
__manifest__ = {
    "name": "common",
    "description": "Base module of AsterNOS Management framework",
    "load_priority": 0,  # modules with lower priorities are loaded first
    "require_feature": []
    # List of feature flags as the prerequisite of this module to get loaded.
    # This particular module is always loaded.
}
