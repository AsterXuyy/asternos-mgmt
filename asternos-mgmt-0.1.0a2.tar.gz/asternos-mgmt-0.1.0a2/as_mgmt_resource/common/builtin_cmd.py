from as_mgmt.cli import show, DumpConfigRenderer


BUILTIN_COMMANDS = [
    show("show {datastore}-config", "/", renderer=DumpConfigRenderer())
]
