import json

from as_mgmt.db import engine
from as_mgmt.test.base import FunctionalTestBase

TEST_DATA = {
    "PORT|Ethernet0": {"admin_status": "up"},
    "PORT|Ethernet1": {"admin_status": "up"},
    "PORT|Ethernet2": {"admin_status": "up", "__refcount__": "1"},
    "PORT|Ethernet3": {"admin_status": "up", "__refcount__": "1"},
    "PORT|Ethernet4": {"admin_status": "up", "__refcount__": "1"},
    "PORT|Ethernet5": {"admin_status": "up", "__refcount__": "1"},
    
    "PORTCHANNEL|PortChannel0001": {
        "description": "Minimal PortChannel object with no members",
        "admin_status": "up"
    },
    "PORTCHANNEL|PortChannel0002": {
        "description": "Complicated PortChannel object with members and various LACP config",
        "admin_status": "up",
        "mtu": "9216",
        "mode": "dynamic",
        "lacp_key": "auto",
        "min_links": "1",
        "system_priority": "10000",
        "fallback": "true",
        "fast_rate": "true",
        "system_id": "12:34:56:ab:cd:ef"
    },
    "PORTCHANNEL_MEMBER|PortChannel0002|Ethernet2": {
        "NULL": "NULL",
    },
    "PORTCHANNEL_MEMBER|PortChannel0002|Ethernet3": {
        "lacp_prio": "65535",
    },
    "PORTCHANNEL|PortChannel0003": {
        "description": "Static load-balance port channel",
        "admin_status": "up",
        "mtu": "9216",
        "mode": "static",
    },
    "PORTCHANNEL_MEMBER|PortChannel0003|Ethernet4": {"NULL": "NULL"},
    "PORTCHANNEL_MEMBER|PortChannel0003|Ethernet5": {"NULL": "NULL"},
}


class TestLag(FunctionalTestBase):

    def setUp(self) -> None:
        super().setUp()
        self.load(TEST_DATA, engine.RUNNING_CFG_DB_NUM)
        self.running_cfg_db = self.get_async_redis(engine.RUNNING_CFG_DB_NUM)
        
    async def test_create_lag_member_batched(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0001/members", "POST",
            [{"port": "Ethernet0", "lacp_port_priority": 222},
             {"port": "Ethernet1"}]
        )
        body = json.loads(resp.body)
        self.assertEqual(resp.code, 200)
        self.assertEqual(
            await self.running_cfg_db.hgetall("PORTCHANNEL_MEMBER|PortChannel0001|Ethernet0"),
            {"lacp_prio": '222', '__refcount__': '0'}
        )
        self.assertEqual(
            await self.running_cfg_db.hgetall("PORTCHANNEL_MEMBER|PortChannel0001|Ethernet1"),
            {'__refcount__': '0'}
        )
        self.assertCountEqual(
            # Result of POST request should carry the created objects.
            body['result'],
            [{"port": "Ethernet0", "lacp-port-priority": 222},
             {"port": "Ethernet1"}]
        )
        
    async def test_create_lag_member_single(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0001/members", "POST",
            {"port": "Ethernet0"},
        )
        body = json.loads(resp.body)
        self.assertEqual(resp.code, 200)
        self.assertEqual(
            await self.running_cfg_db.hgetall("PORTCHANNEL_MEMBER|PortChannel0001|Ethernet0"),
            {'__refcount__': '0'}
        )
        self.assertCountEqual(
            # Result of POST request should carry the created object.
            body, {"port": "Ethernet0"}
        )
        
    async def test_create_lag_member_conflict(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0001/members", "POST",
            {"port": "Ethernet2"},
        )
        self.assertEqual(resp.code, 400)
        self.assertDictEqual(
            json.loads(resp.body),
            {"errors": [{
                "error_tag": "app.portchannel.member_not_unique", 
                "message": "A port may only be the member of one port channel. "
                           "Port Ethernet2 is already a member of PortChannel0002 "
                           "and can not be added to PortChannel0001.",
                "data": {
                    "port": "Ethernet2",
                    "current_portchannel": "PortChannel0002",
                    "new_portchannel": "PortChannel0001",
                }
            }]}
        )
        
    async def test_create_lag_member_bad_port_channel(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel8888/members", "POST",
            {"port": "Ethernet0"},
        )
        self.assertEqual(resp.code, 400)
        self.assertDictEqual(
            json.loads(resp.body),
            {"errors": [{
                "error_tag": "app.invalid_reference", 
                "message": "Detected invalid referenced to PortChannel object "
                           "with storage key PORTCHANNEL|PortChannel8888", 
                "data": {"referee_type": "PortChannel", "referee_key": "PORTCHANNEL|PortChannel8888"}
            }]}
        )
        
    async def test_create_lag_member_bad_port_non_exist(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0001/members", "POST",
            {"port": "Ethernet555"},
        )
        print(resp.body)
        self.assertEqual(resp.code, 400)
        self.assertDictEqual(
            json.loads(resp.body),
            {"errors": [{
                "error_tag": "app.invalid_reference", 
                "message": "Detected invalid referenced to Port object "
                           "with storage key PORT|Ethernet555", 
                "data": {"referee_type": "Port", "referee_key": "PORT|Ethernet555"}
            }]}
        )
        self.assertFalse(
            await self.running_cfg_db.exists("PORTCHANNEL_MEMBER|PortChannel0001|Ethernet555")
        )
        
    async def test_create_lag_member_bad_port(self) -> None:
        # Unlike the previous test case, this request should be rejected by YANG-based validation.
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0001/members", "POST",
            {"port": "Vlan100"},
        )
        print(resp.body)
        self.assertEqual(resp.code, 400)
        self.assertEqual(
            json.loads(resp.body)["errors"][0]["error_tag"],
            "request.validation_error.bad_value"
        )
        self.assertFalse(
            await self.running_cfg_db.exists("PORTCHANNEL_MEMBER|PortChannel0001|Vlan100")
        )
        
    async def test_list_lag_members(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0002/members", "GET",
        )
        self.assertEqual(resp.code, 200)
        self.assertCountEqual(
            json.loads(resp.body)['result'], [
                {"port": "Ethernet2"},
                {"port": "Ethernet3", "lacp-port-priority": 65535},
            ]
        )
        
    async def test_list_lag_members_lag_not_found(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel8848/members", "GET",
        )
        self.assertEqual(resp.code, 404)
        self.assertEqual(
            json.loads(resp.body)["errors"][0]["error_tag"],
            "app.not_found"
        )
        self.assertEqual(
            json.loads(resp.body)["errors"][0]["data"]["resource_type"],
            "PortChannel"
        )
        
    async def test_get_lag_member(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0002/members/Ethernet3", "GET",
        )
        self.assertEqual(resp.code, 200)
        self.assertCountEqual(
            json.loads(resp.body), {"port": "Ethernet3", "lacp-port-priority": 65535},
        )
        
    async def test_delete_lag_member(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0002/members/Ethernet3", "DELETE",
        )
        self.assertEqual(resp.code, 200)
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0002/members/Ethernet3", "GET",
        )
        self.assertEqual(resp.code, 404)
        self.assertEqual(
            "0", await self.running_cfg_db.hget("PORT|Ethernet3", '__refcount__')
        )
        
    async def test_load_all_lags(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels", "GET",
        )
        self.assertEqual(resp.code, 200)
        body = json.loads(resp.body)
        self.assertCountEqual(
            body['result'], [
                {
                    "name": "PortChannel0001",
                    "description": "Minimal PortChannel object with no members",
                    "admin-status": "up",
                    "mode": "lacp",
                    "lacp": {},
                    "members": []
                },
                {
                    "name": "PortChannel0002",
                    "description": "Complicated PortChannel object with members and various LACP config",
                    "admin-status": "up",
                    "mtu": 9216,
                    "mode": "lacp",
                    "lacp": {
                        "lacp-key": "auto",
                        "min-links": 1,
                        "system-priority": 10000,
                        "fallback": True,
                        "fast-rate": True,
                        "system-id": "12:34:56:ab:cd:ef"
                    },
                    "members": [
                        {
                            "port": "Ethernet2",
                        },
                        {
                            "port": "Ethernet3",
                            "lacp-port-priority": 65535
                        }
                    ]
                },
                {
                    "name": "PortChannel0003",
                    "description": "Static load-balance port channel",
                    "admin-status": "up",
                    "mtu": 9216,
                    "mode": "static",
                    "lacp": {},
                    "members": [
                        {
                            "port": "Ethernet4",
                        },
                        {
                            "port": "Ethernet5",
                        }
                    ]
                }
            ]
        )
        
    async def test_load_one_lag(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0003", "GET",
        )
        self.assertEqual(resp.code, 200)
        body = json.loads(resp.body)
        self.assertDictEqual(body, {
            "name": "PortChannel0003",
            "description": "Static load-balance port channel",
            "admin-status": "up",
            'lacp': {},
            'members': [{'port': 'Ethernet4'}, {'port': 'Ethernet5'}],
            'mode': 'static',
            'mtu': 9216,
        })
        
    async def test_delete_lag(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0003", "DELETE"
        )
        self.assertEqual(resp.code, 200)
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel0003", "GET",
        )
        self.assertEqual(resp.code, 404)
        self.assertFalse(
            await self.running_cfg_db.exists("PORTCHANNEL|PortChannel0003", 
                                             'PORTCHANNEL_MEMBER|PortChannel0003|Ethernet4',
                                             'PORTCHANNEL_MEMBER|PortChannel0003|Ethernet5')
        )
        
    async def test_delete_lag_not_exist(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/portchannels/PortChannel6666", "DELETE"
        )
        self.assertEqual(resp.code, 404)
        
    async def test_create_lag(self) -> None:
        body = {
            "name": "PortChannel0004",
            "description": "Complicated PortChannel object with members and various LACP config",
            "admin-status": "up",
            "mtu": 9216,
            "mode": "lacp",
            "lacp": {
                "lacp-key": "auto",
                "min-links": 1,
                "system-priority": 10000,
                "fallback": True,
                "fast-rate": True,
                "system-id": "12:34:56:ab:cd:ef"
            },
            "members": [
                {
                    "port": "Ethernet0",
                },
                {
                    "port": "Ethernet1",
                    "lacp-port-priority": 65535
                }
            ]
        }
        await self.rest_request("rest/v1/running/portchannels", "POST", body)
        resp = await self.rest_request("rest/v1/running/portchannels/PortChannel0004", "GET")
        self.assertDictEqual(json.loads(resp.body), body)
        
    async def test_batch_create_lags(self) -> None:
        body = [{
            "name": "PortChannel0004",
            "mode": "static"
        }, {
            "name": "PortChannel0005",
            "mode": "static",
            "members": [
                {"port": "Ethernet0"}
            ]
        }]
        await self.rest_request("rest/v1/running/portchannels", "POST", body)
        resp = await self.rest_request("rest/v1/running/portchannels/PortChannel0004", "GET")
        self.assertDictEqual(json.loads(resp.body), {
            "name": "PortChannel0004",
            "mode": "static",
            "admin-status": "up",
            "lacp": {},
            "members": []
        })
        
        self.assertDictEqual(
            await self.running_cfg_db.hgetall("PORTCHANNEL|PortChannel0004"),
            {"mode": "static", "__refcount__": "0", "admin_status": "up"}
        )
        self.assertDictEqual(
            await self.running_cfg_db.hgetall("PORTCHANNEL|PortChannel0005"),
            {"mode": "static", "__refcount__": "0", "admin_status": "up"}
        )
        
    async def test_update_lag_and_add_member(self) -> None:
        body = {
            "admin-status": "down",
            "members": [
                {"port": "Ethernet0"},  # create new member
                {"port": "Ethernet3", "lacp-port-priority": "22222"}  # modify existing member
            ]
        }
        await self.rest_request("rest/v1/running/portchannels/PortChannel0002", "PATCH", body)
        self.assertEqual(
            len(await self.running_cfg_db.keys("PORTCHANNEL_MEMBER|PortChannel0002|*")),
            3
        )
        self.assertTrue(
            await self.running_cfg_db.exists("PORTCHANNEL_MEMBER|PortChannel0002|Ethernet0"),
        )
        self.assertEqual(
            await self.running_cfg_db.hget("PORTCHANNEL_MEMBER|PortChannel0002|Ethernet3", "lacp_prio"),
            "22222"
        )
        self.assertEqual(
            "down",
            await self.running_cfg_db.hget("PORTCHANNEL|PortChannel0002", "admin_status")
        )

    async def test_netconf_list_operational_config_filter_port(self):
        async with self.netconf_session():
            result = await self.netconf_get_config("running", """
<filter type="subtree">
    <top xmlns="http://www.asterfusion.com/asternos-schema/1.0/config">
        <portchannels>
            <portchannel>
                <name>PortChannel0002</name>
            </portchannel>
        </portchannels>
    </top>
</filter>
            """)
        self.assert_xml_equal(result, """
<data><top>
    <portchannels>
        <portchannel>
            <name>PortChannel0002</name>
            <description>Complicated PortChannel object with members and various LACP config</description>
            <mtu>9216</mtu>
            <admin-status>up</admin-status>
            <mode>lacp</mode>
            <lacp>
                <lacp-key>auto</lacp-key>
                <min-links>1</min-links>
                <system-priority>10000</system-priority>
                <fallback>true</fallback>
                <fast-rate>true</fast-rate>
                <system-id>12:34:56:ab:cd:ef</system-id>
            </lacp>
            <members>
                <member>
                    <port>Ethernet2</port>
                </member>
                <member>
                    <port>Ethernet3</port>
                    <lacp-port-priority>65535</lacp-port-priority>
                </member>
            </members>
        </portchannel>
    </portchannels>
</top></data>               
        """)
        
    async def test_netconf_list_portchannel_all_member(self):
        async with self.netconf_session():
            result = await self.netconf_get_config("running", """
<filter type="subtree">
    <top xmlns="http://www.asterfusion.com/asternos-schema/1.0/config">
        <portchannels>
            <portchannel>
                <name>PortChannel0002</name>
                <members>
                    <member/>
                </members>
            </portchannel>
        </portchannels>
    </top>
</filter>
            """)
        self.assert_xml_equal(result, """
<data><top>
    <portchannels>
        <portchannel>
            <name>PortChannel0002</name>
            <members>
                <member>
                    <port>Ethernet2</port>
                </member>
                <member>
                    <port>Ethernet3</port>
                    <lacp-port-priority>65535</lacp-port-priority>
                </member>
            </members>
        </portchannel>
    </portchannels>
</top></data>               
        """)
        
    async def test_netconf_list_portchannel_specific_member(self):
        async with self.netconf_session():
            result = await self.netconf_get_config("running", """
<filter type="subtree">
    <top xmlns="http://www.asterfusion.com/asternos-schema/1.0/config">
        <portchannels>
            <portchannel>
                <name>PortChannel0002</name>
                <members>
                    <member>
                        <port>Ethernet3</port>
                    </member>
                </members>
            </portchannel>
        </portchannels>
    </top>
</filter>
            """)
        self.assert_xml_equal(result, """
<data><top>
    <portchannels>
        <portchannel>
            <name>PortChannel0002</name>
            <members>
                <member>
                    <port>Ethernet3</port>
                    <lacp-port-priority>65535</lacp-port-priority>
                </member>
            </members>
        </portchannel>
    </portchannels>
</top></data>               
        """)
        
    async def test_netconf_create_portchannel(self):
        body = """
<portchannel>
    <name>PortChannel0004</name>
    <description>foo bar</description>
    <mtu>8888</mtu>
    <admin-status>down</admin-status>
    <mode>lacp</mode>
    <lacp>
        <lacp-key>123</lacp-key>
        <min-links>2</min-links>
        <system-priority>6666</system-priority>
        <fallback>true</fallback>
        <fast-rate>true</fast-rate>
        <system-id>12:34:56:ab:cd:ef</system-id>
    </lacp>
    <members>
        <member>
            <port>Ethernet0</port>
        </member>
        <member>
            <port>Ethernet1</port>
            <lacp-port-priority>22222</lacp-port-priority>
        </member>
    </members>
</portchannel>
        """
        async with self.netconf_session():
            await self.netconf_edit_config("running", f"""
<config><top>
    <portchannels operation="create">
{body}
    </portchannels>
</top></config>
            """)
            result = await self.netconf_get_config("running", """
<filter type="subtree">
    <top xmlns="http://www.asterfusion.com/asternos-schema/1.0/config">
        <portchannels>
            <portchannel>
                <name>PortChannel0004</name>
            </portchannel>
        </portchannels>
    </top>
</filter>
            """)
            self.assert_xml_equal(result, f"""
<data><top>
    <portchannels>
        {body}
    </portchannels>
</top></data>               
        """)        
            
    async def test_netconf_batch_create_portchannel_member(self):
        async with self.netconf_session():
            await self.netconf_edit_config("running", """
<config><top>
    <portchannels>
        <portchannel>
            <name>PortChannel0002</name>
            <members operation="create">
                <member>
                    <port>Ethernet0</port>
                </member>
                <member>
                    <port>Ethernet1</port>
                </member>
            </members>
        </portchannel>
    </portchannels>
</top></config>
            """)
        self.assertEqual(
            await self.running_cfg_db.exists('PORTCHANNEL_MEMBER|PortChannel0002|Ethernet0',
                                             'PORTCHANNEL_MEMBER|PortChannel0002|Ethernet1'),
            2
        )
        
    async def test_netconf_delete_portchannel_member(self):
        async with self.netconf_session():
            await self.netconf_edit_config("running", """
<config><top>
    <portchannels>
        <portchannel operation="delete">
            <name>PortChannel0002</name>
        </portchannel>
    </portchannels>
</top></config>
            """)
        self.assertEqual(
            await self.running_cfg_db.exists('PORTCHANNEL|PortChannel0002'
                                             'PORTCHANNEL_MEMBER|PortChannel0002|Ethernet2',
                                             'PORTCHANNEL_MEMBER|PortChannel0002|Ethernet3'),
            0
        )
        
    async def test_netconf_change_lacp_params(self):
        async with self.netconf_session():
            await self.netconf_edit_config("running", """
<config><top>
    <portchannels>
        <portchannel operation="merge">
            <name>PortChannel0002</name>
            <mtu>1500</mtu>
            <lacp>
                <system-id>22:22:22:22:22:22</system-id>
            </lacp>
        </portchannel>
    </portchannels>
</top></config>
            """)
        self.assertEqual(
            await self.running_cfg_db.hget('PORTCHANNEL|PortChannel0002', 'mtu'),
            '1500'
        )
        self.assertEqual(
            await self.running_cfg_db.hget('PORTCHANNEL|PortChannel0002', 'system_id'),
            '22:22:22:22:22:22'
        )
