import itertools
import logging

from typing import TypedDict, Union, Optional
from typing_extensions import Required

from as_mgmt import (
    BaseModel, Field, Reference, regex_validate, trivially_serializable, bind_path,
    UseSession, UseController
)
from as_mgmt.cli import cfg
from as_mgmt.exc import DuplicateResource, ResourceNotFound, InvalidResource, BadRequest

from as_mgmt_resource.ietf_yang_types import MacAddress
from as_mgmt_resource.port.port import Port

LOG = logging.getLogger(__name__)


class LagMemberNotUniqueError(BadRequest):
    error_tag = "app.portchannel.member_not_unique"
    msg_format = ("A port may only be the member of one port channel. "
                  "Port {port} is already a member of {current_portchannel} and can not be added to {new_portchannel}.")
    
    def __init__(self, port: str, current_portchannel: str, new_portchannel: str):
        super().__init__(
            port=port,
            current_portchannel=current_portchannel,
            new_portchannel=new_portchannel,
        )


@trivially_serializable("asternos-portchannel:lacp-key-type")
class LacpKeyType:
    
    __slots__ = ("_value", )
    _value: Union[str, int]
    
    def __init__(self, value: Union[str, int]) -> None:
        if isinstance(value, str) and value == 'auto':
            self._value = value
            return
        
        if isinstance(value, str):
            try:
                value = int(value)
            except ValueError as exc:
                raise ValueError(f"Unexpected LACP Key '{value}'") from exc
        if isinstance(value, int):
            if not 1 <= value <= 65535:
                raise ValueError(f"Unexpected LACP Key '{value}'")
        else:
            raise TypeError(f"Expected int or string, got {type(value).__name__} instead")
        self._value = value
        
    @property
    def is_auto(self) -> bool:
        return self._value == 'auto'
    
    @property
    def int_value(self) -> int:
        if isinstance(self._value, int):
            return self._value
        raise TypeError('value is "auto"')
    
    def __str__(self) -> str:
        return str(self._value)


class PortChannel(BaseModel):
    __table_name__ = "PORTCHANNEL"
    
    name = Field(str, primary_key=True, validator=regex_validate(r"PortChannel[0-9]{1,4}"))
    description = Field(str, validator=lambda x: 1 <= len(x) <= 255)
    mtu = Field(int, validator=lambda x: 1 <= x <= 9216)
    admin_status = Field(str, default="up")
    mode = Field(str, default="dynamic")
    
    lacp_key = Field(LacpKeyType)
    min_links = Field(int, validator=lambda x: 1 <= x <= 128)
    system_priority = Field(int, validator=lambda x: 0 <= x <= 65535)
    fallback = Field(bool)
    fast_rate = Field(bool)
    system_id = Field(MacAddress)
    

class PortChannelMember(BaseModel):
    __table_name__ = "PORTCHANNEL_MEMBER"
    
    name = Field(str, primary_key=True)
    port = Field(str, primary_key=True)
    
    lacp_prio = Field(int, validator=lambda x: 0 <= x <= 65535)
    
    channel_ref = Reference(['name'], PortChannel, on_del_cascade=True)
    port_ref = Reference(["port"], Port)
    

# ----- API Type Hints ----- #
# TODO: These should be auto-generated from YANG files in the future.
# NOTE:
# 1. Leaf fields are typically "Optional" because we allow use to PATCH a None value to "remove" this node.
# 2. These TypedDict definitions are completely optional, but recommended to increase maintainability.
class PortChannelMemberDict(TypedDict, total=False):
    port: Required[str]
    lacp_port_priority: Optional[int]
    

class LacpCfgDict(TypedDict, total=False):
    lacp_key: Optional[LacpKeyType]
    min_links: Optional[int]
    system_priority: Optional[int]
    fallback: Optional[bool]
    fast_rate: Optional[bool]
    system_id: Optional[MacAddress]
    

class PortChannelDict(TypedDict, total=False):
    name: Required[str]
    description: Optional[str]
    mtu: Optional[int]
    admin_status: Optional[str]
    mode: Optional[str]
    lacp: LacpCfgDict
    members: list[PortChannelMemberDict]
# ----- API Type Hints End ----- #


@bind_path("/portchannels[name={lag_name}]/members[port={port}]")
class PortChannelMemberController:
    session = UseSession('CONFIG_DB')
    
    @staticmethod
    def _set_lag_member_attrs(obj: PortChannelMember, body: PortChannelMemberDict) -> None:
        if "lacp_port_priority" in body:
            obj.lacp_prio = body["lacp_port_priority"]
            
    @staticmethod
    def _convert_lag_member_to_dict(obj: PortChannelMember) -> PortChannelMemberDict:
        result: PortChannelMemberDict = {
            "port": obj.port,
            "lacp_port_priority": obj.lacp_prio
        }
        return result
            
    async def create(self, lag_name: str, body: PortChannelMemberDict) -> PortChannelMemberDict:
        if 'port' not in body:
            raise InvalidResource('PortChannel', body, "Missing port channel member port")
        conflicting_channels = await self.session.query(PortChannelMember).filter(
            PortChannelMember.port == body["port"]
        ).all()
        if conflicting_channels:
            if len(conflicting_channels) > 1:
                LOG.error("Detected corrupted config data: multiple portchannel referenced %s", body['port'])
            raise LagMemberNotUniqueError(body["port"], conflicting_channels[0].name, lag_name)
        obj = PortChannelMember(name=lag_name, port=body["port"])
        self._set_lag_member_attrs(obj, body)
        await self.session.add(obj)
        return self._convert_lag_member_to_dict(obj)
    
    async def merge(self, lag_name: str, port: str, body: PortChannelMemberDict) -> PortChannelMemberDict:
        obj = await self.session.query(PortChannelMember).filter(
            PortChannelMember.name == lag_name,
            PortChannelMember.port == port,
        ).one_or_none()
        if obj is None:
            raise ResourceNotFound("PortChannelMember", {"name": lag_name, "port": port})
        self._set_lag_member_attrs(obj, body)
        return self._convert_lag_member_to_dict(obj)
    
    async def delete(self, lag_name: str, port: str):
        await self.session.query(PortChannelMember).filter(
            PortChannelMember.name == lag_name,
            PortChannelMember.port == port,
        ).delete()
        
    async def get(self, lag_name: str, port: Optional[str] = None
                  ) -> Union[list[PortChannelMemberDict], PortChannelMemberDict]:
        # TODO: Such check operation should be optimized by "count" method,
        #     which only checks existence, but do not load data from DB.
        channel = await self.session.query(PortChannel).filter(PortChannel.name == lag_name).one_or_none()
        if channel is None:
            raise ResourceNotFound("PortChannel", {"name": lag_name})
        
        query = self.session.query(PortChannelMember).filter(PortChannelMember.name == lag_name)
        if port is not None:
            query.filter(PortChannelMember.port == port)
            member = await query.one_or_none()
            if member is None:
                raise ResourceNotFound("PortChannelMember", {"name": lag_name, "port": port})
            return self._convert_lag_member_to_dict(member)
        
        members = await query.all()
        return [self._convert_lag_member_to_dict(item) for item in members]
    
    async def load_all(self) -> dict[str, list[PortChannelMemberDict]]:
        objs = await self.session.query(PortChannelMember).all()
        objs.sort(key=lambda x: x.name)  # TODO: This should be integrated by query framework.
        result = {}
        for lag_name, members in itertools.groupby(objs, lambda x: x.name):
            result[lag_name] = [
                self._convert_lag_member_to_dict(member)
                for member in members
            ]
        return result
    
    
@bind_path("/portchannels[name={name}]")
class PortChannelController:
    session = UseSession('CONFIG_DB')
    member_ctl = UseController(PortChannelMemberController)
    
    async def get(self, name: Optional[str] = None) -> Union[list[PortChannelDict], PortChannelDict]:
        query = self.session.query(PortChannel)
        if name is not None:
            lag = await query.filter(PortChannel.name == name).one_or_none()
            if lag is None:
                raise ResourceNotFound("PortChannel", {"name": name})
            members = await self.member_ctl.get(name)
            assert isinstance(members, list)
            lag_dct = self._convert_lag_to_dict(lag)
            lag_dct['members'] = members
            return lag_dct
            
        lags = await query.all()
        result: list[PortChannelDict] = []
        all_members = await self.member_ctl.load_all()
        for lag in lags:
            lag_dct = self._convert_lag_to_dict(lag)
            lag_dct["members"] = all_members.get(lag.name, [])
            result.append(lag_dct)
        return result
    
    @staticmethod
    def _set_lag_attrs(obj: PortChannel, body: PortChannelDict) -> None:
        if 'description' in body:
            obj.description = body["description"]
        if 'mtu' in body:
            obj.mtu = body["mtu"]
        if "admin_status" in body:
            obj.admin_status = body["admin_status"]
        if "mode" in body:
            if body["mode"] == "lacp":
                obj.mode = "dynamic"
            elif body["mode"] == "static":
                obj.mode = "static"
            else:
                assert False, f"unexpected lag mode {body['mode']}"
        if "lacp" in body:
            lacp_cfg = body["lacp"]
            if "lacp_key" in lacp_cfg:
                obj.lacp_key = lacp_cfg["lacp_key"]
            if "min_links" in lacp_cfg:
                obj.min_links = lacp_cfg["min_links"]
            if "system_priority" in lacp_cfg:
                obj.system_priority = lacp_cfg["system_priority"]
            if "fallback" in lacp_cfg:
                obj.fallback = lacp_cfg["fallback"]
            if "fast_rate" in lacp_cfg:
                obj.fast_rate = lacp_cfg["fast_rate"]
            if "system_id" in lacp_cfg:
                obj.system_id = lacp_cfg["system_id"]
                
    @staticmethod
    def _convert_lag_to_dict(obj: PortChannel) -> PortChannelDict:
        result: PortChannelDict = {
            "name": obj.name,
            "members": [],
            "description": obj.description,
            "mtu": obj.mtu,
            "admin_status": obj.admin_status,
        }
        if obj.mode == "static":
            result["mode"] = "static"
        else:
            result["mode"] = "lacp"
        
        result["lacp"] = {
            "fallback": obj.fallback,
            "fast_rate": obj.fast_rate,
            "lacp_key": obj.lacp_key,
            "min_links": obj.min_links,
            "system_id": obj.system_id,
            "system_priority": obj.system_priority,
        }
        return result
        
    async def create(self, body: PortChannelDict):
        if 'name' not in body:  # TODO: YANG Models' "mandatory" field should be able to check this.
            raise InvalidResource('PortChannel', body, "Missing port channel name")
        name = body['name']
        lag = await self.session.query(PortChannel).filter(PortChannel.name == name).one_or_none()
        if lag is not None:
            raise DuplicateResource("PortChannel", {"name": name})
        obj = PortChannel(name=body["name"])
        self._set_lag_attrs(obj, body)
        await self.session.add(obj) 
        for member in body.get('members', []):
            await self.member_ctl.create(name, member)
    
    async def merge(self, body: PortChannelDict, name: str) -> None:
        lag = await self.session.query(PortChannel).filter(PortChannel.name == name).one_or_none()
        if lag is None:
            raise ResourceNotFound("PortChannel", {"name": name})
        self._set_lag_attrs(lag, body)
        if 'members' in body:
            members = await self.member_ctl.get(name)
            assert isinstance(members, list)
            member_idx = {item['port']: item for item in members}
            for new_member in body["members"]:
                if new_member["port"] in member_idx:
                    await self.member_ctl.merge(name, new_member["port"], new_member)
                else:
                    await self.member_ctl.create(name, new_member)
        
    # async def replace(self, body: PortChannelDict, name: str) -> None:
        # TODO: The framework should be able to fill "None" values in missing fields
        #       so that replace method may be implemented easily.
        
    async def delete(self, name: Optional[str] = None) -> None:
        count = await self.session.query(PortChannel).filter(PortChannel.name == name).delete()
        if count == 0:
            raise ResourceNotFound("PortChannel", {"name": name})
