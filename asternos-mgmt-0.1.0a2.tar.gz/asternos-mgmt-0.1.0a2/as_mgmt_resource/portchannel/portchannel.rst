Link Aggregation Groups
=====================================

Link Aggregation Groups provides Link Layer high availability by aggregating multiple
ethernet ports into one logical L2 port.

This module provides two operation mode for LAGs:

* Dynamic, or LACP mode, which implements standard LACP protocol and select forwarding ports
  based on bidirectional negotiation.
* Static mode, which simply load balances traffic to ports in "up" state.


YANG Model
-----------------------

.. literalinclude:: asternos-portchannel.yang
   :language: yang
   :tab-width: 2


Command Line
-----------------------

.. klish:command:: link-aggregation <lag-id>

   :name: link-aggregation - Create a Link Aggregation Group and enters its view

   :synopsis: 

      link-aggregation <lag-id>

      This command first checks if <lag-id> exists. If not, create a new empty LAG object.
      Then, enter ``"lag-port"`` view of the corresponding object

      no link-aggregation <lag-id>

      Delete a Link Aggregation group, remove its all member configuration.

   :param int lag-id: Integer ID of this LAG object, ranges from 0 to 9999.

   :examples:

      .. code-block:: text

         sonic-cli# configure 
         sonic-cli(config)# link-aggregation 0
         sonic-cli(lag-port-0)# 

   :see-also:

      Important configuration commands of LAGs:
      
      - :klish:command:`eth-port/link-aggregation-group`
      - :klish:command:`lag-port/mode`
      - :klish:command:`lag-port/lacp system-priority`
      - :klish:command:`lag-port/lacp system-id`
      - :klish:command:`lag-port/lacp key`
      - :klish:command:`lag-port/lacp min-links`
      - :klish:command:`lag-port/lacp fast-rate`
      - :klish:command:`lag-port/lacp fallback`

.. klish:command:: link-aggregation-group <lag-id> [port-priority <priority>]
   :view: eth-port

   :name: link-aggregation-group - Set an ethernet port to be a member of a LAG.

   :synopsis:

      **link-aggregation-group <lag-id> [port-priority <priority>]** 

      Add the current ethernet port to a LAG object.
      The ethernet port must not be a member of VLANs or configured with IP addresses.
      Each ethernet port may not be a member of more than one LAGs 
          
      **no link-aggregation-group**      

      Remove the current port from whichever LAG object it belongs to.

   :param int lag-id: Target LAG ID, ranges from 0 to 9999.
   :param uint16 priority: 
      LACP Port priority value. This option has no effect if the LAG works in "static" mode.
      The port priority determines which ports should be put in standby mode when there is 
      a hardware limitation that prevents all compatible ports from aggregating. 
      Ports with lower priorities are preferred.

   :examples:

      .. code-block:: text

         sonic-cli# configure 
         sonic-cli(config)# ethernet-port 45
         sonic-cli(eth-port-45)# link-aggregation-group 2 port-priority 500

      .. code-block:: text

         sonic-cli(eth-port-45)# no link-aggregation-group

.. klish:command:: mode {lacp|static}
   :view: lag-port
   :idempotent:

   :name: mode - select Link Aggregation Group operation mode.

   :synopsis:

      **mode lacp**

      Use dynamic LACP mode. This is the default.

      **mode static**

      Use static mode, which simply load balances traffic to ports in "up" state.

   :see-also:

      In ``lacp`` mode, the following configurations are REQUIRED:

      - :klish:command:`lag-port/lacp system-priority`
      - :klish:command:`lag-port/lacp system-id`


.. klish:command:: lacp system-priority <priority>
   :view: lag-port
   :idempotent:

   :name: lacp system-priority - Set priority for LACP protocol master negotiation

   :synopsis: 
   
      lacp system-priority <priority>

      Set system priority for a instance of LAG. The system with the lower system priority becomes
      the master of LACP protocol operation.
   
   :param uint16 priority: priority value


.. klish:command:: lacp system-id <mac-addr>
   :view: lag-port
   :idempotent:

   :name: lacp system-id - configure LACP system id and lag port MAC address.

   :synopsis:

      lacp system-id <mac-addr>

      Configure a MAC address for this LAG. This address is used in both LACP PDUs as system-id
      and configured as the MAC address of the LAG port.

   :param str mac-addr: 
      A MAC address represented in hex-colon format.
      The address can not be zero and can not be a multicast address.

   :examples:

      .. code-block:: text

         sonic-cli(config)# link-aggregation 0
         sonic-cli(lag-port-0)# lacp system-id 12:34:56:ab:cd:ef
   

.. klish:command:: lacp key <key>
   :view: lag-port
   :idempotent:

   :name: lacp key - Configure LACP key.

   :synopsis:

      lacp key <key>

      LACP key defines the ability of a port to aggregate with other ports. 
      LACP key should be either "auto" or a integer ranges from 1 to 65535.
      When lacp_key is set to 'auto', use the lag id prefixed with "1" as the actual LACP key. 

   :param uint16 lacp_key: Value of LACP key. Default to "auto" and can not be 0. 


.. klish:command:: lacp min-links <num-links>
   :view: lag-port
   :idempotent:

   :name: lacp key - Configure minimum number of links in "up" state for the LAG to operate.

   :param int num-links: minimum link count. Must be greater or equal to 1. Default to 1.


.. klish:command:: lacp fast-rate
   :view: lag-port
   :idempotent:

   :name: lacp fast-rate - Set LACP fast rate utilities.

   :synopsis:

      **lacp fast-rate**
      
      Enable LACP fast rate. Fast-rate allows the LACP peer to send LACP PDUs at a 
      rate of one per second even after synchronization. Otherwise, the PDU rate is 
      one per 30 seconds after synchronization.

      **no lacp fast-rate**

      Disable LACP fast rate.


.. klish:command:: lacp fallback
   :view: lag-port
   :idempotent:

   :name: lacp fallback - Set LACP fallback utilities.

   :synopsis:

      **lacp fallback**
      
      Enable LACP fallback. The fallback mode brings up one of the LACP member ports to 
      'UP' state before an LACP PDU is received by the LAG.

      **no lacp fallback**

      Disable LACP fallback.

