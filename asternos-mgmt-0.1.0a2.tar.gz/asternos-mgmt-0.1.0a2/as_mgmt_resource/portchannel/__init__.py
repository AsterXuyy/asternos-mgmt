__manifest__ = {
    "name": "portchannel",
    "description": "PortChannel(LAG) and LACP resources",
    "load_priority": 100,
    "require_feature": [],
    "define_feature": {}
}
