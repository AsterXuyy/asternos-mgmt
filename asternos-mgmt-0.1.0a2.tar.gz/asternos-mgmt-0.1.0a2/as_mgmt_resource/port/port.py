from typing import Optional, TypedDict, cast

from as_mgmt import BaseModel, Field, bind_path
from as_mgmt.cli import cfg
from as_mgmt.app.base import UseSession
from as_mgmt.exc import ResourceNotFound


class PortDict(TypedDict, total=False):
    """
    This class *should* be auto-generated.
    However, the generation logic is not implemented yet,
    so we write it manually.
    """
    name: str
    index: str
    speed: int
    mtu: int
    lanes: list[int]
    admin_status: str
    

class Port(BaseModel):
    __table_name__ = "PORT"
    __no_add_del__ = True
    
    name = Field(str, primary_key=True)
    index = Field(int, read_only=True)
    lanes = Field(list[int], read_only=True)
    fec = Field(str)
    mtu = Field(int)
    alias = Field(str, read_only=True)
    admin_status = Field(str)
    speed = Field(int)
    
    def as_dict(self) -> PortDict:
        result = {
            field: getattr(self, field)
            for field in ['name', 'index', 'speed', 'mtu', 'lanes', 'admin_status']
            if getattr(self, field) is not None
        }
        return cast(PortDict, result)
    

@bind_path("/ports[name={name}]")
class PortController:
    session = UseSession('CONFIG_DB')
    
    async def get(self, name: Optional[str] = None) -> list[PortDict]:
        query = self.session.query(Port)
        if name is not None:
            query = query.filter(Port.name == name)
        result = await query.all()
        return [item.as_dict() for item in result]
    
    async def merge(self, body: PortDict, name: str) -> None:
        obj = await self.session.query(Port).filter(Port.name == name).one_or_none()
        if obj is None:
            raise ResourceNotFound("port", {"name": name})
        for key, value in body.items():
            setattr(obj, key, value)


PORT_COMMANDS = [
    cfg("ethernet-port {port_num}", "/ports[name=Ethernet{port_num}]", [
        cfg("speed {speed}", "", converter={"speed": "{speed}"}),
        cfg("mtu {mtu}", "", converter={"mtu": "{mtu}"}),
        cfg("shutdown", "", converter={"admin-status": "down"}),
        cfg("no shutdown", "", converter={"admin-status": "up"}),
    ])
]
