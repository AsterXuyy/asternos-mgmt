Port
======================

The Port resource contains various configuration and state data of ethernet ports.


YANG Model
----------------------

.. literalinclude:: asternos-port.yang
   :language: yang
   :tab-width: 4

Command Line
----------------------

.. klish:command:: ethernet-port <name|port-id>
   
   :name: ethernet-port - Enter the view of configuring an ethernet port
   :synopsis: 
      ethernet-port <port-id>

      This command enters ethernet port configuration view of the port specified by <name> parameter.
      Prints an error if the given port name does not exist.

   :param port-id:
      Integer ID of the ethernet port, e.g. 0 for Ethernet0, 10 for Ethernet10.
   
   :examples:

      .. code-block:: text

         sonic-cli# configure 
         sonic-cli(config)# ethernet-port 0
         sonic-cli(eth-port-0)# 
   
   :see-also:
      Important configure commands of ethernet ports:

      - :klish:command:`eth-port/speed`
      - :klish:command:`eth-port/shutdown`
      - :klish:command:`eth-port/startup`
      - :klish:command:`eth-port/mtu`
      - :klish:command:`eth-port/startup-delay`
      - :klish:command:`eth-port/description`

      Commands related with Link Aggregation Groups(LAGs):

      - :klish:command:`eth-port/link-aggregation-group`


.. klish:command:: speed <speed-mbps>
   :view: eth-port
   :idempotent:

   :name: speed - Change the speed of an ethernet port

   :param int speed-mbps: Speed of the port in Mbps.

   :examples:

      .. code-block:: text

         sonic-cli(config)# ethernet-port 0
         sonic-cli(eth-port-0)# speed 25000


.. klish:command:: shutdown
   :view: eth-port
   :idempotent:

   :name: shutdown - Shutdown an interface by setting its ``admin_status`` to ``down``

   :examples:

      .. code-block:: text

         sonic-cli(config)# ethernet-port 0
         sonic-cli(eth-port-0)# shutdown

   :see-also:

      - :klish:command:`eth-port/startup`

   
.. klish:command:: startup
   :view: eth-port
   :idempotent:

   :name: startup - Startup an interface by setting its ``admin_status`` to ``up``

   :examples:

      .. code-block:: text

         sonic-cli(config)# ethernet-port 0
         sonic-cli(eth-port-0)# startup

   :see-also:

      - :klish:command:`eth-port/shutdown`

.. klish:command:: mtu <mtu>
   :view: eth-port
   :idempotent:

   :name: mtu - Configure the Maximum Transmit Unit of an ethernet port.

   :param int mtu: 
      MTU value. Typical range is 1500-9216. Refer to the YANG model for detailed range for current device model.

   :examples:

      .. code-block:: text

         sonic-cli(config)# ethernet-port 0
         sonic-cli(eth-port-0)# mtu 1500

   :see-also:

      * `Maximum Transmit Unit <https://en.wikipedia.org/wiki/Maximum_transmission_unit>`_
      * `Jumbo Frames <https://en.wikipedia.org/wiki/Jumbo_frame>`_, which allows greater MTU values 
        up to more than 9000 bytes.


.. klish:command:: startup-delay <time>
   :view: eth-port
   :idempotent:

   :name: startup-delay - Set a timer to delay interface startup after system boot.

   :param int time: Value of the delay timer in seconds.

   :examples:

      .. code-block:: text

         sonic-cli(config)# ethernet-port 0
         sonic-cli(eth-port-0)# startup-delay 100


.. klish:command:: description <desc>
   :view: eth-port
   :idempotent:

   :name: description - Set arbitrary comment string for an ethernet port.

   :param str desc: The description string. Maximum length is 255 characters.
