__manifest__ = {
    "name": "port",
    "description": "Ethernet port resource definition",
    "load_priority": 100,
    "require_feature": []
}
