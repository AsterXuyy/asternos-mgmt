# pylint: disable=too-many-public-methods
import asyncio
import json

from tornado.websocket import websocket_connect
from tornado.httpclient import HTTPRequest

from as_mgmt.db import engine
from as_mgmt.test.base import FunctionalTestBase
from as_mgmt.typing_helper import NetconfRPCError
from as_mgmt.gnmi.gnmi.gnmi_pb2_grpc import gNMIStub
from as_mgmt.gnmi.gnmi.gnmi_pb2 import (  # pylint: disable=no-name-in-module
    CapabilityRequest, CapabilityResponse, ModelData
)


OPERATIONAL_CFG_DATA = {
    "PORT|Ethernet0": {
        "index": "0",
        "lanes": "113",
        "fec": "rs",
        "mtu": "9216",
        "alias": "Y1",
        "admin_status": "down",
        "speed": "25000",
    },
    "PORT|Ethernet64": {
        "index": "52",
        "lanes": "9,10,11,12",
        "fec": "rs",
        "mtu": "9216",
        "alias": "C5",
        "admin_status": "up",
        "speed": "100000",
    }
}

RUNNING_CFG_DATA = {
    "PORT|Ethernet0": {
        "admin_status": "down",
    },
    "PORT|Ethernet64": {
        "NULL": "NULL"
    }
}


class TestPort(FunctionalTestBase):

    def setUp(self) -> None:
        self.load(OPERATIONAL_CFG_DATA, engine.OPERATIONAL_INTENDED_CFG_DB_NUM)
        self.load(RUNNING_CFG_DATA, engine.RUNNING_CFG_DB_NUM)
        super().setUp()
        
    async def test_invalid_path(self) -> None:
        resp = await self.rest_request(
            "rest/v1/operational/blah_blah_blah/2345", "GET"
        )
        self.assertEqual(resp.code, 404)
        self.assertDictEqual(json.loads(resp.body.decode('utf-8')), {
            "errors": [{
                "message": "Path blah_blah_blah/2345 not found",
                "error_tag": "request.invalid_path",
                "data": {"path": "blah_blah_blah/2345"}
            }]
        })

    async def test_get_port_list(self) -> None:
        resp = await self.rest_request(
            "rest/v1/operational/ports", "GET"
        )
        self.assertEqual(resp.code, 200)
        body = json.loads(resp.body.decode('utf-8'))
        self.assertCountEqual(body['result'], [
            {
                "name": "Ethernet0",
                "index": 0,
                "lanes": [113],
                "mtu": 9216,
                "admin-status": "down",
                "speed": 25000,
            },
            {
                "name": "Ethernet64",
                "index": 52,
                "lanes": [9, 10, 11, 12],
                "mtu": 9216,
                "admin-status": "up",
                "speed": 100000,
            }
        ])
        
    async def test_get_port_item(self) -> None:
        resp = await self.rest_request(
            "rest/v1/operational/ports/Ethernet0", "GET"
        )
        self.assertEqual(resp.code, 200)
        body = json.loads(resp.body.decode('utf-8'))
        self.assertEqual(body, 
            {
                "name": "Ethernet0",
                "index": 0,
                "lanes": [113],
                "mtu": 9216,
                "admin-status": "down",
                "speed": 25000,
            }
        )
        
    async def test_update_port_speed(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/ports/Ethernet0", "PATCH",
            {"speed": 10000}
        )
        self.assertEqual(resp.code, 200)
        self.assertEqual(
            self.get_sync_redis(engine.RUNNING_CFG_DB_NUM).hget("PORT|Ethernet0", "speed"),
            "10000"
        )
    
    async def test_update_port_speed_by_cmd(self) -> None:
        stdout, stderr = await self.cli_command(
            ["configure", "ethernet-port 0", "speed 10000"]
        )
        self.assertNotIn('error', stdout.lower())
        self.assertNotIn('error', stderr.lower())
        self.assertEqual(
            self.get_sync_redis(engine.RUNNING_CFG_DB_NUM).hget("PORT|Ethernet0", "speed"),
            "10000"
        )
        
    async def _test_update_mtu_and_admin_status_common(self, key_name: str) -> None:
        resp = await self.rest_request(
            "rest/v1/running/ports/Ethernet0", "PATCH",
            {"mtu": 1888, key_name: "up"}
        )
        print(resp.body.decode('utf-8'))
        self.assertEqual(resp.code, 200)
        redis = self.get_sync_redis(engine.RUNNING_CFG_DB_NUM)
        self.assertEqual(
            redis.hget("PORT|Ethernet0", "mtu"),
            "1888"
        )
        self.assertEqual(
            redis.hget("PORT|Ethernet0", "admin_status"),
            "up"
        )
    
    # The API do not distinguish "-" and "_". Both should be accepted in request body.
    async def test_update_mtu_and_admin_status_hyphen(self) -> None:
        await self._test_update_mtu_and_admin_status_common("admin-status")
        
    async def test_update_mtu_and_admin_status_underscore(self) -> None:
        await self._test_update_mtu_and_admin_status_common("admin_status")
        
    async def test_update_with_extra_key(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/ports/Ethernet0", "PATCH",
            {"mtu": 1888, "invalid_key": "..."}
        )
        self.assertEqual(resp.code, 400)
        self.assertDictEqual(json.loads(resp.body.decode('utf-8')), {
            "errors": [{
                "message": "Got following extra fields in request: ['invalid_key']",
                "error_tag": "request.validation_error.extra_field",
                "data": {"fields": ['invalid_key']}
            }]
        })
        
    async def test_update_mtu_and_admin_status_by_cmd(self) -> None:
        stdout, stderr = await self.cli_command(
            ["configure", "ethernet-port 0", "mtu 1777", "no shutdown"]
        )
        self.assertNotIn('error', stdout.lower())
        self.assertNotIn('error', stderr.lower())
        redis = self.get_sync_redis(engine.RUNNING_CFG_DB_NUM)
        self.assertEqual(
            redis.hget("PORT|Ethernet0", "mtu"),
            "1777"
        )
        self.assertEqual(
            redis.hget("PORT|Ethernet0", "admin_status"),
            "up"
        )
        
    async def test_shutdown_by_cmd_via_websocket(self) -> None:
        sock = await websocket_connect(HTTPRequest("wss://localhost:8088/websocket/cli", validate_cert=False))
        await sock.write_message(json.dumps({
            "user": "zxy", "cli": "sonic-cli"
        }))
        await sock.write_message('\n'.join([
            "configure", "ethernet-port 64", "shutdown", "exit", "exit", "exit"
            ]) + '\n'
        )
        
        async def _read_msg():
            while msg := await sock.read_message():
                print(msg)
        
        await asyncio.wait_for(_read_msg(), 3)
        sock.close()
        redis = self.get_sync_redis(engine.RUNNING_CFG_DB_NUM)
        self.assertEqual(
            redis.hget("PORT|Ethernet64", "admin_status"),
            "down"
        )
        
    async def test_update_port_not_exist(self) -> None:
        resp = await self.rest_request(
            "rest/v1/running/ports/Ethernet999", "PATCH",
            {"speed": 10000}
        )
        self.assertEqual(json.loads(resp.body.decode())['errors'][0]['error_tag'], 'app.not_found')
        self.assertEqual(resp.code, 404)
        
    async def test_update_port_not_exist_by_cmd(self) -> None:
        stdout, _ = await self.cli_command(
            ["configure", "ethernet-port 9999", "mtu 1777"]
        )
        self.assertNotIn('(eth-port)', stdout)
        # Make sure that Klish does not enter port view if port number is invalid
        self.assertIn("port not found: name=Ethernet999", stdout)

    async def test_dump_config(self) -> None:
        resp = await self.rest_request("rest/v1/operational/", "GET")
        result = json.loads(resp.body.decode('utf-8'))
        self.assertCountEqual(result["ports"], [
            {
                "name": "Ethernet0",
                "index": 0,
                "lanes": [113],
                "mtu": 9216,
                "admin-status": "down",
                "speed": 25000,
            },
            {
                "name": "Ethernet64",
                "index": 52,
                "lanes": [9, 10, 11, 12],
                "mtu": 9216,
                "admin-status": "up",
                "speed": 100000,
            }
        ])
        
    async def test_dump_running_config(self) -> None:
        resp = await self.rest_request("rest/v1/running/", "GET")
        result = json.loads(resp.body.decode('utf-8'))
        self.assertCountEqual(result["ports"], [
            {
                "name": "Ethernet0",
                "admin-status": "down",
            },
            {
                "name": "Ethernet64",
            }
        ])
        
    async def test_dump_running_config_command(self) -> None:
        await self.rest_request(
            "rest/v1/running/ports/Ethernet0", "PATCH",
            {"speed": 10000, "mtu": 3333}
        )
        await self.rest_request(
            "rest/v1/running/ports/Ethernet64", "PATCH",
            {"speed": 25000, "mtu": 2222}
        )
        stdout, stderr = await self.cli_command(['show running-config'])
        print(stdout)
        self.assertEqual(stdout.strip(), """
sonic-cli# show running-config
ethernet-port 0
  mtu 3333
  shutdown
  speed 10000
  exit
ethernet-port 64
  mtu 2222
  speed 25000
  exit
        """.strip())
        self.assertNotIn('err', stderr)
        
    async def test_gnmi_capability(self) -> None:
        async with self.grpc_channel() as channel:
            stub = gNMIStub(channel)
            result: CapabilityResponse = await stub.Capabilities(CapabilityRequest(extension=[]))
            self.assertEqual(result.gNMI_version, "0.10.0")
            expected = [
                ModelData(name="asternos-port", organization="AsterNOS", version="v1"),
            ]
            for item in expected:
                self.assertIn(item, result.supported_models)
            
    async def test_netconf_list_operational_config(self):
        async with self.netconf_session():
            result = await self.netconf_get_config("operational", """
<filter type="subtree">
    <top xmlns="http://www.asterfusion.com/asternos-schema/1.0/config">
        <ports/>
    </top>
</filter>
            """)
        self.assert_xml_equal(result, """
<data><top>
    <ports>
        <port>
            <name>Ethernet0</name>
            <index>0</index>
            <lanes>113</lanes>
            <mtu>9216</mtu>
            <admin-status>down</admin-status>
            <speed>25000</speed>
        </port>
        <port>
            <name>Ethernet64</name>
            <index>52</index>
            <lanes>9</lanes>
            <lanes>10</lanes>
            <lanes>11</lanes>
            <lanes>12</lanes>
            <mtu>9216</mtu>
            <admin-status>up</admin-status>
            <speed>100000</speed>
        </port>
    </ports>
</top></data>               
        """)
        
    async def test_netconf_list_operational_config_filter_port(self):
        async with self.netconf_session():
            result = await self.netconf_get_config("operational", """
<filter type="subtree">
    <top xmlns="http://www.asterfusion.com/asternos-schema/1.0/config">
        <ports>
            <port>
                <name>Ethernet0</name>
            </port>
        </ports>
    </top>
</filter>
            """)
        self.assert_xml_equal(result, """
<data><top>
    <ports>
        <port>
            <name>Ethernet0</name>
            <index>0</index>
            <lanes>113</lanes>
            <mtu>9216</mtu>
            <admin-status>down</admin-status>
            <speed>25000</speed>
        </port>
    </ports>
</top></data>               
        """)
        
    async def test_netconf_list_running_config_redundant_containment_node(self):
        async with self.netconf_session():
            result = await self.netconf_get_config("running", """
<filter type="subtree">
    <top> <!-- XML namespaces are not strictly required -->
        <ports>
            <port/> <!-- Redundant containment node -->
        </ports>
    </top>
</filter>
            """)
        self.assert_xml_equal(result, """
<data><top>
    <ports>
        <port>
            <name>Ethernet0</name>
            <admin-status>down</admin-status>
        </port>
        <port>
            <name>Ethernet64</name>
        </port>
    </ports>
</top></data>               
        """)
        
    async def test_netconf_get_bad_resource(self) -> None:
        async with self.netconf_session():
            with self.assertRaisesRegex(
                    NetconfRPCError, "Invalid subtree filter at tag foo-bar: tag foo-bar does not exist."):
                await self.netconf_get_config("running", """
<filter type="subtree">
    <top xmlns="http://www.asterfusion.com/asternos-schema/1.0/config">
        <foo-bar/>
    </top>
</filter>
                """)

    async def test_netconf_get_non_exist_object(self):
        async with self.netconf_session():
            result = await self.netconf_get_config("operational", """
<filter type="subtree">
    <top xmlns="http://www.asterfusion.com/asternos-schema/1.0/config">
        <ports>
            <port>
                <name>Ethernet888</name>
            </port>
        </ports>
    </top>
</filter>
            """)
        self.assert_xml_equal(result, """
<data><top>
    <ports/>
</top></data>               
        """)

    async def test_netconf_edit_port_status(self):
        async with self.netconf_session():
            await self.netconf_edit_config("running", """
<config>
    <top xmlns="http://www.asterfusion.com/asternos-schema/1.0/config">
        <ports operation="merge">
            <port>
                <name>Ethernet0</name>
                <admin-status>up</admin-status>
            </port>
        </ports>
    </top>
</config>
            """)
        self.assertEqual(
            await self.get_async_redis(engine.RUNNING_CFG_DB_NUM).hget("PORT|Ethernet0", "admin_status"),
            "up"
        )
