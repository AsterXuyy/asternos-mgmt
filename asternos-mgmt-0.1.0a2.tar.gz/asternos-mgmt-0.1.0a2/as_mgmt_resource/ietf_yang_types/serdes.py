import datetime
import functools
import uuid

from typing import Union

import as_mgmt


as_mgmt.add_type(
    datetime.datetime, 'ietf-yang-types:date-and-time',
    datetime.datetime.isoformat,
    datetime.datetime.fromisoformat,
    functools.partial(datetime.datetime.isoformat, sep=' '),
    datetime.datetime.fromisoformat
)


@as_mgmt.trivially_serializable('ietf-yang-types:mac-address')
class MacAddress:

    __slots__ = ['_mac']
    
    def __init__(self, mac: Union[str, int]):
        if isinstance(mac, str):
            mac = int(''.join(mac.split(':')), 16)
        self._mac = mac

    def __str__(self):
        return ':'.join([
            f"{(self._mac >> i) & 0xFF:02x}".lower() for i in [40, 32, 24, 16, 8, 0]
        ])

    def __int__(self):
        return self._mac

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, MacAddress):
            return NotImplemented
        return self._mac == other._mac

    def __hash__(self):
        return hash(self._mac)

    def __repr__(self):
        return f'MacAddress("{str(self)}")'


as_mgmt.add_type(
    uuid.UUID, 'ietf-yang-types:uuid',
    str, uuid.UUID,
    str, uuid.UUID,
)
