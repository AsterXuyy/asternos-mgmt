import datetime
from uuid import UUID

from as_mgmt.serdes import SerdesRegistry
from as_mgmt.test import LoadModulesTestBase

from .serdes import MacAddress


class TestYANGTypes(LoadModulesTestBase):
    
    def setUp(self) -> None:
        self.serdes = SerdesRegistry.instance()
        return super().setUp()
    
    def test_serialize_datetime_api(self) -> None:
        ser, _ = self.serdes.get_api_serdes('ietf-yang-types:date-and-time')
        self.assertEqual(
            ser(datetime.datetime(2023, 6, 19, 18, 22, 5, 888)),
            "2023-06-19T18:22:05.000888"
        )
        self.assertEqual(
            ser(datetime.datetime(2023, 6, 19, 18, 22, 5)),
            "2023-06-19T18:22:05"
        )
        
    def test_deserialize_datetime_api(self) -> None:
        _, des = self.serdes.get_api_serdes('ietf-yang-types:date-and-time')
        self.assertEqual(
            des("2023-06-19T18:22:05"),
            datetime.datetime(2023, 6, 19, 18, 22, 5)
        )
        self.assertEqual(
            des("2023-06-19 18:22:05"),
            datetime.datetime(2023, 6, 19, 18, 22, 5)
        )
        self.assertEqual(
            des("2023-06-19A18:22:05.888"),
            datetime.datetime(2023, 6, 19, 18, 22, 5, 888000)
        )
        self.assertEqual(
            des("2023-06-19A18:22:05.888987"),
            datetime.datetime(2023, 6, 19, 18, 22, 5, 888987)
        )
        
    def test_serialize_datetime_db(self) -> None:
        ser, _ = self.serdes.get_db_serdes(datetime.datetime)
        self.assertEqual(
            ser(datetime.datetime(2023, 6, 19, 18, 22, 5, 888)),
            "2023-06-19 18:22:05.000888"
        )
        self.assertEqual(
            ser(datetime.datetime(2023, 6, 19, 18, 22, 5)),
            "2023-06-19 18:22:05"
        )
        
    def test_deserialize_datetime_db(self) -> None:
        _, des = self.serdes.get_db_serdes(datetime.datetime)
        self.assertEqual(
            des("2023-06-19 18:22:05"),
            datetime.datetime(2023, 6, 19, 18, 22, 5)
        )
        
    def test_serialize_mac(self) -> None:
        ser, _ = self.serdes.get_api_serdes('ietf-yang-types:mac-address')
        self.assertEqual(
            ser(MacAddress(0xabcdef123456)),
            "ab:cd:ef:12:34:56"
        )
        ser, _ = self.serdes.get_db_serdes(MacAddress)
        self.assertEqual(
            ser(MacAddress(0xabcdef123456)),
            "ab:cd:ef:12:34:56"
        )
        
    def test_deserialize_mac(self) -> None:
        _, des = self.serdes.get_api_serdes('ietf-yang-types:mac-address')
        self.assertEqual(
            des("ab:cd:ef:12:34:56"),
            MacAddress(0xabcdef123456)
        )
        _, des = self.serdes.get_db_serdes(MacAddress)
        self.assertEqual(
            des("ab:cd:ef:12:34:56"),
            MacAddress(0xabcdef123456)
        )
        
    def test_serialize_uuid(self) -> None:
        ser, _ = self.serdes.get_api_serdes('ietf-yang-types:uuid')
        self.assertEqual(
            ser(UUID('4b8c8f70-6c47-439e-8a45-e6093afae5bd')),
            '4b8c8f70-6c47-439e-8a45-e6093afae5bd'
        )
        ser, _ = self.serdes.get_db_serdes(UUID)
        self.assertEqual(
            ser(UUID('4b8c8f70-6c47-439e-8a45-e6093afae5bd')),
            '4b8c8f70-6c47-439e-8a45-e6093afae5bd'
        )
        
    def test_deserialize_uuid(self) -> None:
        _, des = self.serdes.get_api_serdes('ietf-yang-types:uuid')
        self.assertEqual(
            des('4b8c8f70-6c47-439e-8a45-e6093afae5bd'),
            UUID('4b8c8f70-6c47-439e-8a45-e6093afae5bd')
        )
        _, des = self.serdes.get_db_serdes(UUID)
        self.assertEqual(
            des('4b8c8f70-6c47-439e-8a45-e6093afae5bd'),
            UUID('4b8c8f70-6c47-439e-8a45-e6093afae5bd')
        )
