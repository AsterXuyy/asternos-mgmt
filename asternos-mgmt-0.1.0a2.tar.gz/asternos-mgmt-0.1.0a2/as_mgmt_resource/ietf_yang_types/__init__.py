from .serdes import MacAddress

__manifest__ = {
    "name": "ietf-yang-types",
    "description": "Definitions of IETF Standard YANG types and their (de)serialization methods.",
    "load_priority": 0,
    "require_feature": []
}
