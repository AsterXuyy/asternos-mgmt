__manifest__ = {
    "name": "ietf-inet-types",
    "description": "Definitions of IETF Standard Internet types and their (de)serialization methods.",
    "load_priority": 0,
    "require_feature": []
}
