__manifest__ = {
    "name": "vlan",
    "description": "VLAN resources",
    "load_priority": 150,
    "require_feature": []
}
