import { TranslationOutlined } from '@ant-design/icons';
import { setLocale } from '@umijs/max';
import type { MenuProps } from 'antd';
import { Dropdown } from 'antd';

interface LangProps {
  dropdown_placement: "topLeft" | "topCenter" | "topRight" | "bottomLeft" | 
                      "bottomCenter" | "bottomRight" | "top" | "bottom";
}

const languages: MenuProps['items'] = [{
  key: 'zh-CN',
  label: (<a>中文</a>)
}, {
  key: 'en-US',
  label: (<a>English</a>)
}]

const SwitchLanguage = (props: LangProps) => {

  const clickCb: MenuProps['onClick'] = ({ key }) => {
    setLocale(key, false);
  };

  return (
    <Dropdown menu={{items: languages, onClick: clickCb}} placement={props.dropdown_placement}>
      <a onClick={(e) => e.preventDefault()}>
       <TranslationOutlined style={{fontSize: "25px",}}/>
      </a>
    </Dropdown>
  )
}

export default SwitchLanguage;
