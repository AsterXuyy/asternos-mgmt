import { useEffect } from 'react';
import { Terminal } from 'xterm';
import { AttachAddon } from 'xterm-addon-attach';
import { FitAddon } from 'xterm-addon-fit';
import 'xterm/css/xterm.css';


interface Props {
    user_name: string;
    // name of the user to login command line.
    cli: string
    // currently support "bash" and "sonic-cli"(klish)
}

const CLITerminal: React.FC<Props> = (props) => {

    useEffect(() => {
        const socket = new WebSocket("wss://" + location.host + "/websocket/cli");
        console.log("Connecting to klish command line terminal");
        const terminal = new Terminal({
            theme: {
                background: '#ffffff',
                foreground: '#000000',
                cursor: "#000000",
                cursorAccent: "#000000",
                selectionForeground: "#ffffff",
                selectionBackground: "#000000"
            },
            cursorBlink: true,
            cursorStyle: "block",
            cols: 120,
            rows: 40,
        });
        socket.addEventListener("open", (_) => {
            socket.send(JSON.stringify({
                user: props.user_name,
                cli: props.cli
            }))
            const attachAddon = new AttachAddon(socket);
            const fitAddon = new FitAddon();
            terminal.loadAddon(fitAddon);
            terminal.loadAddon(attachAddon);
            const terminalDom = document.getElementById('terminal-container');
            if (terminalDom === null) {
                console.error("Failed to find 'terminal-container' element to render the terminal");
                return () => {
                    socket.close();
                    terminal.dispose();
                }
            }
            terminal.open(terminalDom)
        })
        return () => {
            if (socket.readyState === WebSocket.OPEN) {
                socket.close();
                terminal.dispose();
            }
        }
    }, []);

    return (<div id="terminal-container"></div>);
}

export default CLITerminal;
