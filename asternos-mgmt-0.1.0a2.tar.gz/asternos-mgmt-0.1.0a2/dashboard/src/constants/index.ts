export const DEFAULT_NAME = 'AsterNOS';
