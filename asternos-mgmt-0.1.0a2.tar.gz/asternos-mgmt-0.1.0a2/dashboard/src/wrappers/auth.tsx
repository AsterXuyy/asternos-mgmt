import { Navigate, Outlet } from '@umijs/max';
 
export default () => {
  const username = get_cookie("username");
  const singed_username = get_cookie("singed_username");
  if (username && singed_username) {
    return <Outlet />;
  } else{
    return <Navigate to="/login" />;
  }
}

function get_cookie(name: string): string {
  var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
  if (match) {
    return match[2];
  }
  else {
    return "";
  }
}
