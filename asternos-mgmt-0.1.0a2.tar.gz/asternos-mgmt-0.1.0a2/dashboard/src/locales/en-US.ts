export default {
  "login.keep_login": 'keep login',
  "login.password_login": 'Password Login',
  "login.username": "username",
  "login.password": "password",
  "login.action": "Login",
  "login.err.empty_username": "Please enter username",
  "login.err.empty_password": "Please enter password",
};
