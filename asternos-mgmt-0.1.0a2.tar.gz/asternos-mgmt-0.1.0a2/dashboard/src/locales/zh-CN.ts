export default {
  "login.keep_login": '自动登录',
  "login.password_login": '密码登录',
  "login.username": "用户名",
  "login.password": "密码",
  "login.action": "登录",
  "login.err.empty_username": "请输入用户名",
  "login.err.empty_password": "请输入密码",
};