import CLITerminal from '@/components/Terminal';
import { PageContainer } from '@ant-design/pro-components';

const TerminalPage: React.FC = () => {
  return (
    <PageContainer ghost>
      <CLITerminal user_name='zxy' cli='sonic-cli'></CLITerminal>
    </PageContainer>
  );
};

export default TerminalPage;
