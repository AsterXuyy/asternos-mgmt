import {
  LockOutlined,
  UserOutlined,
} from '@ant-design/icons';
import {
  ProFormCheckbox,
  ProFormText,
} from '@ant-design/pro-components';
import { Tabs, Button } from 'antd';
import { useState } from 'react';
import { ReactComponent as Logo } from '@/assets/asterfusion_logo.svg';
import SwitchLanguage from "@/components/Language";
import { FormattedMessage } from '@umijs/max';
import { useIntl } from '@umijs/max';

type LoginType = 'phone' | 'account';

export default () => {
  const intl = useIntl();
  const [loginType, setLoginType] = useState<LoginType>('account');
  return (
    <div
      style={{
        height: 'calc(100vh - 48px)',
        margin: -24,
      }}
    >
        <div style={{marginRight: "40%"}}></div>
        <div style={
          {width: "40%", float: "right", padding: "5%", backgroundColor: "white",  height: 'calc(100vh - 48px)'}
        }>
          <div style={{float: "right"}}>
            <SwitchLanguage dropdown_placement='bottomRight'/>
          </div>
          <div style={{textAlign: "center"}}><Logo style={{width: "30%",}}/></div>
          <h1 style={{textAlign: "center"}}>Asterfusion Network Operating System</h1>
          <Tabs
            centered
            activeKey={loginType}
            onChange={(activeKey) => setLoginType(activeKey as LoginType)}
          >
            <Tabs.TabPane key={'account'} tab={intl.formatMessage({id: "login.password_login"})} />
          </Tabs>
          {loginType === 'account' && (
            <>
              <ProFormText
                name="username"
                fieldProps={{
                  size: 'large',
                  prefix: <UserOutlined className={'prefixIcon'} />,
                }}
                placeholder={intl.formatMessage({id: "login.username"})}
                rules={[
                  {
                    required: true,
                    message: '请输入用户名!',
                  },
                ]}
              />
              <ProFormText.Password
                name="password"
                fieldProps={{
                  size: 'large',
                  prefix: <LockOutlined className={'prefixIcon'} />,
                }}
                placeholder={intl.formatMessage({id: "login.password"})}
                rules={[
                  {
                    required: true,
                    message: '请输入密码！',
                  },
                ]}
              />
            </>
          )}
          <div
            style={{
              marginBlockEnd: 24,
            }}
          >
            <ProFormCheckbox noStyle name="autoLogin">
              <FormattedMessage id="login.keep_login"/>
            </ProFormCheckbox>
          </div>
          <Button size='large' style={{width: "100%"}}>Login</Button>
        </div>
    </div>
  );
};
