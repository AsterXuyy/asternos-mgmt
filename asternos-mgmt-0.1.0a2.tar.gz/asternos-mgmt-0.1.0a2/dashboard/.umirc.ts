import { defineConfig } from '@umijs/max';

export default defineConfig({
  antd: {},
  access: {},
  model: {},
  initialState: {},
  request: {},
  layout: {
    title: 'AsterNOS',
  },
  base: '/ui',
  proxy: {
    // Proxy any request that dose NOT match /ui to backend server
    '/websocket': {
      'target': 'https://localhost:8080/',
      'changeOrigin': true,
      'secure': false,
      'ws': true,
    },
    '/rest': {
      'target': 'https://localhost:8080/',
      'changeOrigin': true,
      'secure': false,
    },
  },
  https: {
    "cert": "../as_mgmt/test/ca_cert/cert.pem",
    "key": "../as_mgmt/test/ca_cert/key.pem",
    "http2": false
  },
  routes: [
    {
      path: '/',
      redirect: '/home',
    },
    {
      name: 'Main Page',
      path: '/home',
      component: './Home',
      wrappers: ['@/wrappers/auth'],
    },
    {
      name: "Terminal",
      path: '/terminal',
      component: '@/pages/Terminal/index',
      wrappers: ['@/wrappers/auth'],
    },
    {
      path: '/login',
      component: '@/pages/Login/index',
      headerRender: false,
      footerRender: false,
      menuRender: false,
      menuHeaderRender: false,
    }
  ],
  locale: {
    default: 'en-US',
    baseSeparator: '-',
  },
  npmClient: 'pnpm',
});

