# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Project information -----------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#project-information
import os
import sys

project = 'asternos-mgmt'
copyright = '2023, Asterfusion'
author = 'Asterfusion'
release = '0.1'

# -- General configuration ---------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#general-configuration

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')
    ),
)
extensions: list[str] = ['as_mgmt_sphinx', 'sphinx_copybutton']

templates_path = ['_templates']
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']

smartquotes = False


# -- Options for HTML output -------------------------------------------------
# https://www.sphinx-doc.org/en/master/usage/configuration.html#options-for-html-output

html_theme = 'furo'
html_static_path = ['_static']


# -- Options for LaTeX output ------------------------------------------------

latex_elements = {
    # The paper size ('letterpaper' or 'a4paper').
    #
    'papersize': 'a4paper',
    'extraclassoptions': 'oneside',

    'preamble': r"""
    \usepackage{fancyhdr}
    \usepackage{ctex}
    \usepackage{xeCJK}
    \setCJKmainfont{Source Han Serif SC}
    \setCJKsansfont{Source Han Serif SC}
    \setmainfont{Noto Sans}
    \setsansfont{Noto Sans}
    \setmonofont{Noto Sans Mono}
    \usepackage{color}
    \makeatletter
      \fancypagestyle{normal}{
        \fancyhf{}
        \fancyfoot[L]{\small\textcolor[RGB]{30,80,160}{©2023 Asterfusion confidential. All rights reserved.}}
        \fancyfoot[R]{\small\textcolor[RGB]{30,80,160}{\thepage}}
        \fancyhead[L]{\small\textcolor[RGB]{30,80,160}{\includegraphics[scale=1.0]{../../asterfusion.png}}}
        \fancyhead[R]{\small\textcolor[RGB]{30,80,160}{Re-Engineering the Cloud Networks}}

        \setlength{\headheight}{19mm}
        \setlength{\topskip}{-10mm}
        \setlength{\topmargin}{-14mm}
        \setlength{\headsep}{4mm} 
        \setlength{\footskip}{6mm}
        \renewcommand{\headrulewidth}{0.4pt}
        \renewcommand{\headrule}{\hbox to\headwidth{%
            \textcolor[RGB]{30,80,160}{\leaders\hrule height \headrulewidth\hfill}}}
        \renewcommand{\footrulewidth}{0pt}

      }
      \fancypagestyle{plain}{
        \fancyhf{}
        \fancyfoot[L]{\small\textcolor[RGB]{30,80,160}{©2023 Asterfusion confidential. All rights reserved.}}
        \fancyfoot[R]{\small\textcolor[RGB]{30,80,160}{\thepage}}
        \fancyhead[L]{\small\textcolor[RGB]{30,80,160}{\includegraphics[scale=1.0]{../../asterfusion.png}}}
        \fancyhead[R]{\small\textcolor[RGB]{30,80,160}{Re-Engineering the Cloud Networks}}

        \setlength{\headheight}{19mm}
        \setlength{\topskip}{-10mm}
        \setlength{\topmargin}{-14mm}
        \setlength{\headsep}{4mm} 
        \setlength{\footskip}{6mm}
        \renewcommand{\headrulewidth}{0.4pt}
        \renewcommand{\headrule}{\hbox to\headwidth{%
            \textcolor[RGB]{30,80,160}{\leaders\hrule height \headrulewidth\hfill}}}
        \renewcommand{\footrulewidth}{0pt}
      }

      %modify sphinxmanual.cls

      \renewcommand*\sphinxmaketitle{%
       \let\sphinxrestorepageanchorsetting\relax
        \ifHy@pageanchor\def\sphinxrestorepageanchorsetting{\Hy@pageanchortrue}\fi
        \hypersetup{pageanchor=false}% avoid duplicate destination warnings
        \begin{titlepage}%
        \let\footnotesize\small
        \let\footnoterule\relax
        \noindent\rule{\textwidth}{1pt}\par
          \begingroup % for PDF information dictionary
           \def\endgraf{ }\def\and{\& }%
           \pdfstringdefDisableCommands{\def\\{, }}% overwrite hyperref setup
           \hypersetup{pdfauthor={\@author}, pdftitle={\@title}}%
          \endgroup
        \begin{flushright}%
        \vspace*{200pt}
          \sphinxlogo
          \py@HeaderFamily
          \begin{center}
          {\Huge \@title \par}
          {\itshape\LARGE \py@release\releaseinfo \par}
          {\LARGE
            \begin{tabular}[t]{c}
              \@author
            \end{tabular}\kern-\tabcolsep \par}
          {\large
           \@date \par
           \vfill
           \py@authoraddress \par
          }%
          \end{center}%
        \end{flushright}%\par
        \@thanks
      \end{titlepage}%
      \setcounter{footnote}{0}%
      \let\thanks\relax\let\maketitle\relax
      %\gdef\@thanks{}\gdef\@author{}\gdef\@title{}
      \clearpage
      \ifdefined\sphinxbackoftitlepage\sphinxbackoftitlepage\fi
      \if@openright\cleardoublepage\else\clearpage\fi
      \sphinxrestorepageanchorsetting
      }
        \renewcommand*\sphinxtableofcontents{%
            \begingroup
            \renewcommand{\contentsname}{Table of Contents}
            \tableofcontents
          \endgroup
        }



    \titleformat{\chapter}{\LARGE\py@HeaderFamily}%
            {\py@TitleColor\thechapter\,.}{0.5em}{\py@TitleColor}
    \makeatother
    
    \renewcommand{\quote}{\noindent}
    \usepackage{enumitem}
    \setlist[itemize]{leftmargin=*}
    \setlist[description]{leftmargin=1em}
""",

    # The font size ('10pt', '11pt' or '12pt').
    #
    'pointsize': '11pt',

    # Additional stuff for the LaTeX preamble.
    #
    # 'preamble': '',

    # Latex figure (float) alignment
    #
    # 'figure_align': 'htbp',
}

# Grouping the document tree into LaTeX files. List of tuples
# (source start file, target name, title,
#  author, documentclass [howto, manual, or own class]).
latex_documents: list = [
    ('index', 'as_mgmt.tex', "AsterNOS User Manual", '', 'manual'),
]

latex_engine = 'xelatex'
# xelatex supports UTF-8 encoded Chinese characters, while the default latex engine does not.

# -- Options for manual page output ------------------------------------------

# One entry per manual page. List of tuples
# (source start file, name, description, authors, manual section).
man_pages: list = [
    ('index', 'as_mgmt',  "AsterNOS User Manual", [], 1)
]

# -- Options for Texinfo output ----------------------------------------------

# Grouping the document tree into Texinfo files. List of tuples
# (source start file, target name, title, author,
#  dir menu entry, description, category)
texinfo_documents: list = [
    ('index', 'as_mgmt', project,
     author, 'as_mgmt', 'One line description of project.',
     'Miscellaneous'),
]

