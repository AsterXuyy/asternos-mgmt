AsterNOS Management User Manual
=========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   :glob:
   :numbered:

   resource/*



Indices and tables
==================

* :ref:`klish-cmdindex`
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
