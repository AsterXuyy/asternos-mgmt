"""
Run this script to build sphinx documents. 
To build PDF document, install these dependencies(ubuntu): 

   sudo apt install texlive texlive-lang-chinese texlive-xetex latexmk texlive-fonts-extra xindy

"""
import os
import subprocess

from as_mgmt.loader import ResourcePackageLoader

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))


def main():
    loader = ResourcePackageLoader([], [])
    loader.find_additional_modules()
    loader.load_modules()
    for name, content in loader.iter_content(lambda x: x.endswith('.rst') or x.endswith('.yang')):
        # YANG files are also copied because we may want to "literal include" them in the document.
        with open(os.path.join(PROJECT_ROOT, f"doc/resource/{name}"), 'wb') as fd:
            fd.write(content)
    
    os.chdir(os.path.join(PROJECT_ROOT, "doc"))   
    subprocess.Popen(["make", "clean"]).wait()
    subprocess.Popen(["make", "html", "latexpdf"]).wait()


if __name__ == "__main__":
    main()
