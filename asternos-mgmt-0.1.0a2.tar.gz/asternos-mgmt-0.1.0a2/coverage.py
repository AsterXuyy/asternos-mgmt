"""
Run pytest to get coverage report.
Program in this file intends to be called by vscode as defined by ".vscode/launch.json".
Otherwise, it has no extra effect than running converage tests maunally.
"""

import subprocess


if __name__ == "__main__":
    subprocess.run(
        ["pytest", "--cov=as_mgmt", "--cov=as_mgmt_resource",
         "--cov-report=term-missing:skip-covered", "--cov-report=xml:cov.xml"],
        check=True
    )
