import asyncio
from asyncio import FIRST_COMPLETED, Task
from typing import TypeVar, AsyncIterable, AsyncIterator, Generic, Optional, Union

_T = TypeVar('_T')


async def _next(itr: AsyncIterator[_T]) -> tuple[AsyncIterator[_T], Union[_T, StopAsyncIteration]]:
    try:
        result = await itr.__anext__()
    except StopAsyncIteration as err:
        return itr, err
    return itr, result


async def interleave(*aiterables: AsyncIterable[_T]) -> AsyncIterable[_T]:
    """
    Combine several async iterable objects, and yield a result once any of the async iterators is ready.
    Return when all async iterators are exhausted.
    """
    iterators = [item.__aiter__() for item in aiterables]
    pending = {asyncio.create_task(_next(item)) for item in iterators}
    while pending:
        done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
        for task in done:
            itr, result = task.result()
            if not isinstance(result, StopAsyncIteration):
                pending.add(asyncio.create_task(_next(itr)))
                yield result


class _Group(Generic[_T]):
    def __init__(self, aiterable: AsyncIterable[_T], time_span: float):
        self.iter = aiterable.__aiter__()
        self.time_span = time_span
        self._timeout_task: Optional[Task[None]] = None
        self._anext_task: Optional[Task[_T]] = None
        self._item: Optional[_T] = None
        self._finished = False

    def __aiter__(self):
        return self
    
    async def _next(self):
        return await self.iter.__anext__()
    
    async def __anext__(self):
        if self._finished:
            # Because we want to return the cached item when underlying iterator is exhausted,
            # We use this _finished flag to delay "stop iteration" to next iteration.
            raise StopAsyncIteration()
        while True:
            if self._anext_task is None:  # initial status.
                self._anext_task = asyncio.create_task(self._next())
            if self._timeout_task is None:  # wait for the first item before we start the timer.
                await self._anext_task
                self._item = self._anext_task.result()  # cache the item, the start waiting for timeout.
                self._timeout_task = asyncio.create_task(asyncio.sleep(self.time_span))
            elif self._timeout_task.done():  # timer timed out, return result/
                self._timeout_task = None
                return self._item
            else:
                done, _ = await asyncio.wait(
                    {self._anext_task, self._timeout_task}, return_when=FIRST_COMPLETED
                )
                if self._anext_task in done:
                    try:
                        result = self._anext_task.result()
                    except StopAsyncIteration:
                        self._finished = True
                        return self._item
                    self._anext_task = None
                    if result == self._item:
                        # in this branch, _timout_task might also be in 'done' state;
                        # if this is the case, the item will be returned in next loop.
                        continue
                    self._item, result = result, self._item
                    self._timeout_task = asyncio.create_task(asyncio.sleep(self.time_span))
                    return result
                # only waiting task done
                self._timeout_task = None
                return self._item


def group(aiterable: AsyncIterable[_T], timespan: float) -> AsyncIterable[_T]:
    """
    Eliminate consecutive duplicated items returned by a given iterator in a given timespan.
    Suitable for event processing.
    
    The iterated type must defines __eq__ method meaningfully or this function will not work.
    """
    return _Group(aiterable, timespan)
