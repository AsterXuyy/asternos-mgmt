import logging
import re
import os
from enum import Enum
from argparse import ArgumentParser, RawDescriptionHelpFormatter
from typing import Any, Iterable, Optional, Type, Union, Generic, TypeVar, Callable

import tomli
from typing_extensions import TypeAlias

from as_mgmt import _version

LOG = logging.getLogger(__name__)

_BasicOptType: TypeAlias = Union[int, float, str, bool]

T = TypeVar("T", bound=_BasicOptType)

_PRODUCT_INFO = [        
    "AsterNOS Management Framework",
    f"Version: v{_version.__version__}", 
    "© Copyright 2023, Asterfusion"
]


class Opt(Generic[T]):
    """
    Represents a config option.
    Implements of different modules should register their options
    as Opt instances to the "register" function(see below) to make them available to variable sources.
    """
    
    _valid_name_pattern = r'^[a-z_]+$'
    
    section: str
    # Category of this option, used in .ini or .toml config files
    
    name: str
    # Name of the Option.
    # This SHOULD be a string with only lower-case letters and '_'
    # The name match procedure is case insensitive.
    # This is compatible for various config source, take "redis-url" as an example:
    # 1. In .ini/.toml config file, use redis_url=...
    # 2. In command line option, use --redis-url=...
    # 3. In environment variables, use MGMT_REDIS_URL=...
    #    (MGMT_ prefix is prepended to all config files to avoid name conflict.)
    # 4. When used programmatically(by "set_option" function, see below),
    #    use "redis_url": ..., which is a valid python 
    # The priorities of these methods are(see "setup_config" function below)
    #    command options > environment variable > config file
    
    type: Type[T]
    # Type of the option, used to convert type and verify.
    # Possible types are:
    # 1. int, float, str, or Enum types constructed with these types.
    # 2. boolean
    
    help: str
    # Help string, displayed when using '-h' or '--help' option.
    
    default: Optional[T]
    # Default value of this option, if not specified.
    # A boolean options MUST have "False" as its default value.
    # (Required by command line parsing logic, where the presence of an option means true.)
    # NOTE: Most options SHOULD have a default value.
    #       If a value without default is not specified by any means,
    #       an AttributeError is raised when trying to access such option.
    
    verifier: Optional[Callable[[T], Optional[T]]]
    # An extra verifier function.
    # This function should raise an error if validation failed and may return:
    # 1. None, indicate using the original value.
    # 2. Another value to use instead of the original one.
    #    In this case, the verifier also acts as a transformer.
    
    cmd_abbr: Optional[str]
    # This field, if specified, MUST be a single lower case letter.
    # It is used as the short option name in command line options.
    # e.g. 'a' will add a "-a" option to command line.

    __slots__ = ('section', 'name', 'type', 'help', 'default', 'verifier', 'cmd_abbr')
    
    def __init__(self, section: str, name: str, type_: Type[T], help_: str, *, 
                 default: Optional[T] = None, verifier: Optional[Callable[[T], Optional[T]]] = None, 
                 cmd_abbr: Optional[str] = None) -> None:
        self.section = section
        self.name = name
        self.type = type_
        self.help = help_
        self.default = default
        self.verifier = verifier
        self.cmd_abbr = cmd_abbr
        if not re.match(self._valid_name_pattern, name):
            raise ValueError("Invalid option name. Names should only contain lower case letters and '_'")
        if not re.match(self._valid_name_pattern, section):
            raise ValueError("Invalid section name. Names should only contain lower case letters and '_'")
        if name in ['help', 'config_file', 'version'] or cmd_abbr in ['h', 'f', 'v']:
            raise ValueError("Can not use reserved names")
        if cmd_abbr:
            if len(cmd_abbr) != 1 or not cmd_abbr.islower():
                raise ValueError("Invalid command line abbreviated option name")
        
    def __hash__(self) -> int:
        return hash(self.name)
    
    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, Opt):
            return NotImplemented
        # This should be enough because we disallow multiple options with the same name
        return self.name == other.name
    
    @property
    def full_name(self) -> str:
        if not self.section:
            return self.name
        return f"{self.section}_{self.name}"


_env_opts: dict[str, Opt] = {}
_cfg_opts: dict[str, Opt] = {}
_opt_vals: dict[str, Any] = {}


def _get_parser():
    parser = ArgumentParser(
        description='\n'.join(_PRODUCT_INFO + [
            "",
            "Options may be specified in one of the following ways, with descending priority:",
            "1. By options specified here.",
            "2. By using environment variables, replacing '-' with '_', converting to upper case and ",
            "   adding \"MGMT_\" prefix. (e.g. \"--redis-url\" becomes \"MGMT_REDIS_URL\")",
            "3. By a configuration file specified by the -f(--config-file) option.",
            "   Please refer to the document for config file format.",
        ]),
        formatter_class=RawDescriptionHelpFormatter
    )
    parser.add_argument('-f', '--config-file', nargs=1, help="Location of the config file")
    parser.add_argument('-v', '--version', help="Show program version and exit",
                        action="version", version='\n'.join(_PRODUCT_INFO))
    return parser
    
_parser = _get_parser()


class _Section:
    
    __slots__ = ('_section', )
    
    def __init__(self, section: str):
        self._section = section
        
    def __getattr__(self, name: str) -> Any:
        if f"{self._section}_{name}" not in _opt_vals:
            if f"{self._section}_{name}" not in _cfg_opts:
                raise AttributeError(f"Unknown config option {self._section}.{name}") 
            raise AttributeError(f"Unspecified config option {self._section}.{name}")
        return _opt_vals[f"{self._section}_{name}"]


class _Config:
    
    def __getattr__(self, name: str) -> _Section:
        if name in _opt_vals:  # options without section
            return _opt_vals[name]
        return _Section(name)
    
    
cfg = _Config()
# "singleton" holding config options
# Users of this module should import this variable and access config values like this:
# cfg.<section>.<name>  (e.g. cfg.db.redis_url)


def _register_cmd_opt(opt: Opt):
    names = [f"--{opt.full_name.lower().replace('_', '-')}"]
    if opt.cmd_abbr:
        names.append(f"-{opt.cmd_abbr}")
    if opt.type is bool:
        kwargs: dict[str, Any] = {'action': 'store_true'}
    else:
        kwargs = {'nargs': 1}
    kwargs['help'] = opt.help
    if opt.default:
        kwargs["default"] = opt.default
    # TODO: Support list types such as list[int], list[str]
    if issubclass(opt.type, Enum):
        values = list(opt.type.__members__.values())
        kwargs["type"] = type(values[0])
        # We require all enum members to have the same type.
        kwargs["choices"] = values
    elif opt.type is not bool:
        kwargs["type"] = opt.type
    _parser.add_argument(*names, **kwargs)


def register_opt(opts: Iterable[Opt]):
    """
    Add some options to
    Typical usage in an application module:
    >>> register_opt([
    ...     Opt('db', 'redis_url', str, 'Redis URL for connections', default='redis://localhost:6379'),
    ...     Opt('...')
    ... ])
    These codes should appear as toplevel module code(not inside functions/methods),
    and will then get executed before main() is called.
    """
    for opt in opts:
        full_name = opt.full_name
        if full_name in _cfg_opts:
            raise ValueError(f"Duplicated option name(with section): {full_name}")
        
        # "--" prefix is stripped by arg parser, thus do not appear here.
        environ_name = f"MGMT_{full_name.upper()}"
        _env_opts[environ_name] = opt
        _cfg_opts[full_name] = opt
        _register_cmd_opt(opt)
        if opt.default is not None:
            _opt_vals[opt.full_name] = opt.default
        

def _handle_cfg_opt(opt_kv: dict[str, Any], prefix: str = ""):
    for key, value in opt_kv.items():
        if isinstance(value, dict):
            _handle_cfg_opt(value, key)
            continue
        opt = _cfg_opts[f"{prefix}_{key}"]
        typed_value = opt.type(value)
        if opt.verifier:
            typed_value = opt.verifier(typed_value) or typed_value
        _opt_vals[opt.full_name] = typed_value
        

def _handle_cmd_opt(opt_kv: dict[str, Any]):
    for key, value in opt_kv.items():
        if key == 'config_file':
            continue
        if value is None:
            continue
        opt = _cfg_opts[key]
        typed_value = opt.type(value[0] if isinstance(value, list) else value)
        if opt.verifier:
            typed_value = opt.verifier(typed_value) or typed_value
        _opt_vals[opt.full_name] = typed_value


def _handle_env_opt():
    for key, value in os.environ.items():
        if key in _env_opts:
            opt = _env_opts[key]
            typed_value = opt.type(value)
            if opt.verifier:
                typed_value = opt.verifier(typed_value) or typed_value
            _opt_vals[opt.full_name] = typed_value


def setup_config():
    """
    Setup config with the following priority:
    command options > environment variable > config file
    This method SHOULD be called before running any application tools.
    """
    argv_opts = vars(_parser.parse_args())
    cfg_opts: dict[str, Any] = {}
    if "config_file" in argv_opts and argv_opts['config_file'] is not None:
        cfg_file = argv_opts["config_file"]
        try: 
            with open(cfg_file[0], 'rb') as fd:
                cfg_opts = tomli.load(fd)
        except OSError as err:
            print(f"Failed to read config from file {cfg_file}, {type(err).__name__}: {str(err)}")
    
    _handle_cfg_opt(cfg_opts)
    _handle_env_opt()
    _handle_cmd_opt(argv_opts)


def set_option(section: str, name: str, value: Any):
    """
    Forcefully override the value of an option.
    Typically used by tests.
    """
    if not section:
        _opt_vals[name] = value
    else:
        _opt_vals[f"{section}_{name}"] = value


# Util functions for unit test cases.
def reset_config() -> tuple[dict, dict, dict, ArgumentParser]:
    global _env_opts, _cfg_opts, _opt_vals, _parser   # pylint: disable=global-statement
    backed = (_env_opts, _cfg_opts, _opt_vals, _parser)
    _env_opts = {}
    _cfg_opts = {}
    _opt_vals = {}
    _parser = _get_parser()
    return backed


def restore_config(backup: tuple[dict, dict, dict, ArgumentParser]) -> None:
    global _env_opts, _cfg_opts, _opt_vals, _parser   # pylint: disable=global-statement
    _env_opts, _cfg_opts, _opt_vals, _parser = backup
    