import os
from asyncio import Future

from grpc import ssl_server_credentials
from grpc.aio import ServicerContext, Server
from grpc.aio import server as grpc_server_factory

from as_mgmt.app.registry import ModuleMetadata
from as_mgmt.config import cfg, register_opt, Opt
from as_mgmt.http.request import CA_FALLBACK_LOCATION
from as_mgmt.app.proto_server import (
    AbstractProtoServer, AbstractProtoClient, Notification, RequestID, Response
)
from as_mgmt.exc import GrpcRespCode

from .gnmi.gnmi_pb2_grpc import gNMIServicer, add_gNMIServicer_to_server
from .gnmi.gnmi_pb2 import (  # pylint: disable=no-name-in-module
    CapabilityRequest, CapabilityResponse, ModelData
)


register_opt([
    Opt("gnmi", "ca_cert", str, "Path to the server TLS certificate for gNMI."
        "Note that a fallback self-signed certificate is used if not specified, "
        "and unencrypted HTTP is not supported due to security concerns.",
        default=os.path.join(CA_FALLBACK_LOCATION, 'cert.pem')),
    Opt("gnmi", "ca_key", str, "Path to the server TLS certificate key for gNMI.",
        default=os.path.join(CA_FALLBACK_LOCATION, 'key.pem')),
    Opt("gnmi", "address", str, "Local IP address for gNMI Server to listen on",
        default='0.0.0.0'),
    Opt("gnmi", "port", int, "TCP Port to accept gNMI gRPC connections, defaults to 6030", default=6030),
])


class NMIProtoClient(AbstractProtoClient):
    _resp_futures: dict[RequestID, Future[tuple[dict, GrpcRespCode]]]
    
    def __init__(self, server: AbstractProtoServer):
        self._server = server
        self._client_id = self._server.add_client(self)
        self._resp_futures = {}
        
    def response_callback(self, response: Response):
        ...
        
    def notification_callback(self, notification: Notification):
        ...
    
    def get_capability(self) -> list[ModuleMetadata]:
        return self._server.capability()
    

class GNMIServicerImpl(gNMIServicer):
    
    def __init__(self, client: NMIProtoClient):
        self._client = client
    
    async def Capabilities(self,  # pylint: disable=invalid-overridden-method
                           request: CapabilityRequest, 
                           context: ServicerContext) -> CapabilityResponse:
        models = self._client.get_capability()
        resp = CapabilityResponse(
            supported_models=[
                ModelData(
                    name=model.name, 
                    organization=model.organization, 
                    version=model.version
                ) for model in models
            ],
            supported_encodings=['JSON'],  # TODO: add support for JSON_IETF
            gNMI_version="0.10.0",
            extension=[]
        )
        return resp


def make_grpc_server(proto_server: AbstractProtoServer) -> Server:
    proto_client = NMIProtoClient(proto_server)
    grpc_server = grpc_server_factory(options=[
        ('grpc.so_reuseport', 1)
    ])
    add_gNMIServicer_to_server(GNMIServicerImpl(proto_client), grpc_server)
    with open(cfg.gnmi.ca_key, 'rb') as fd:
        tls_key = fd.read()
    with open(cfg.http.ca_cert, 'rb') as fd:
        tls_cert = fd.read()
    grpc_server.add_secure_port(
        f"[{cfg.gnmi.address}]:{cfg.gnmi.port}" if ':' in cfg.gnmi.address else f"{cfg.gnmi.address}:{cfg.gnmi.port}",
        # IPv6 or IPv4
        ssl_server_credentials(
            [(tls_key, tls_cert)],
            require_client_auth=False
            # TODO: Add support for client auth, which is required by gNMI client.
        )
    )
    return grpc_server
