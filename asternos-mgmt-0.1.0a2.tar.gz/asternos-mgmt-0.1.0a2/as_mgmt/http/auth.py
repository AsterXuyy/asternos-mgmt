import asyncio
import json
import pam

from tornado.web import RequestHandler

from as_mgmt.config import cfg, register_opt, Opt


register_opt([
    Opt('http', 'disable_auth', bool, default=False,
        help_="Disable all authentication and authorization procedure."),
    Opt('http', 'cookie_sign_key', str,
        help_="A secret key used to sign user session cookies. "
             "If not specified, a random key is generated at startup, "
             "which means user login status is lost each time the service restarts.",
        default="")
])


class LoginHandler(RequestHandler):
    
    async def post(self):
        try:
            body = json.loads(self.request.body.decode("utf-8"))
        except ValueError as err:
            self.set_status(400)
            self.write({"errors": [
                {"error_tag": "http.bad_body",
                 "message": f"Failed to decode request body as json: {err}",
                 "data": {}}
            ]})
            return
        try:
            username = body['username']
            password = body['password']
        except KeyError as err:
            self.set_status(400)
            self.write({"errors": [
                {"error_tag": "http.bad_auth_format",
                 "message": f"Missing mandatory field in authentication request: {err}",
                 "data": {}}
            ]})
            return
        keep_login = bool(body.get('keep_login', False))
        success = await asyncio.get_event_loop().run_in_executor(
            None, pam.authenticate, username, password
        )
        if not success:
            self.set_status(403)
            self.write({"errors": [
                {"error_tag": "http.invalid_credential",
                 "message": f"Login failed due to invalid username or password",
                 "data": {}}
            ]})
            return
        self.set_signed_cookie("signed_username", username, expires_days=(15 if keep_login else 0))
        self.set_cookie("username", username, expires_days=(15 if keep_login else 0))
