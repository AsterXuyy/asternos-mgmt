import json
import logging
import ssl
import secrets
import os
from asyncio import Future
from typing import Awaitable, Optional, Sequence
from uuid import UUID, uuid4

from tornado.web import RequestHandler, Application, StaticFileHandler

from as_mgmt import exc
from as_mgmt.app.registry import PathParseError
from as_mgmt.config import cfg, register_opt, Opt
from as_mgmt.app.proto_server import (
    AbstractProtoServer, AbstractProtoClient, Notification, Request, RequestContext,
    Action, UserClientID, RequestID, Response
)
from as_mgmt.http.auth import LoginHandler
from as_mgmt.http.websocket import CLIWebsocketHandler

LOG = logging.getLogger(__name__)


CA_FALLBACK_LOCATION = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    '../test/ca_cert'
)

_STATIC_FILE_DEFAULT_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    '../static'
)

register_opt([
    Opt("http", "ca_cert", str, "Path to the HTTPS certificate. "
        "Note that a fallback self-signed certificate is used if not specified, "
        "and unencrypted HTTP is not supported due to security concerns.",
        default=os.path.join(CA_FALLBACK_LOCATION, 'cert.pem')),
    Opt("http", "ca_key", str, "Path to the HTTPS certificate key",
        default=os.path.join(CA_FALLBACK_LOCATION, 'key.pem')),
    Opt("http", "address", str, "Local IP address for HTTP Server"
        "(used by REST/WebUI/RESTCONF) to listen on",
        default='0.0.0.0'),
    Opt("http", "port", int, "TCP Port to accept HTTP connections, defaults to 443", default=443),
    
    Opt("http", "frontend_path", str, "A local path to serve frontend static files.",
        default=_STATIC_FILE_DEFAULT_PATH),
    Opt("http", "frontend_disable", bool, "Disable WebUI dashboard", default=False)
])


class HttpProtoClient(AbstractProtoClient):
    _resp_futures: dict[RequestID, Future[tuple[dict, int]]]
    
    def __init__(self, server: AbstractProtoServer):
        self._server = server
        self._client_id = self._server.add_client(self)
        self._resp_futures = {}
        
    def _convert_exception(self, exceptions: Sequence[Exception]) -> tuple[list[dict], int]:
        result = []
        for exception in exceptions:
            if isinstance(exception, exc.MgmtBaseException):
                result.append(exception.format_http_resp())
            else:
                result.append({"msg": str(exception)})
        if isinstance(exceptions[0], exc.MgmtBaseException):
            code = exceptions[0].http_status_code
        else:
            code = 500
        return result, code
    
    def response_callback(self, response: Response):
        assert isinstance(response, Response)
        request_id = response.request_id
        if response.exceptions:
            converted, code = self._convert_exception(response.exceptions)
            self._resp_futures[request_id].set_result(
                ({"errors": converted}, code)
            )
        else:
            self._resp_futures[request_id].set_result(
                (response.body, 200)
            )
        self._resp_futures.pop(request_id)
        
    def notification_callback(self, notification: Notification):
        raise RuntimeError("Notifications are not supported by REST API")
    
    async def send_request(self, request_uuid: UUID, datastore: str, 
                           path: str, action: Action, body: dict) -> tuple[dict, int]:
        try:
            parsed_path = self._server.parse_rest_path(path)
        except PathParseError:
            return {'errors': [{
                'error_tag': 'request.invalid_path',
                'message': f"Path {path} not found",
                'data': {
                    "path": path
                }
            }]}, 404
        request = Request(
            self._client_id, UserClientID(""), RequestID(str(request_uuid)),
            RequestContext(), datastore, parsed_path,
            action, body
        )
        future: Future[tuple[dict, int]] = Future()
        self._resp_futures[request.request_id] = future
        self._server.add_request(request)
        return await future


class CommonHandler(RequestHandler):  # pylint: disable=abstract-method
    
    def get_current_user(self):
        if cfg.http.disable_auth:
            return "__stub_user__"
        return self.get_signed_cookie("username")
    
    def initialize(self, proto_client: HttpProtoClient) -> None:
        self._proto_client = proto_client
        self._request_uuid = uuid4()
        
    def _load_body(self) -> Optional[dict]:
        if not self.request.body:
            return {}  # placeholder for GET/DELETE requests
        if not self.request.headers['Content-Type'].startswith("application/json"):
            self.set_status(400)
            self.write({"errors": [
                {"error_tag": "http.bad_content_type",
                 "message": "Unsupported request content type, expected application/json; charset=utf-8",
                 "data": {}}
            ]})
            return None
        try:
            return json.loads(self.request.body.decode("utf-8"))
        except ValueError as err:
            self.set_status(400)
            self.write({"errors": [
                {"error_tag": "http.bad_body",
                 "message": f"Failed to decode request body as json: {err}",
                 "data": {}}
            ]})
            return None
        
    async def _handle(self, datastore: str, path: str, action: Action):
        if not self.current_user:
            self.set_status(401)
            self.write({"errors": [
                {"error_tag": "http.not_authenticated",
                 "message": "Login required",
                 "data": {}}
            ]})
            return None
        self.set_header('X-Request-Id', str(self._request_uuid))
        self.set_header('Content-Type', "application/json")
        body = self._load_body()
        if body is None:  # error
            return    
        result, code = await self._proto_client.send_request(
            self._request_uuid, datastore, path,
            action, body
        )
        self.set_status(code)
        self.write(result)
        
    def get(self, datastore: str, path: str) -> Awaitable[None]:
        return self._handle(datastore, path, Action.GET)
        
    def post(self, datastore: str, path: str) -> Awaitable[None]:
        return self._handle(datastore, path, Action.CREATE)
        
    def put(self, datastore: str, path: str) -> Awaitable[None]:
        return self._handle(datastore, path, Action.REPLACE)
        
    def delete(self, datastore: str, path: str) -> Awaitable[None]:
        return self._handle(datastore, path, Action.DELETE)
    
    async def patch(self, datastore: str, path: str):
        body = json.loads(self.request.body.decode("utf-8"))
        if isinstance(body, dict):
            await self._handle(datastore, path, Action.MERGE)
        elif isinstance(body, list):
            self.set_status(400)
            self.write("List request body not implemented") 
        else:
            assert False
            

class RootHandler(RequestHandler):  # pylint: disable=abstract-method
    
    def get_current_user(self):
        return self.get_signed_cookie("username")
    
    async def get(self):
        if not self.current_user:
            self.redirect('/ui/login')
        else:
            self.redirect('/ui')
        
        
def make_app(server: AbstractProtoServer):
    proto_client = HttpProtoClient(server)
    handlers = [
        (r"/rest/v1/([a-zA-Z]+)/(.*)", CommonHandler, {'proto_client': proto_client}),
        (r"/websocket/cli", CLIWebsocketHandler, {}),
        (r"/rest/login", LoginHandler),
        (r"/", RootHandler, {}),
    ]
    if not cfg.http.frontend_disable:
        handlers.append(('/ui', StaticFileHandler, {'path': cfg.http.frontend_path})) 
    return Application(
        handlers,  # type: ignore[arg-type]
        cookie_secret=cfg.http.cookie_sign_key or secrets.token_urlsafe(128)
    )  
    

def create_ssl_context():
    ssl_ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ssl_ctx.load_cert_chain(cfg.http.ca_cert, cfg.http.ca_key)
    return ssl_ctx
    