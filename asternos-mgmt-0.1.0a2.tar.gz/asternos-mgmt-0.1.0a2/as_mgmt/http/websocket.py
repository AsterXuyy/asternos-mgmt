import asyncio
import logging
import json
import os
import pty
import pwd
import shutil
import sys

from asyncio import subprocess, Task, create_task
from typing import Awaitable, Callable, Optional, Union

from tornado.websocket import WebSocketHandler

LOG = logging.getLogger(__name__)


class CLIProxy:
    
    def __init__(self, user: str, cmd: str, 
                 write_msg_callback: Callable[[bytes], Union[None, Awaitable[None]]],
                 close_cb: Callable[[], None]):
        self.user = user
        self._proc: Optional[subprocess.Process] = None
        self._cmd = cmd
        self._write_cb = write_msg_callback
        self._close_cb = close_cb
        self._task: Optional[Task] = None
        self._master_fd = -1
        
    async def start(self):
        if pwd.getpwnam(self.user).pw_uid == os.getuid():
            cmd = self._cmd
        else:
            cmd = f"sudo -u {self.user} {self._cmd}"
        # Because websocket does not transmit stdout and stderr separately,
        # we simply merge them to make things simpler.
        py_version_parts = sys.version.split('.')
        py_version = f"{py_version_parts[0]}.{py_version_parts[1]}"
        self._master_fd, slave_fd = pty.openpty()
        os.set_blocking(self._master_fd, False)
        
        self._proc = await subprocess.create_subprocess_shell(
            cmd, 
            stdin=slave_fd, stdout=slave_fd, stderr=slave_fd,
            env={
                "LD_LIBRARY_PATH": "/usr/local/lib",
                "LD_PRELOAD": f"/usr/lib/x86_64-linux-gnu/libpython{py_version}.so"
            }
            # Use LD_LIBRARY_PATH to add /usr/local/lib, where libraries of klish python plugin
            # resides when klish is installed with "make install" command.
            # This path is not searched by LD dynamic linker by default.
            # Use LD_PRELOAD to force change python version used by klish.
            # Note:
            # 1. Klish must be built with python limited API for stable ABI(which is the default).
            #    https://docs.python.org/3/c-api/stable.html
            # 2. This is ONLY FOR TEST PURPOSE.
            #    It does not work in production due to linux security context,
            #    which makes setuid programs ignore LD_PRELOAD.
            #    https://www.man7.org/linux/man-pages/man8/ld.so.8.html#ENVIRONMENT
        )
        self._task = create_task(self._read_output_and_send())
    
    async def _read_output_and_send(self) -> None:
        os.set_blocking(self._master_fd, False)
        finished_event = asyncio.Event()
        
        def _transmit():
            data = os.read(self._master_fd, 1024)
            if not data:
                finished_event.set()
            else:
                self._write_cb(data)
        
        loop = asyncio.get_event_loop()
        loop.add_reader(self._master_fd, _transmit)
        assert self._proc is not None
        await self._proc.wait()
        self._proc = None
        loop.remove_reader(self._master_fd)
        self._write_cb(b"Klish shell exited. Refresh the page to start a new session.")
        self._close_cb()
        
    async def write_input(self, data: bytes) -> None:
        os.write(self._master_fd, data)
        
    def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
        if self._proc is not None:
            self._proc.terminate()
        
    
class CLIWebsocketHandler(WebSocketHandler):
    
    async def open(self, *_, **__) -> None:
        self._user: str = ""
        self._proxy: Optional[CLIProxy] = None
        self.write_message("Connecting to command line...\r\n")
        
    async def _handle_first_message(self, message: Union[str, bytes]) -> None:
        # The first message sent by the client should be a json encoded dict
        # containing user identity and credential.
        try:
            cred = json.loads(message)
        except ValueError:
            self.write_message("The first message sent by the client must be a json encoded dict"
                               "containing user identity and credential.")
            return
        if not isinstance(cred, dict):
            self.write_message("The first message sent by the client must be a json encoded dict"
                   "containing user identity and credential.")
            return
        if 'user' not in cred:
            self.write_message("Missing user name in the given message.")
            return
        try:
            pwd.getpwnam(cred['user'])
        except KeyError:
            self.write_message(f"Specified user name {cred['user']} does not exist.")
        self._user = cred["user"]
        # TODO: Verify user credentials.
        
        cli_type = cred.get("cli", "sonic-cli")
            
        if cli_type == "sonic-cli":
            self._proxy = CLIProxy(self._user,
                f"{shutil.which('clish')} --lockless --utf8 -x {os.path.expanduser('~/.as-mgmt/klish')}",
                self.write_message, self.close
            )
        elif cli_type == "bash":
            self._proxy = CLIProxy(self._user,
                f"{shutil.which('bash')}", self.write_message, self.close
            )
        else:
            self.write_message(f"Unknown/unsupported cli type {cred['user']} does not exist.")
            self._user = ""  # give a chance to retry.
            return
        try:
            await self._proxy.start()
        except Exception as err:
            self._user = ""  # give a chance to retry.
            msg = f"Websocket connection failed with {type(err).__name__}: {str(err)}"
            LOG.error(msg)
            self.write_message(msg)
            
    async def on_message(self, message: Union[str, bytes]) -> None:
        if not self._user:
            await self._handle_first_message(message)
            return
        assert self._proxy
        try:
            if isinstance(message, str):
                message = message.encode("utf-8")
            await self._proxy.write_input(message)
        except Exception as err:
            msg = f"Websocket server failed failed with {type(err).__name__}: {str(err)}"
            LOG.error(msg)
            self.write_message(msg)
        
    def on_close(self) -> None:
        if self._proxy:
            self._proxy.stop()
            
    def check_origin(self, origin: str) -> bool:
        # TODO: implement a serious cross-origin strategy.
        return True
