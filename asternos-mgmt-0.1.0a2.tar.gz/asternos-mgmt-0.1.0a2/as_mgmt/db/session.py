# pylint: disable=too-many-public-methods
from __future__ import annotations

import abc
import logging
import typing
import weakref
from typing import Any, Iterable, Literal, Optional, TypeVar, Type, Union
from typing_extensions import Self

from redis.exceptions import RedisError, WatchError
from redis.asyncio import Redis
from redis.asyncio.client import Pipeline

from .engine import Engine
from .model import BaseModel, Field, ReferenceWrapper, format_model_redis_key
from .exc import (
    DuplicatedModelError, SessionError, SessionRedisError, TransactionConflictError,
    InvalidReferenceError
)
from .query import Query

LOG = logging.getLogger(__name__)


T = TypeVar('T', bound=BaseModel)
V = TypeVar('V', bound=BaseModel)


class Loader(metaclass=abc.ABCMeta):
    """
    Loader interface of model objects.
    Implementation of this interface will handle actual database access
    """
        
    @abc.abstractmethod
    async def load_object_by_key_filters(self, model: Type[T], filters: Optional[list[str]] = None) -> list[T]:
        """
        Load objects of a single model type, with optionally primary key filters.
        """

    @abc.abstractmethod
    async def load_object_by_key(self, model: Type[T], keys: list[str]) -> Optional[T]:
        """
        Load a single object by specifying all its primary keys in order.
        """

    @abc.abstractmethod
    async def mark_delete_by_key(self, model: Type[BaseModel], keys: list[str]) -> None:
        """
        Mark the object denoted by the given model and list of primary_keys.
        """
        
    @abc.abstractmethod
    def increment_refcount(self, model: Type[BaseModel], keys: list[str]) -> None:
        """
        Notify the creation of a reference,
        add 1 to the ref count of a model object
        """
        
    @abc.abstractmethod
    def decrement_refcount(self, model: Type[BaseModel], keys: list[str]) -> None:
        """Notify the removal of a reference, minus 1 to the ref count of a model object"""
      
    @abc.abstractmethod  
    def add_on_del_cascade_ref(self, model: Type[BaseModel], keys: list[str]) -> None:
        """notify the creation of an "on_del_cascade" reference"""
        
    @abc.abstractmethod
    def del_on_del_cascade_ref(self, model: Type[BaseModel], keys: list[str]) -> None:
        """notify the removal of an "on_del_cascade" reference"""


class SessionLoader(Loader):
    """
    Responsible for loading and managing objects mapped from db
    """
    
    INDEX_KEY = "AS_MGMT_KEY_INDEX"

    _objects: dict[str, BaseModel]
    _new_keys: set[str]
    _del_keys: set[str]
    _deferred_refcount: dict[tuple[Type[BaseModel], str], int]
    # Deferred reference counts. Maps model and redis key to ref count modification value.
    # We can't load the referred object when the referrer is changed by attribute assignment
    # Because it is not an "async" operation and the object load method must be "awaited".
    _deferred_cascade_del_ref: set[tuple[Type[BaseModel], str]]
    # Deferred verification of "on delete cascade" references.
    # These are treated separately because the don't participate ref counting.

    def __init__(self, reader: Redis, writer: Pipeline, separator: str, read_only: bool, session: Session):
        self._reader = reader
        self._writer = writer
        self._separator = separator
        self._read_only = read_only
        self._objects = {}
        self._deferred_refcount = {}
        self._new_keys = set()  
        # This has O(n) complexity to perform prefix match.
        # Hopefully we don't got too many new keys in a row.
        # Update this if required
        self._del_keys = set()
        self._deferred_cascade_del_ref = set()
        self._session: Session = weakref.proxy(session)

    async def add(self, model: BaseModel):
        if self._read_only:
            raise SessionError("Can not create objects in a read only session")
        redis_key = format_model_redis_key(model, self._separator)
        await self._writer.watch(redis_key)
        if await self._reader.exists(redis_key) or redis_key in self._new_keys:
            raise DuplicatedModelError(model)
        model.__refcount__ = 0
        model.__session__ = self._session
        for ref_field in model.__refs__:
            getattr(type(model), ref_field).update_ref(model, increment=True)
        self._new_keys.add(redis_key)
        self._objects[redis_key] = model

    async def _index_add_new_keys(self):
        if self._new_keys:
            await self._writer.zadd(self.INDEX_KEY, {key: 0 for key in self._new_keys})

    async def _index_rem_del_keys(self):
        if self._del_keys:
            await self._writer.zrem(self.INDEX_KEY, *self._del_keys)

    async def rebuild_index(self):
        """Rebuild index. This is typically required for CONFIG_DB on the first run"""
        async for batch in self._reader.scan_iter(count=50):
            # WARNING: Since the management plane share Redis with control plane(APP_DB) and ASIC driver(ASIC_DB),
            #    Improper increase of "count" parameter may block Redis
            #    and result in severe performance degradation of the whole switch system.
            await self._writer.zadd(self.INDEX_KEY, {key: 0 for key in batch})
     
    async def _load_object(self, model_type: Type[T], key: str) -> Optional[T]:
        """
        Load an object by model type and key.
        Return None if the object does not exist.
        """
        if key in self._objects:
            obj = self._objects[key]
            assert isinstance(obj, model_type)
            return obj
        
        data = await self._reader.hgetall(key)
        if not data:
            return None
        kwargs: dict[str, Any] = {}
        key_elements = key.split(self._separator)
        table_name = key_elements[0]
        primary_keys = key_elements[1:]
        assert table_name == model_type.__table_name__
        if len(primary_keys) != len(model_type.__key_fields__):
            # This is possible where two tables have the same name and are only different by primary key count.
            # example: "INTERFACE|Ethernet1" and "INTERFACE|Ethernet2|192.168.1.1/24"
            # In a prefix query of one resource, the key of the other one might also get matched
            # and result in here
            return None

        for field_name, value in zip(model_type.__key_fields__, primary_keys):
            field_descriptor = getattr(model_type, field_name)
            assert isinstance(field_descriptor, Field)
            kwargs[field_name] = self._deserialize_field(field_descriptor, value)

        for field_name in model_type.__all_fields__:
            field_descriptor = getattr(model_type, field_name)
            if field_name in data:
                kwargs[field_name] = self._deserialize_field(field_descriptor, data[field_name])        

        model = model_type(**kwargs)
        model.__new_obj__ = False
        model.__session__ = self._session
        refcount = int(data.get("__refcount__", 0))
        if (model_type, key) in self._deferred_refcount:
            refcount += self._deferred_refcount.pop((model_type, key))
        assert refcount >= 0
        model.__refcount__ = refcount
        self._objects[key] = model
        return model
    
    def _deserialize_field(self, descriptor: 'Field', value: str):
        # TODO: Support custom deserializer in the future.
        type_info = descriptor.type
        if type_info.is_container:
            return type_info.base_type(type_info.item_type(item) for item in value.split(','))
        else:
            return type_info.base_type(value)
        
    async def load_object_by_key_filters(self, model: Type[T], filters: Optional[list[str]] = None) -> list[T]:
        prefix = f'{model.__table_name__}{self._separator}'
        if filters:
            prefix += self._separator.join(filters)
        keys = []
        for key in self._new_keys:
            if key.startswith(prefix):
                keys.append(key)
        q_str = f"[{prefix}".encode('utf-8')
        keys.extend(await self._reader.zrangebylex(
            self.INDEX_KEY, q_str, q_str + b"\xff"
        ))
        if not self._read_only and keys:
            await self._writer.watch(*keys)
        result = []
        for key in keys:
            if key in self._del_keys:
                continue
            item = await self._load_object(model, key)
            # It is possible to have 'None' here even under normal operation.
            # 1. This is the result of matching different tables that are solely
            #    different by primary key count.
            # 2. This is the result of "phantom read", caused by the fact that the
            #    ranged key query lacks "predicate locks" to protect it from 
            #    concurrent delete operations.
            if item is not None:
                result.append(item)
        return result

    async def _save_fields(self, key: str, model: BaseModel, fields: Iterable[str], new: bool):
        mapping = {'__refcount__': str(model.__refcount__)}
        del_fields = []
        for field in fields:
            val = getattr(model, field, None)
            if val is not None:
                # TODO: Support custom serializer in the future.
                mapping[field] = str(val)
            else:
                del_fields.append(field)
        if mapping:
            await self._writer.hset(key, mapping=mapping)  # type: ignore[arg-type]
        if del_fields and not new:
            await self._writer.hdel(key, *del_fields)
            
    async def pre_save_validate(self) -> None:
        for (model_type, key), refcount in list(self._deferred_refcount.items()):  
            # list() call required because _deferred_refcount will be modified in iteration.
            if refcount == 0:
                continue
            result = await self._load_object(model_type, key)
            if result is None:
                raise InvalidReferenceError(model_type, key)
        for model_type, key in self._deferred_cascade_del_ref:
            result = await self._load_object(model_type, key)
            if result is None:
                raise InvalidReferenceError(model_type, key)
    
    async def save(self) -> None:
        """Save data and clear cached objects"""
        if self._read_only:
            return
        # If there are still some reference count deferred, this is our last chance to load and modify them.
        for key, model in self._objects.items():
            if key in self._del_keys:
                continue
            if model.__new_obj__:
                # TODO: Cache non-key fields and optimize this.
                await self._save_fields(key, model, set(model.__all_fields__) - set(model.__key_fields__), True)
            else:
                await self._save_fields(key, model, model.__dirty_fields__, False)
        if self._del_keys:
            await self._writer.delete(*self._del_keys)
        await self._index_add_new_keys()
        await self._index_rem_del_keys()
        self._objects.clear()
        self._new_keys.clear()
        self._del_keys.clear()

    async def load_object_by_key(self, model: Type[T], keys: list[str]) -> Optional[T]:
        redis_key = f'{model.__table_name__}{self._separator}' + self._separator.join(keys)
        if not self._read_only:
            await self._writer.watch(redis_key)
        return await self._load_object(model, redis_key)
    
    async def mark_delete_by_key(self, model: Type[BaseModel], keys: list[str]) -> None:
        if self._read_only:
            raise SessionError("Can not delete objects in a read only session")
        redis_key = f'{model.__table_name__}{self._separator}' + self._separator.join(keys)
        await self._writer.watch(redis_key)
        self._del_keys.add(redis_key)
        
    def increment_refcount(self, model: Type[BaseModel], keys: list[str]) -> None:
        redis_key = f'{model.__table_name__}{self._separator}' + self._separator.join(keys)
        if redis_key in self._objects:
            self._objects[redis_key].__refcount__ += 1
        elif redis_key not in self._deferred_refcount:
            self._deferred_refcount[(model, redis_key)] = 1
        else:
            self._deferred_refcount[(model, redis_key)] += 1
        
    def decrement_refcount(self, model: Type[BaseModel], keys: list[str]) -> None:
        redis_key = f'{model.__table_name__}{self._separator}' + self._separator.join(keys)
        if redis_key in self._objects:
            self._objects[redis_key].__refcount__ -= 1
        elif redis_key not in self._deferred_refcount:
            self._deferred_refcount[(model, redis_key)] = -1
        else:
            self._deferred_refcount[(model, redis_key)] -= 1
            
    def add_on_del_cascade_ref(self, model: Type[BaseModel], keys: list[str]) -> None:
        redis_key = f'{model.__table_name__}{self._separator}' + self._separator.join(keys)
        self._deferred_cascade_del_ref.add((model, redis_key))
        
    def del_on_del_cascade_ref(self, model: Type[BaseModel], keys: list[str]) -> None:
        redis_key = f'{model.__table_name__}{self._separator}' + self._separator.join(keys)
        self._deferred_cascade_del_ref.discard((model, redis_key))


class Session:
    """
    Database access sessions. Provides transaction control and 
    object saving/loading interfaces.
    Each engine is only capable of operating one datastore, e.g. CONFIG_DB. 

    A session is not coroutine safe and should not be accessed concurrently.
    """
    state: Literal['READY', 'ACTIVE', 'COMMITTED', 'ABORTED', 'ERROR']
    # 'Error' indicates an unexpected, unrecoverable error
    # where redis commands failed partially and can not be rolled back.
    _pipe: Optional[Pipeline]
    _loader: Optional[SessionLoader]


    def __init__(self, engine: Engine, *, read_only: bool = False):
        self.engine = engine
        self._client = engine.get_client()
        self.read_only = read_only
        self.state = 'READY'

        self._pipe = None
        self._loader = None

    async def __aenter__(self) -> Self:
        """
        Session objects supports asynchronous context manager semantics
        The transaction is aborted if:
        1. User called abort() method during the transaction.
        2. The context manager exits
        Otherwise, it is automatically committed on exit.
        Usage:
        >>> async with Session(engine) as session:
        >>>     port = session.query(Port).filter(Port.name == "Ethernet0")
        >>>     port.admin_state = 'down'
        """
        await self._begin()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.state == 'ACTIVE':
            if exc_type is None:
                try:
                    await self.commit()
                    self.state = 'COMMITTED'
                except Exception:
                    await self.abort()
                    self.state = 'ABORTED'
                    await self._client.close()
                    raise
            else:
                await self.abort()
                # transaction is aborted automatically if we got a redis error.
                # repeated discard will result in another error
                self.state = 'ABORTED'
        await self._client.close()
    
    async def _begin(self) -> None:
        # No need to call this method manually even if context managers are not used.
        # It is called automatically.
        self._pipe = self._client.pipeline()
        await self._pipe.immediate_execute_command('SELECT', self.engine.db_id)
        self._loader = SessionLoader(self._client, self._pipe, self.engine.separator, self.read_only, self)
        self.state = 'ACTIVE'

    async def commit(self) -> None:
        """Explicitly commit the transaction."""
        if self.state != 'ACTIVE':
            raise SessionError(f"Invalid state '{self.state}' when calling session commit.")
        assert self._pipe is not None
        assert self._loader is not None
        if self.read_only:
            await self._pipe.reset()
            await self._pipe.close(close_connection_pool=False)
            return
        await self._loader.pre_save_validate()
        self._pipe.multi()
        try:
            await self._loader.save()
            await self._pipe.execute()
            self.state = 'COMMITTED'
        except WatchError as err:
            self.state = 'ABORTED'
            raise TransactionConflictError() from err
        except RedisError as err:
            LOG.error("Failed to commit redis transaction with error: %s", err)
            self.state = 'ERROR'
            raise SessionRedisError(err) from err
        except Exception:
            self.state = 'ERROR'
            raise
        finally:
            await self._pipe.close(close_connection_pool=False)
        
    async def abort(self, need_discard=False) -> None:
        if self.state != 'ACTIVE':
            raise SessionError(f"Invalid state '{self.state}' when calling session abort.")
        assert self._pipe is not None
        try:
            if need_discard:
                await self._pipe.discard()
            self.state = 'ABORTED'
        except RedisError as err:
            LOG.error("Failed to commit redis transaction with error: %s", err)
            self.state = 'ERROR'
            raise SessionRedisError(err) from err
        finally:
            await self._pipe.close(close_connection_pool=False)
        
    def __del__(self):
        if self.state == 'ACTIVE':
            LOG.warning("A session is garbage collected without being explicitly "
                        "committed. This will waste resources in connection pools.")
            
    async def add(self, model: BaseModel):
        """
        Add a newly created model into the session.
        These models are
        """
        if not model.__new_obj__:
            raise SessionError("Model is not newly created")
        if self.state != 'ACTIVE':
            raise RuntimeError("Session not started")
        assert self._loader is not None
        await self._loader.add(model)
        
    @typing.overload
    def query(self, target: Type[T]) -> Query[T]:
        """
        Starts a query on a model class
        Usage example:
        >>> vlan100_instance = session.query(Vlan).filter(Vlan.vlan_id == 100).one_or_none()
        """
        
    @typing.overload
    def query(self, target: ReferenceWrapper[T, V]) -> Query[T]:
        """
        Query a reference on a model instance and get a query object for the referred model with filters set.
        T: referee model type
        V: referrer model type
        Usage Example:
        >>> vlan: Vlan
        >>> vlan_member: VlanMember
        >>> vlan = session.query(vlan_member.vlan_ref).one_or_none()
        Now we find the associated vlan object of a vlan_member object.
        """

    def query(self, target: Union[Type[T],  ReferenceWrapper[T, V]]) -> Query[T]:
        if self.state != 'ACTIVE':
            raise RuntimeError("Session not started")
        assert self._loader is not None
        if isinstance(target, ReferenceWrapper):
            instance = target.instance
            target_model = target.ref.referee_model
            fields = target.ref.referrer
            predicates = [
                getattr(target_model, target_key_field) == getattr(instance, local_field)
                for target_key_field, local_field in zip(target_model.__key_fields__, fields)
            ]
            return Query(target_model, self._loader).filter(*predicates)
        return Query(target, self._loader)
        
    @property
    def __loader__(self) -> Loader:
        # For internal use. Exposes lower-level APIs for models and references.
        if self.state != 'ACTIVE':
            raise RuntimeError("Session not started")
        assert self._loader is not None
        return self._loader
