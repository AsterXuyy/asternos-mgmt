import logging
import redis.asyncio as redis

from enum import Enum
from typing_extensions import Self

LOG = logging.getLogger(__name__)


class SonicDB(str, Enum):
    CONFIG_DB = "CONFIG_DB"
    STATE_DB = "STATE_DB"
    APP_DB = "APP_DB"
    COUNTER_DB = "COUNTER_DB"
    FLEX_COUNTER_DB = "FLEX_COUNTER_DB"
    
    
class Datastore(str, Enum):
    RUNNING = "running"
    INTENDED = "intended"
    OPERATIONAL = "operational"
    STARTUP = "startup"
    CANDIDATE = "candidate"
    
    
EMPTY_DB_NUM = 15
RUNNING_CFG_DB_NUM = 14
OPERATIONAL_INTENDED_CFG_DB_NUM = 4
CANDIDATE_CFG_DB_NUM = 13
STARTUP_CFG_DB_NUM = 12
STATE_DB_NUM = 6
APP_DB_NUM = 0
COUNTER_DB_NUM = 2
FLEX_COUNTER_DB_NUM = 5


class SwitchDbRedis(redis.Redis):  # pylint: disable=abstract-method
    
    def __init__(self, connection_pool: redis.ConnectionPool, db_id: int):
        super().__init__(
            connection_pool=connection_pool,
            decode_responses=True,
            single_connection_client=True
        )
        self._db_id = db_id
        self._init = False
        
    async def initialize(self) -> Self:
        assert self.single_connection_client
        # We use single connection client because:
        # 1. In a asyncio environment, sessions are single-threaded, and
        #    using multiple connection is not beneficial
        # 2. SELECT command is only performed once, and only valid on the current connection.
        if self._init:
            return self
        self._init = True
        await super().initialize()
        await self.select(self._db_id)  # 'select' calls 'initialize' again. avoid recursive calls.
        return self


class Engine:
    """
      Store connection pools to each redis database.
      :param db_name: Name of the database. Currently supported ones are:
    'CONFIG_DB', 'STATE_DB', 'APP_DB', 'COUNTER_DB', 'FLEX_COUNTER_DB'
      :param datastore: Each datastore holds a separated copy of config data.
    Their interactions conform to NETCONF standard. Available datastores are:
    'running', 'intended', 'startup', 'operational', 'candidate', 'backup<n>',
    where n ranges from 1 to 4
      :param url: Specify connection parameters to the redis instance.
    For TCP connections, use: redis://127.0.0.1:6379
    For UNIX domain socket connections, use: unix:///var/run/redis.sock
      Since APP_DB, COUNTER_DB and other operational state db does not have multiple
    datastore, they will be pointed to an unused, empty redis db, so that any 
    read operation results in empty value.

    TODO: Multiple datastore is not implemented yet.
    TODO: Cache pools according to init params, make them singletons.
    """
    db_id: int
    separator: str

    def __init__(self, 
                 db_name: SonicDB,
                 datastore: Datastore,
                 connection_pool: redis.ConnectionPool):
        self.db_name = db_name
        self.datastore = datastore
        if db_name == SonicDB.CONFIG_DB:
            if datastore == Datastore.RUNNING:
                self.db_id = RUNNING_CFG_DB_NUM
            elif datastore == Datastore.INTENDED or datastore == Datastore.OPERATIONAL:
                self.db_id = OPERATIONAL_INTENDED_CFG_DB_NUM
            elif datastore == Datastore.CANDIDATE:
                self.db_id = CANDIDATE_CFG_DB_NUM
            elif datastore == Datastore.STARTUP:
                self.db_id = STARTUP_CFG_DB_NUM
            else:
                assert False
            self.separator = '|'
        elif datastore != Datastore.RUNNING:
            self.db_id = EMPTY_DB_NUM
            self.separator = '.'  # Not important
        else:
            if db_name == SonicDB.STATE_DB:
                self.db_id = STATE_DB_NUM
                self.separator = '|'
            elif db_name == SonicDB.APP_DB:
                self.db_id = APP_DB_NUM
                self.separator = ':'
            elif db_name == SonicDB.COUNTER_DB:
                self.db_id = COUNTER_DB_NUM
                self.separator = ':'
            elif db_name == SonicDB.FLEX_COUNTER_DB:
                self.db_id = FLEX_COUNTER_DB_NUM
                self.separator = ':'
            else:
                assert False
        self._pool = connection_pool

    def get_client(self) -> redis.Redis:
        return SwitchDbRedis(self._pool, self.db_id)
    
    async def shutdown(self) -> None:
        await self._pool.disconnect()
