from typing import Type, Any, TYPE_CHECKING
from as_mgmt.exc import HttpRespCode, MgmtBaseException, NetconfErrorTag, GrpcRespCode

if TYPE_CHECKING:  # pragma: no cover
    from as_mgmt.db.model import BaseModel


class StorageException(MgmtBaseException):
    """
    Errors related with the storage subsystem,
    Either about the object mapping models or redis database access
    """


class ModifyReadOnlyModelException(StorageException):
    pass


class SessionError(StorageException):
    """
    Raised with invalid usage of session objects.
    Such errors are caused by programming errors/
    """

    msg_format = "{msg}"

    def __init__(self, msg: str):
        super().__init__(msg=msg)


class SessionRedisError(StorageException):
    """
    Raised when the interaction with redis database fails
    """

    msg_format = "{msg}"

    def __init__(self, wrapped_exc: Exception):
        self.wrapped_exc = wrapped_exc
        super().__init__(msg=str(wrapped_exc))


class TransactionConflictError(StorageException):
    
    msg_format = ("Operation failed because it conflicts with another "
                  "concurrent request. Please try again later.")
    netconf_error_tag = NetconfErrorTag.LOCK_DENIED
    http_status_code = HttpRespCode.CONFLICT
    grpc_error_code = GrpcRespCode.ABORTED
    error_tag = 'system.concurrency.conflict'


class DataValidationFailedError(StorageException):
    """Raised when trying to write invalid data into databases."""

    error_tag = 'app.validation'
    grpc_error_code = GrpcRespCode.INVALID_ARGUMENT
    netconf_error_tag = NetconfErrorTag.INVALID_VALUE

    msg_format = "Failed to validate {model}.{field}: {msg}"

    def __init__(self, model: str, field: str, msg: str):
        super().__init__(model=model, field=field, msg=msg)


class ModifyReadOnlyFieldException(StorageException):
    """Raised when trying to write a read only field."""

    error_tag = 'app.validation'
    grpc_error_code = GrpcRespCode.INVALID_ARGUMENT
    netconf_error_tag = NetconfErrorTag.INVALID_VALUE

    msg_format = "{model}.{field} is read only"

    def __init__(self, model: str, field: str):
        self.data = {'model': model, "field": field}
        super().__init__(model=model, field=field)


class DuplicatedModelError(StorageException):
    """
    Raised when trying to add an object that:
    1. Already exists in the database
    2. Already created in the same session(duplicated call to session.add)
    """
    
    error_tag = "app.duplicated"
    grpc_error_code = GrpcRespCode.ALREADY_EXISTS
    netconf_error_tag = NetconfErrorTag.DATA_EXISTS
    http_status_code = HttpRespCode.BAD_REQUEST
    
    msg_format = "Duplicated {model_name} with key fields: {key_fields_str}"
    
    def __init__(self, instance: 'BaseModel'):
        self.instance = instance
        self.data: dict[str, Any] = {'resource_type': type(instance).__name__, 'keys': {
            key: getattr(instance, key) for key in instance.__key_fields__
        }}
        super().__init__(
            model_name=type(instance).__name__,
            key_fields_str=", ".join(f"{key}={value}" for key, value in self.data['keys'].items())
        )


class InvalidReferenceError(StorageException):
    """
    Raised when detecting references to objects that do not exists.
    """
    
    error_tag = "app.invalid_reference"
    grpc_error_code = GrpcRespCode.FAILED_PRECONDITION
    netconf_error_tag = NetconfErrorTag.DATA_MISSING
    http_status_code = HttpRespCode.BAD_REQUEST
    
    msg_format = ("Detected invalid referenced to {referee_type} object "
                  "with storage key {referee_key}")
    
    def __init__(self, referee_type: Type['BaseModel'], key: str):
        self.referee_type = referee_type
        self.referee_key = key
        super().__init__(
            referee_type=referee_type.__name__,
            referee_key=key
        )


class DeleteReferencedError(StorageException):
    
    error_tag = "app.delete_referenced"
    grpc_error_code = GrpcRespCode.FAILED_PRECONDITION
    netconf_error_tag = NetconfErrorTag.IN_USE
    http_status_code = HttpRespCode.BAD_REQUEST
    
    msg_format = "Failed to delete {instance} because it is still referenced by {refcount} object(s)"

    def __init__(self, instance: 'BaseModel'):
        self.data = {
            'instance': instance.to_dict(),
            'refcount': instance.__refcount__
        }
        super().__init__(instance=repr(instance), refcount=instance.__refcount__)
