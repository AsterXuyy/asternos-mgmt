from typing import TYPE_CHECKING, Iterable, Type, TypeVar, Generic, Any, Optional

from typing_extensions import Self

if TYPE_CHECKING:
    from .model import Field, BaseModel
    from .session import SessionLoader


class Predicate:
    """Represents a filter predicate, such as equal, greater, etc."""
    predicate: str = ""

    def __init__(self, field: 'Field', value: Any):
        self.field = field
        self.value = value
        self._verify(field, value)

    def _verify(self, field: 'Field', value: Any):
        if not isinstance(value, field.type.base_type):
            raise TypeError("Filter value does not have the same type with the field. "
                            f"Expected: {field.orig_type.__name__}, "
                            f"Actual: {type(value).__name__}")
            

class IterableValuePredicate(Predicate):
    def _verify(self, field: 'Field', value: Any):
        if not isinstance(value, Iterable):
            raise TypeError(f"{type(self).__name__} expects a iterable value.")
        for item in value:
            if not isinstance(item, field.type.base_type):
                raise TypeError("Filter value does not have the same type with the field. "
                                f"Expected: {field.orig_type.__name__}, "
                                f"Actual: {type(value).__name__}")


class Equal(Predicate):
    predicate = "eq"


class Greater(Predicate):
    predicate = "gt"
    

class Lesser(Predicate):
    predicate = "lt"
    

class NotEqual(Predicate):
    predicate = "gt"
    

class GreaterEqual(Predicate):
    predicate = "ge"
    
    
class LesserEqual(Predicate):
    predicate = "le"
    
    
class IsElementOf(IterableValuePredicate):
    predicate = "in"
    

class IsNotElementOf(IterableValuePredicate):
    predicate = "not_in"
    

V = TypeVar('V', bound='BaseModel')


class Query(Generic[V]):

    def __init__(self, model: Type[V], loader: 'SessionLoader'):
        self.model = model
        self.filters: dict[str, dict[str, Predicate]] = {
            'eq': {}, 'neq': {}, 'gt': {}, 'lt': {}, 'ge': {}, 'le': {}, 'in': {}, 'not_in': {}
        }
        self.has_filters: bool = False
        self.loader = loader

    def _app_filter(self, objects: Iterable[V]) -> Iterable[V]:
        # Handle filters that redis db is not capable of filtering.
        for obj in objects:
            matched = True
            for pred in self.filters['eq'].values():
                if pred.field.__get__(obj, self.model) != pred.value:  # pylint: disable=unnecessary-dunder-call
                    matched = False
            for pred in self.filters['neq'].values():
                if pred.field.__get__(obj, self.model) == pred.value:  # pylint: disable=unnecessary-dunder-call
                    matched = False
            for pred in self.filters['gt'].values():
                if pred.field.__get__(obj, self.model) <= pred.value:  # pylint: disable=unnecessary-dunder-call
                    matched = False
            for pred in self.filters['lt'].values():
                if pred.field.__get__(obj, self.model) >= pred.value:  # pylint: disable=unnecessary-dunder-call
                    matched = False
            for pred in self.filters['ge'].values():
                if pred.field.__get__(obj, self.model) < pred.value:  # pylint: disable=unnecessary-dunder-call
                    matched = False
            for pred in self.filters['le'].values():
                if pred.field.__get__(obj, self.model) > pred.value:  # pylint: disable=unnecessary-dunder-call
                    matched = False
            for pred in self.filters['in'].values():
                if pred.field.__get__(obj, self.model) not in pred.value:  # pylint: disable=unnecessary-dunder-call
                    matched = False
            for pred in self.filters['not_in'].values():
                if pred.field.__get__(obj, self.model) in pred.value:  # pylint: disable=unnecessary-dunder-call
                    matched = False
            if matched:
                yield obj
    
    def _extract_db_filters(self) -> list[str]:
        # Find all filters that can form a prefix in redis key.
        result = []
        for primary_key in self.model.__key_fields__:
            # Control flows in this for loop are "break" instead of "continue"
            # Because if any primary key filters are not present, we can't use redis index any more
            # and need to used "_app_filter" to filter result for the remaining predicates.
            if primary_key not in self.filters['eq']:
                break
            filter_ = self.filters['eq'].pop(primary_key)
            if isinstance(filter_, Equal):
                result.append(filter_.value)
            else:
                break
        return result

    def filter(self, *predicates: Predicate) -> Self:
        """
        Filter with predicates. Example:
        >>> session.query(Interface).filter(Interface.name == "Ethernet1").all()
        """
        for item in predicates:
            self.filters[item.predicate][item.field.name] = item
        self.has_filters = True
        return self

    async def delete(self) -> int:
        """
        Delete models matching the filter.
        :return: Number of resources actually deleted
        """
        # TODO: This is sub-optimal. We don't need to load the content of objects in many cases
        #       where a reference check is not required.
        filters = self._extract_db_filters()
        objs_to_del = await self.loader.load_object_by_key_filters(self.model, filters)
        count = 0
        for obj in self._app_filter(objs_to_del):
            count += 1
            await obj.delete()
        return count

    async def all(self) -> list[V]:
        """
        Load all models matching the filter
        """
        filters = self._extract_db_filters()
        objs = await self.loader.load_object_by_key_filters(self.model, filters)
        return list(self._app_filter(objs))
    
    async def one_or_none(self) -> Optional[V]:
        """
        Assert that there is at most one model matching the filters.
        Return the model if it exists.
        Raise an error if more than one models matched the filters.
        """
        filters = self._extract_db_filters()
        objs = await self.loader.load_object_by_key_filters(self.model, filters)
        result = list(self._app_filter(objs))
        if not result:
            return None
        if len(result) > 1:
            raise ValueError("Multiple objects found")
        return result[0]
    
    async def exactly_one(self) -> V:
        val = await self.one_or_none()
        if val is None:
            raise ValueError("Object not found")
        return val
