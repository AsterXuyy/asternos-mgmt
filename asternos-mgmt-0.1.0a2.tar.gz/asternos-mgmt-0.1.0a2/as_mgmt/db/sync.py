

class IncrementalSyncAgent:
    """
    This agent runs in background to incrementally synchronize data
    from one config store to another.
    The most typical use case is from <running-config> to <operational-config>(CONFIG_DB).
    """
    
    debounce_time = 0.05
    # The time to wait before emitting config sync operations of a key.
    # For example, when receiving an "HSET" or "HDEL" event on key "ETHERNET_PORT|Ethernet0",
    # we wait a "debounce_time" before trying to load the content of this key.
    # This is useful when there are multiple consecutive operations on this key.
    # Bigger debounce_time may result in lower resource usage but increases the time for configs to take effect.
    # TODO: This value requires future fine-tuning.
    
    rate_limit_levels: dict[str, float] = {
        "quick": 0.05,
        "moderate": 0.2,
        "slow": 1
    }
    # Some configurations requires a rate limit when writing to CONFIG_DB 
    # due to some bad, legacy implementation.
    # Models may choose a rate limit level. Whe syncing this model, we use a special
    # rate limited queue to process such them.
    
