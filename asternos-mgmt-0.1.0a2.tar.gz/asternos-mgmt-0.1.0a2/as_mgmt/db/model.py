"""
Data types used in object mapping framework.
"""
from __future__ import annotations

import typing
from dataclasses import dataclass
from types import GenericAlias
from typing import (
    Iterable, Literal, Optional, Generic, Sequence, TypeVar, Type, 
    Any, Callable, overload, Union, ClassVar, TYPE_CHECKING,
)
from typing_extensions import Self, TypeAlias

from as_mgmt.db import exc
from as_mgmt.db.query import (
    Equal, NotEqual, Greater, Lesser, GreaterEqual, LesserEqual, IsElementOf, IsNotElementOf
)

if TYPE_CHECKING:
    from .session import Session


T = TypeVar('T')
        

class ModelMeta(type):
    
    models: dict[str, ModelMeta] = {}
    # An index of all defined model classes.
    # Maps __table_name__ to Model class
    
    root_models: list[ModelMeta] = []
    # Records models that are not dependant on any other models(without "Reference" field).
    # Such models are the starting point of a config sync process, and the dependency graph
    # is then accessed via the __backrefs__ attribute of model classes.
    
    # Below are fields on model classes. Make type checker happy.
    if TYPE_CHECKING:   # pragma: no cover
        __table_name__: str
        __refs__: list[str]
    
    def __new__(mcs, name: str, bases: tuple[type, ...], dct: dict[str, Any]):
        count = 0
        for base in bases:
            if isinstance(base, ModelMeta):
                count += 1
        if count >= 2:
            raise TypeError("Multiple inheritance of Model classes is not allowed "
                            "as it breaks the dependency resolver.")
        dct['__all_fields__'] = []
        dct['__key_fields__'] = []
        dct['__mandatory_fields__'] = []
        dct['__backrefs__'] = []
        dct['__refs__'] = []
        cls = super().__new__(mcs, name, bases, dct)
        # Descriptor __set_name__ is called in metaclass method type.__new__.
        # From now on we can access metadata fields such as __all_fields__ and __refs__
        # of the newly created model class.
        mcs.models[cls.__table_name__] = cls
        if not cls.__refs__:
            mcs.root_models.append(cls)
        return cls
    
    @classmethod
    def reflect_db(mcs, key: str, key_split: str = '|') -> Optional[BaseModel]:
        """
        Reflect a model class from database representation.
        Type of the model is not known in prior, but acquired from model registration in the metaclass.
        
        :param key_split: A single character used as the separator of fields in keys.
           Usually '|' for CONFIG_DB and ':' for APP_DB
        :return: The model class. Return None if not found.
        """
        table, _, _ = key.partition(key_split)
        if table not in mcs.models:
            return None
        # TODO: This type case is not safe. We can only guarantee that its metaclass is ModelMeta,
        #    but it may not be a subclass of BaseModel.
        #    We can't check this in __new__ since BaseModel is not yet created there.
        #    We need to find an alternative way.
        return typing.cast(BaseModel, mcs.models[table])


class BaseModel(metaclass=ModelMeta):
    """
    Base Model class used to create database objects.
    Use 'Field' class to create attribute definitions.
    User should override the following class attributes to define its behavior.
      :param __table_name__: "Table" is the term used by SONIC to denote 
    a collection of homogeneous objects. It is essentially a prefix in redis db.
    for example, a redis key named "INTERFACE_TABLE|Ethernet1" represents an instance
    of a model with __table_name__ = "INTERFACE_TABLE". 
      :param __db_name__: Name of the SONIC database this model belongs to.
    This defaults to "CONFIG_DB". It can be overridden by model loading APIs.
    Models from databases other than "CONFIG_DB" are intrinsically read only,
    and "read_only" attrs on fields have no effect in this case.
      :param __no_add_del__: If true, user can neither create new instances for this model,
    nor can they delete existing ones. This is commonly used by hardware related configs
    including ports and buffers. Default to false.
       The example below defines an (extremely simplified) port model:
    >>> class Port(BaseModel):
    ...     __table_name__ = "PORT_TABLE"
    ...     __no_add_del__ = True
    ...     name = Field(str, primary_key=True)
    ...     lanes = Field(list[int], read_only=True)
    ...     speed = Field(int)
    ...     mtu = Field(int, lambda mtu: 1500 <= mtu <= 9216)
    """
    __refcount__: int

    __all_fields__: ClassVar[list[str]]
    __key_fields__: ClassVar[list[str]]
    __mandatory_fields__: ClassVar[list[str]]
    __refs__: ClassVar[list[str]]
    __backrefs__: ClassVar[list[BackRef]]

    __readonly__: bool = False

    def _real_init(self, *args, **kwargs):
        self.__session__ = None
        self.__refcount__ = -1  # Use negative number for uninitialized objects.
        self.__new_obj__ = True
        self.__dirty_fields__ = set()
        if len(args) > len(self.__all_fields__):
            raise TypeError(f"Got {len(args) - len(self.__all_fields__)} extra "
                            f"positional parameters for {type(self).__name__}")
        for field, arg in zip(self.__all_fields__, args):
            setattr(self, field, arg)
        for field, arg in kwargs.items():
            if field not in self.__all_fields__:
                raise TypeError(f"Got extra keyword argument '{field}' for {type(self).__name__}")
            setattr(self, field, arg)
        for field in self.__key_fields__:
            if getattr(self, field, None) is None:
                raise TypeError(f"Instance creation of {type(self).__name__} is missing primary key {field}")
        self.__dirty_fields__ = set()  # dirty fields will be set by former setattr. clear them.
        
    # When typechecking, we use a mypy plugin located at as_mgmt_mypy.model_plugin to generate __init__ signature
    # with field name and types. At runtime, use this plain init method with *args and **kwargs.
    if not TYPE_CHECKING:
        __init__ = _real_init

    async def delete(self) -> None:
        """
        Mark this model as deleted. It will no longer be accessible to query methods,
        and will be deleted from database on session commit.
        This method also check for restrict/cascade delete references.
        """
        if self.__session__ is None:
            raise exc.SessionError(f"Object {self} is not bound to any session")
        assert self.__refcount__ >= 0
        if self.__refcount__ > 0:
            raise exc.DeleteReferencedError(self)
        for ref_field in self.__refs__:
            getattr(self, ref_field).update_ref(self, increment=False)
        await self.__session__.__loader__.mark_delete_by_key(
            type(self), 
            [getattr(self, key) for key in self.__key_fields__]
        )
        for ref in self.__backrefs__:
            await self.__session__.query(ref.model).filter(*[
                getattr(ref.model, target_name) == getattr(self, local_name)
                for local_name, target_name in zip(self.__key_fields__, ref.fields)
            ]).delete()
        
    def is_complete(self) -> bool:
        """
        Whether all mandatory fields are assigned.
        If not, this model is considered "incomplete" and:
        1. Has no effect as a configuration
        2. Can not be referenced by other models.
        """
        return all(getattr(self, attr) is not None for attr in self.__mandatory_fields__)
    
    def to_dict(self, preserve_none: bool = False) -> dict[str, Any]:
        """
        Convert this model to a dictionary with the same structure.
          :param preserve_none: If True, fields not assigned appears with "None" as its value in the result.
        Otherwise, such keys are simply not present.
        """
        result = {}
        for field_name in self.__all_fields__:
            value = getattr(self, field_name)
            if value is not None or preserve_none:
                result[field_name] = value
        return result
    
    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, BaseModel):
            return NotImplemented
        if type(self) is not type(other):
            return False
        return all(getattr(self, attr, None) == getattr(other, attr, None) for attr in self.__all_fields__)

    # Model attributes:
    __table_name__: str = "NOT_SPECIFIED"
    __db_name__: str = "CONFIG_DB"
    __no_add_del__: bool = False

    # Internal use:
    __session__: Optional['Session']
    __new_obj__: bool
    __dirty_fields__: set[str]


def format_model_redis_key(model: BaseModel, separator: str):
    elem = [model.__table_name__]
    for key in model.__key_fields__:
        value = getattr(model, key, None)
        if value is None:
            raise ValueError(f"Missing primary key {key}")
        # TODO: Provide custom serializer.
        elem.append(str(value))
    return separator.join(elem)


@dataclass
class _TypeInfo(Generic[T]):
    """Holds type info for field objects"""
    is_container: bool
    base_type: Type[T]
    item_type: type = int  # arbitrary placeholder.
    

ValidatorType: TypeAlias = Callable[[T], Optional[Union[str, bool]]]


class _FieldMeta(type):
    @overload
    def __call__(cls, py_type: Type[T], primary_key: Literal[True],
                 validator: ValidatorType = lambda _: None,
                 read_only: Optional[bool] = None,
                 nullable: bool = False, default: Optional[T] = None,
                 alt_name: Optional[str] = None) -> _PrimaryField[T]:
        ...   # pragma: no cover
      
    @overload  
    def __call__(cls, py_type: Type[T], primary_key: Literal[False] = False,
                 validator: ValidatorType = lambda _: None,
                 read_only: Optional[bool] = None,
                 nullable: bool = False, default: Optional[T] = None,
                 alt_name: Optional[str] = None) -> _NonPrimaryField[T]:
        ...   # pragma: no cover
        
    def __call__(cls, py_type: Type[T], primary_key: Literal[True, False] = False,
                 validator: ValidatorType = lambda _: None,
                 read_only: Optional[bool] = None,
                 nullable: bool = False, default: Optional[T] = None,
                 alt_name: Optional[str] = None) -> Field[T]:
        if cls is Field:
            if primary_key:
                return _PrimaryField(py_type, primary_key, validator, read_only, nullable, default, alt_name)
            return _NonPrimaryField(py_type, primary_key, validator, read_only, nullable, default, alt_name)
        # Don't be recursive
        return super().__call__(py_type, primary_key, validator, read_only, nullable, default, alt_name)
    

class Field(Generic[T], metaclass=_FieldMeta):
    """
    A data field in redis object mapping models.
      Positional or keyword arguments:
      :param py_type: python type of the field. This may be one of:
    1. Basic python types, including but not limited to int, string, bytes.
    2. Stdlib types and user types that implements __str__ as a serialization method,
       and has an __init__ method accepting exactly one string argument as a deserializer.
    3. Lists, sets and tuples of these types, for example:
       >>> class ExampleModel(BaseModel):
       ...     list_field = Field(list[int])
       ...     set_field = Field(set[int])
       ...     tuple_field = Field(tuple[int, str])
       >>> obj = ExampleModel()
       >>> obj.list_field = [1, 2, 2, 3]
       >>> obj.set_field = {1, 2, 3}
       >>> obj.tuple_field = (1, "this is a string")
    4. Other types with its serialization/deserialization method registered in as_mgmt.serdes module.
    
      :param validator: Optionally provide a validator for the given value.
    It should be a callable object accepting exactly one parameter, which is the value to be verified.
    It should return None or True if the verification is successful, and return False or a string 
    containing error info if it fails. It may also raise an exception conforming to the exception 
    format of as_mgmt.
      :param primary_key: If true, this indicates the field be a part of the "object identity".
    Since we store data in redis, these fields will be encoded in the redis key.
    Although we borrowed this term from SQL, these "primary keys" do not act exactly the same as SQL:
    1. The order of these fields are significant and defines there order in redis key.
    2. Set types are not allowed for primary keys.
    3. Only the first primary key is indexable using redis 'ZRANGE' command.
    4. Updating primary key is not supported, since this effectively delete the entry
       in CONFIG_DB, causing operations to be executed.
       We require users to explicitly delete and recreate the record when changing primary key.

      :param read_only: If true, this field can be modified by business logic.
    This is used to protect configs related with hardware platforms, such as port lanes mapping.
      :param nullable: If true, this field is not necessary to make the object "complete".
    Note that we never forbid creating incomplete objects because they are inevitable for 
    command line actions. Instead, it is used to filter out incomplete object when 
    synchronizing configuration into actual SONIC CONFIG_DB.
      :param default: Optionally provide a default value for this key if not specified.
      :param alt_name: If specified, use an alternative name when storing in redis
    hash objects. By default, we the variable name that the field is assigned to.
    """

    _value: Optional[T]
    _owner: Optional[Type[BaseModel]]
    _name: str
    type: _TypeInfo
    
    ref: Optional[Reference]
    # Points to the reference object that is associated with this field.

    def _real_init(self, py_type: Type[T], primary_key: bool, validator: ValidatorType, 
                   read_only: Optional[bool], nullable: bool, default: Optional[T], alt_name: Optional[str]):
        _py_type = typing.cast(Union[Type[T], GenericAlias], py_type)
        # This is a hack to the type checkers.
        # Theoretically GenericAlias instances such as list[int] is not of type Type[T]
        # because the are not a class and can not be instantiated.
        # However, passing list[int] to py_type will not result in an error and
        # type checkers will deduce generic param T=list[int] (for example), which is what we want.
        # We force cast its type to include GenericAlias to suppress type errors in the following code.
        
        self._value = None
        self._owner = None
        self._name = alt_name if alt_name is not None else '__unbound__'
        self.orig_type = _py_type
        if isinstance(_py_type, GenericAlias):
            generic_params = typing.get_args(_py_type)
            if len(generic_params) != 1:
                raise ValueError("The first parameter of Field, when using GenericAlias, "
                                 "must be a container type with exactly one generic parameter")
            container_type = typing.get_origin(_py_type)
            if not issubclass(container_type, (list, set)):
                # TODO: Deserializer for tuples is not implemented yet.
                raise ValueError("The first parameter of Field, when using GenericAlias, "
                                 "must be a concrete container type.")
            self.type = _TypeInfo(True, container_type, generic_params[0])
        elif isinstance(_py_type, type):
            self.type = _TypeInfo(False, _py_type)
        else:
            raise ValueError("The first parameter of Field must be a type or GenericAlias")

        if primary_key and read_only is False:
            raise ValueError("Primary keys must be read only.")

        if read_only or (read_only is None and primary_key):
            self._read_only = True
        else:
            self._read_only = False
        self._nullable = nullable

        self._default = default
        self.validator = validator
        self.primary_key = primary_key
        self.ref: Optional[Reference] = None

    def __set_name__(self, owner: Type[BaseModel], name: str):
        self._owner = owner
        if self._name == '__unbound__':
            self._name = name
        self._owner.__all_fields__.append(self._name)
        if self.primary_key:
            self._owner.__key_fields__.append(self._name)
        if not self._nullable:
            self._owner.__mandatory_fields__.append(self._name)

    @overload
    def __get__(self, instance: BaseModel, owner: Type[BaseModel]) -> Optional[T]:
        ...   # pragma: no cover

    @overload
    def __get__(self, instance: None, owner: Type[BaseModel]) -> Self:
        ...   # pragma: no cover

    def __get__(self, instance: Optional[BaseModel], owner: Type[BaseModel]) -> Union[Self, T, None]:
        if instance is None:  # accessing classes instead of instances.
            return self
        field_hidden_name = f'__{self._name}'
        if not hasattr(instance, field_hidden_name):
            return self._default
        return typing.cast(T, getattr(instance, field_hidden_name))

    def __set__(self, instance: BaseModel, value: Optional[T]) -> None:
        assert self._owner is not None
        if value is not None:
            if not isinstance(value, self.type.base_type):
                raise TypeError(f"{self._owner.__name__}.{self._name} expects type {self.orig_type.__name__}, "
                                f"got {type(value).__name__} instead.")
            if self.type.is_container:
                assert isinstance(value, Iterable)
                for item in value:
                    if not isinstance(item, self.type.item_type):
                        raise TypeError(
                            f"{self._owner.__name__}.{self._name} is expects type {self.orig_type.__name__}, "
                            f"got item type {type(item).__name__} instead."
                        )
            err = self.validator(value)
            if self._read_only and hasattr(instance, f'__{self._name}'):
                if getattr(instance, f'__{self._name}') != value:
                    raise exc.ModifyReadOnlyFieldException(self._owner.__name__, self._name)
                # Allow setting read only fields with the same value.
                # This is especially useful for the implementation of NETCONF,
                # Because NETCONF does not have a "path" of target resource,
                # and primary keys are passed in with the fields to change.
                return
            if err is not None and err is not True:
                raise exc.DataValidationFailedError(
                    self._owner.__name__, self._name, 
                    err if isinstance(err, str) else "validator returned False"
                )
        instance.__dirty_fields__.add(self._name)
        if self.ref is not None:
            self.ref.update_ref(instance, increment=False)
        setattr(instance, f'__{self._name}', value)
        if self.ref is not None:
            self.ref.update_ref(instance, increment=True)
        
    # Following methods are predicate generating operations.
    # These are used in query filters to specify filter conditions with field objects.
    # For example:
    # >>> session.query(SomeModel).filter(
    # >>>     SomeModel.some_key == "some_value",
    # >>>     SomeModel.another_key >= 100 
    # >>> ).all()
    def __eq__(self, value: object) -> Equal:  # type: ignore[override]
        return Equal(self, value)
    
    def __ne__(self, value: object) -> NotEqual:  # type: ignore[override]
        return NotEqual(self, value)
    
    def __gt__(self, value: object) -> Greater:  # type: ignore[override]
        return Greater(self, value)
    
    def __lt__(self, value: object) -> Lesser:  # type: ignore[override]
        return Lesser(self, value)
    
    def __ge__(self, value: object) -> GreaterEqual:  # type: ignore[override]
        return GreaterEqual(self, value)
    
    def __le__(self, value: object) -> LesserEqual:  # type: ignore[override]
        return LesserEqual(self, value)
    
    def in_(self, value: Iterable) -> IsElementOf:
        return IsElementOf(self, value)
    
    def not_in(self, value: Iterable) -> IsNotElementOf:
        return IsNotElementOf(self, value)
    
    @property
    def name(self) -> str:
        if not self._name:
            raise ValueError("Name unbound")
        return self._name
    
    # Methods below are a walk around of a mypy bug and does nothing at runtime
    # https://github.com/python/mypy/issues/14122
    # __call__ on the metaclass is not properly analyzed, so
    # we use __new__ method to give type checker information about the result type.
    if TYPE_CHECKING:   # pragma: no cover
        @overload
        def __new__(cls, py_type: Type[T], *, primary_key: Literal[True],
                    validator: ValidatorType = lambda _: None,
                    read_only: Optional[bool] = None,
                    nullable: bool = False, default: Optional[T] = None,
                    alt_name: Optional[str] = None) -> _PrimaryField[T]:
            ...
          
        @overload  
        def __new__(cls, py_type: Type[T], *, primary_key: Literal[False] = False,
                    validator: ValidatorType = lambda _: None,
                    read_only: Optional[bool] = None,
                    nullable: bool = False, default: Optional[T] = None,
                    alt_name: Optional[str] = None) -> _NonPrimaryField[T]:
            ...
            
        def __new__(cls, *_, **__) -> Field[T]:
            raise NotImplementedError()


class _NonPrimaryField(Field[T]):
    def __init__(self, *args, **kwargs):
        Field._real_init(self, *args, **kwargs)


class _PrimaryField(Field[T]):
    def __init__(self, *args, **kwargs):
        Field._real_init(self, *args, **kwargs)
    
    @overload
    def __get__(self, instance: BaseModel, owner: Type[BaseModel]) -> T:
        ...   # pragma: no cover

    @overload
    def __get__(self, instance: None, owner: Type[BaseModel]) -> Self:
        ...   # pragma: no cover

    def __get__(self, instance: Optional[BaseModel], owner: Type[BaseModel]) -> Union[Self, T]:
        value = super().__get__(instance, owner)
        assert value is not None
        if not isinstance(value, Field):
            return typing.cast(T, value)
        return typing.cast(Self, value)


J = TypeVar('J', bound=BaseModel)  # referee model type
K = TypeVar('K', bound=BaseModel)  # referrer model type


class ReferenceWrapper(Generic[J, K]):
    """
    Wrapper class for reference access
    """

    def __init__(self, ref: Reference[J], instance: K):
        self.ref = ref
        self.instance = instance
        
    def update_ref(self, instance: K, increment: bool) -> None:
        # This function is for internal use only.
        return self.ref.update_ref(instance, increment)


V = TypeVar('V', bound=BaseModel)  # referee model type


class Reference(Generic[V]):
    """
      :param referrer: Local field names that contains the reference.
      :param referee_model: Model class of the reference target.
      The referee model must have the same number if primary keys with the length of referrer,
    And they are matched one-by-one to form the reference.
    The referrer and referee fields must have the same type, for example:
    >>> class Interface(BaseModel):
    ...     name = Field(str, primary_key=True)
    >>> class Vlan(BaseModel):
    ...     id = Field(int, lambda vlan_id: 0 < vlan_id < 4095, primary_key=True)
    >>> class SwitchPort(BaseModel):
    ...     vlan = Field(int, primary_key=True)
    ...     interface = Field(str, primary_key=True)
    ...     vlan_obj = Reference(['vlan'], Vlan)
    ...     interface_obj = Reference(['interface'], Interface)

    Note that 'Reference' objects should be created after all fields so that it
    can find referrer fields properly. The following example gives an example of
    multi-key reference:
    >>> class MstpPort(BaseModel):
    ...     vlan = Field(int, primary_key=True)
    ...     interface = Field(str, primary_key=True)
    ...     switch_port = Reference(['vlan', 'interface'], SwitchPort)

      :param ref_cascade_del: If true, when deleting the referee, 
    instead of aborting the request, the referrers are deleted in cascade. 
    This is only available if the referrers are a prefix of the primary keys
    (This means they may be found via range query). Cascade references
    do not increment the reference count of the referee. In the following example, 
    LAG members are deleted in cascade when the LAG object(referee) is deleted.
    >>> class LinkAggregation(BaseModel):
    ...     name = Field(str, primary_key=True)
    >>> class LinkAggregationMember(BaseModel)
    ...     lag = Field(str, primary_key=True)
    ...     intf = Field(str, primary_key=True)
    ...     lag_obj = Reference(['lag'], LinkAggregation, on_del_cascade=True)
    ...     intf_obj =  Reference(['intf'], Interface)
    """

    def __init__(self, referrer: Sequence[str], referee_model: Type[V], *, on_del_cascade=False):
        self.referrer = referrer
        self.referee_model = referee_model
        self.on_del_cascade = on_del_cascade
        self._name: str = "__unbound__"

    def __set_name__(self, owner: Type[BaseModel], name: str):
        self._name = name
        for field_name in self.referrer:
            field = getattr(owner, field_name, None)
            if not isinstance(field, Field):
                # This actually only works in python3.6+,
                # where dicts are inherently ordered. (consider the __dict__ attribute)
                raise TypeError(f"Reference {name} on model {owner.__name__} "
                                f"designated field {field_name} as referrer, which is not found. "
                                f"Did you forget to put reference declarations after field declarations?")
            field.ref = self
        if self.on_del_cascade and self.referrer != owner.__key_fields__[0:len(self.referrer)]:
            raise ValueError(f"Reference {name} on model {owner.__name__} "
                             f"has on_del_cascade=True but referrer fields {self.referrer} "
                             f"is not a prefix of model primary keys: {owner.__key_fields__}")
        owner.__refs__.append(name)
        if self.on_del_cascade:
            self.referee_model.__backrefs__.append(BackRef(owner, self.referrer))

    @overload
    def __get__(self, instance: K, owner: Type[K]) -> ReferenceWrapper[V, K]:
        ...  # pragma: no cover

    @overload
    def __get__(self, instance: None, owner: Any) -> Reference[V]:
        ...  # pragma: no cover
        
    @overload
    def __get__(self, instance: Field, owner: Type[Field]) -> Reference[V]:
        ...  # pragma: no cover

    def __get__(self, instance: Union[None, K, Field], owner: Any) -> Union[ReferenceWrapper[V, K], Self]:
        if instance is None:  # accessing classes instead of instances.
            return self
        if issubclass(owner, Field):
            return self  # field class needs to access original object to notify changes.
        return ReferenceWrapper(self, typing.cast(K, instance))
    
    def update_ref(self, instance: K, increment: bool) -> None:
        session = instance.__session__
        if session is None:
            return  # new instance before passing it to session.add()
        keys = [getattr(instance, field) for field in self.referrer]
        if any(key is None for key in keys):
            return  # reference is not complete.
        if self.on_del_cascade:
            # No reference counting for "on delete cascade" fields
            # because deletion should not be restricted by such references.
            if increment:
                session.__loader__.add_on_del_cascade_ref(self.referee_model, keys)
            else:
                session.__loader__.del_on_del_cascade_ref(self.referee_model, keys)
        else:
            if increment:
                session.__loader__.increment_refcount(self.referee_model, keys)
            else:
                session.__loader__.decrement_refcount(self.referee_model, keys)


class BackRef:
    """
    Created and used internally, this class provides are used to store
    "back refs" from referee to referrer. 
    Only used for references with on_del_cascade=True.
    """

    def __init__(self, referrer_model: Type[BaseModel], referrer_fields: Sequence[str]):
        self.model = referrer_model
        self.fields = referrer_fields
