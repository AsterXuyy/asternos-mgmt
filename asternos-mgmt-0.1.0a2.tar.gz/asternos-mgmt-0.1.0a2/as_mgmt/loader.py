import pkgutil
import importlib
import importlib.resources
import logging

from types import ModuleType
from typing import Callable, Iterable, Iterator, TypedDict, cast

LOG = logging.getLogger(__name__)


class ModuleManifest(TypedDict, total=False):
    name: str
    description: str
    load_priority: int
    require_feature: list[str]
    define_feature: dict[str, bool]
    maintainer: str
    demo_data: dict[str, list[str]]  
    # Maps demo profile to demo data.
    # The "default" profile is always loaded.


class ResourcePackageLoader:
    
    def __init__(self, enable_feature: Iterable[str], disable_feature: Iterable[str]) -> None:
        self._module_pkgs: list[str] = ["as_mgmt_resource"]  # Load the built in module by default.
        self._modules: list[str] = []
        self._imported_modules: list[tuple[ModuleType, int]] = []  # (module_obj, priority)
        self.manifests: dict[str, ModuleManifest] = {}
        
        self.enabled_features: set[str] = set(enable_feature)
        self._explicitly_disabled_features: set[str] = set(disable_feature)
        
    def find_additional_modules(self) -> None:
        # Not implemented yet.
        # TODO: Use python entrypoints mechanism to load extra modules:
        # https://setuptools.pypa.io/en/latest/userguide/entry_point.html#entry-points-for-plugins
        ...

    def load_modules(self) -> None:
        for pkg_name in self._module_pkgs:
            pkg = importlib.import_module(pkg_name)
            for _, name, is_pkg in pkgutil.iter_modules(pkg.__path__, pkg.__name__ + "."):
                if not is_pkg:
                    LOG.warning("Non-package module(standalone .py file) %s in as_mgmt_resource is ignored", name)
                LOG.info("Found resource package %s", name)
                self._modules.append(name)
        self._load_resources()
                
    def _load_resources(self) -> None:
        for res_name in self._modules:
            res = importlib.import_module(res_name)
            priority = 10000
            if hasattr(res, '__manifest__') and isinstance(res.__manifest__, dict):
                manifest = cast(ModuleManifest, res.__manifest__)
                self.manifests[res_name] = manifest
                priority = manifest.get('load_priority', 10000)
            self._imported_modules.append((res, priority))
        self._imported_modules.sort(key=lambda x: x[1])
        for res, _ in self._imported_modules:
            if not self._check_features(self.manifests[res.__name__]):
                continue
            for _, name, is_pkg in pkgutil.iter_modules(res.__path__, res.__name__ + "."):
                if is_pkg:
                    LOG.warning("Sub-package %s in resource module %s is ignored", name, res.__name__)
                # Import all Python files in a resource module.
                # This executes all module level code,
                # and controllers, command line definitions are loaded in this phase.
                importlib.import_module(name)
    
    def iter_content(self, predicate: Callable[[str], bool]) -> Iterator[tuple[str, bytes]]:
        for module, _ in self._imported_modules:
            traversable = importlib.resources.files(module)
            assert traversable.is_dir()
            for item in traversable.iterdir():
                if item.is_file() and predicate(item.name):
                    yield item.name, item.read_bytes()
                    
    def _check_features(self, manifest: ModuleManifest) -> bool:
        if 'require_feature' in manifest:
            if not self.enabled_features.issuperset(set(manifest['require_feature'])):
                return False
        for feature, enabled in manifest.get('define_feature', {}).items():
            if enabled:
                self.enabled_features.add(feature)
        return True
            