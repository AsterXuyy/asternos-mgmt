from enum import IntEnum, Enum
from typing import Any, Mapping

from grpc import StatusCode as GrpcRespCode
from lxml.etree import Element

from as_mgmt.typing_helper import ElementType

class HttpRespCode(IntEnum):
    """
    HTTP Status code.
    Feel free to add more if the one needed is not present.
    """
    OK = 200
    CREATED = 201
    ACCEPTED = 202
    NO_CONTENT = 204
    BAD_REQUEST = 400
    UNAUTHORIZED = 401
    FORBIDDEN = 403
    NOT_FOUND = 404
    METHOD_NOT_ALLOWED = 405
    REQUEST_TIMEOUT = 408
    CONFLICT = 409
    GONE = 410
    INTERNAL_SERVER_ERROR = 500


class NetconfErrorTag(str, Enum):
    """NETCONF normative error tags"""
    IN_USE = 'in-use'
    INVALID_VALUE = 'invalid-value'
    TOO_BIG = 'too-big'
    MISSING_ATTRIBUTE = 'missing-attribute'
    BAD_ATTRIBUTE = 'bad-attribute'
    UNKNOWN_ATTRIBUTE = 'unknown-attribute'
    MISSING_ELEMENT = 'missing-element'
    BAD_ELEMENT = 'bad-element'
    UNKNOWN_ELEMENT = 'unknown-element'
    UNKNOWN_NAMESPACE = 'unknown-namespace'
    ACCESS_DENIED = 'access-denied'
    LOCK_DENIED = 'lock-denied'
    RESOURCE_DENIED = 'resource-denied'
    ROLLBACK_FAILED = 'rollback-failed'
    DATA_EXISTS = 'data-exists'
    DATA_MISSING = 'data-missing'
    OPERATION_NOT_SUPPORTED = 'operation-not-supported'
    OPERATION_FAILED = 'operation-failed'
    MALFORMED_MESSAGE = 'malformed-message'
    # 'partial-operation' is obsoleted by RFC6241 and thus not included here.


class MgmtBaseException(Exception):
    """
    Base exception class for the management framework.
    Defines the mandatory data fields for subclasses so that they can
    be properly mapped to various protocols including REST API, NETCONF and others.
    """
    netconf_error_tag: str = "operation-failed"
    # error tag defined by NETCONF protocol

    msg_format = "An internal server error occurred while processing the request."
    # A format string as defined by python string.format function, for example
    # "Failed to add {interface_name} to vlan as it is a router interface"
    # This string is formatted by the parameters of __init__, and returned in APIs.
    # For command line requests, this is printed directly onto users' terminal.

    http_status_code: int = HttpRespCode.INTERNAL_SERVER_ERROR
    # Define the http status code when accessing via HTTP(RESTful API).
    # ref: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status

    grpc_error_code: GrpcRespCode = GrpcRespCode.UNKNOWN
    # Define the grpc status code when accessing via gRPC(gNMI).
    # ref: https://grpc.github.io/grpc/core/md_doc_statuscodes.html

    error_tag: str = 'unknown'
    # Machine parsable error tag with concrete meanings.
    # Unlike the status code defined
    # 'interface.split_not_supported'

    def __init__(self, **kwargs):  # Subclasses may define actual parameters
        self._fmt_vals = kwargs
        # Use a dict to store structural error info.
        # This dict will be returned to the client and thus MUST be serializable.

    def __str__(self):
        # Human-readable message after formatting.
        return self.msg_format.format(**self._fmt_vals)
    
    @property
    def error_info(self) -> dict[str, Any]:
        # By default, provide format arguments as the detailed error data.
        # Concrete exception classes may define "data" attribute to provide custom error detail. 
        return self.data if hasattr(self, "data") else self._fmt_vals
    
    def format_http_resp(self) -> dict:
        return {
            'error_tag': self.error_tag,
            'message': str(self),
            'data': self.error_info
        }
        
    def format_netconf_rpc_error(self) -> ElementType:
        """
        Format this exception to a NETCONF <rpc-error> XML Node.
        Ref: RFC6241 Section 4.3, <rpc-error> Element
        
        """
        rpc_error = Element('rpc-error')
        tag = Element('error-tag')
        tag.text = self.netconf_error_tag
        severity = Element('error-severity')
        severity.text = 'error'
        app_tag = Element('error-app-tag')
        app_tag.text = self.error_tag
        message = Element("error-message")
        message.text = str(self)
        
        rpc_error.extend([tag, severity, app_tag, message, 
                          self._format_netconf_error_info()])
        return rpc_error

    def _format_netconf_error_info(self) -> ElementType:
        # TODO: normalize error-info according to RFC6241 Appendix A.
        xml_info = Element("error-info")
        for key, value in self.error_info.items():
            elem = Element(key)
            elem.text = str(value)
            xml_info.append(elem)
        return xml_info
        
        
class BadRequest(MgmtBaseException):
    msg_format = "Generic bad request error. Detail not provided."
    http_status_code = 400
    grpc_error_code = GrpcRespCode.INVALID_ARGUMENT
    netconf_error_tag = NetconfErrorTag.BAD_ELEMENT


class ResourceNotFound(MgmtBaseException):
    """Raised when controller implementations failed to find a requested resource."""
    
    msg_format = "{resource_type} not found: {key_info}"
    http_status_code = 404
    grpc_error_code = GrpcRespCode.NOT_FOUND
    netconf_error_tag = NetconfErrorTag.UNKNOWN_ELEMENT
    
    error_tag = "app.not_found"
    
    def __init__(self, resource_type: str, keys: dict[str, Any]):
        self.data = {
            'resource_type': resource_type,
            'keys': keys
        }
        super().__init__(
            resource_type=resource_type, 
            key_info=', '.join(f"{key}={value}" for key, value in keys.items())
        )
        

class InvalidResource(BadRequest):
    """
    Raised when controller implementations find a resource not acceptable,
    which typically fails an additional check
    This exception is intended for user application code and should not be used by the API framework.
    """
    
    msg_format = "Found invalid {resource_type} instance: {error}"
    error_tag = "app.invalid_resource"
    
    def __init__(self, resource_type: str, resource_content: Mapping[Any, Any], error: str):
        self.data = {
            "resource_type": resource_type,
            "resource_content": resource_content,
            "error": error
        }
        super().__init__(resource_type=resource_type, error=error)
        

class DuplicateResource(BadRequest):
    """
    Raised when a controller finds a duplicate resource, typically in "create" method.
    """
    
    msg_format = "Found duplicate {resource_type} instance: {error}"
    error_tag = "app.duplicate_resource"
    
    def __init__(self, resource_type: str, keys: dict[str, Any]):
        self.data = {
            'resource_type': resource_type,
            'keys': keys
        }
        super().__init__(
            resource_type=resource_type, 
            key_info=', '.join(f"{key}={value}" for key, value in keys.items())
        )
    