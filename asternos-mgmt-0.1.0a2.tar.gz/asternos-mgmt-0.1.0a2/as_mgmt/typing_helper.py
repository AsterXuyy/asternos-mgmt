from typing import Union, Any
from lxml.etree import _Element, _Comment  # noqa
from ncclient.operations.rpc import RPCError as NetconfRPCError  # type: ignore[import]

ElementType = _Element
CommentElementType = _Comment

DataNodeType = Union[Any, list['DataNodeType'], dict[str, 'DataNodeType']]

JsonSerializableType = Union[str, int, float, bool, list['DataNodeType'], dict[str, 'DataNodeType']]

SimpleJsonType = Union[str, int, float, bool]

NetconfRPCError = NetconfRPCError  # pylint: disable=self-assigning-variable
                                   # Suppress "unused-import" warning
