import copy
import logging
from io import BytesIO
from typing import Iterable

from lxml.etree import _Element, iterparse
from typing_extensions import TypeAlias

from as_mgmt.parser import exc
from .elements import (
    DataType, DecimalType, LeafRefType, RootNode, YANGElement, EnumType, IntegerType, StringType, Range, Pattern,
    LeafNode, ContainerNode, ListNode, Module, UnionType, AugmentNode
)

LOG = logging.getLogger(__name__)

ElementType: TypeAlias = _Element


def _xml_node_clean_get(node: ElementType, name: str) -> str:
    val = node.get(name)
    assert val is not None
    return val


def parse_typedef(xml_root: ElementType, parent: YANGElement):
    """Parse a YANG typedef statement and register new datatype accordingly"""
    assert xml_root.tag == 'typedef'
    type_name: str = _xml_node_clean_get(xml_root, 'name')
    for child in xml_root:
        if child.tag == "type":
            data_type = parse_type(child, parent)
            data_type.name = type_name
            return data_type
    raise exc.InvalidModelException(
        f"typedef statement with typename {type_name} does not have a type definition"
    )


def parse_type(node: ElementType, parent: YANGElement) -> DataType:
    """Parse a YANG type statement, typically with type narrowing"""
    base_type_name: str = _xml_node_clean_get(node, 'name')
    base_type = parent.lookup(base_type_name)
    if not isinstance(base_type, DataType):
        raise exc.InvalidModelException(f"Referenced name {base_type_name} is not a data type")
    if len(node) == 0:
        return base_type  # a direct reference, no narrowing

    new_type = copy.deepcopy(base_type)
    new_type.set_parent(parent)
    if isinstance(new_type, EnumType):
        for child in node:
            if child.tag == "enum":
                # Add extra options for enum types
                new_type.options.append(_xml_node_clean_get(child, 'name'))
        return new_type
    elif isinstance(new_type, IntegerType):
        for child in node:
            if child.tag == 'range':
                range_node = Range.from_yin_node(child, int)
                new_type.range = range_node
        return new_type
    elif isinstance(new_type, StringType):
        for child in node:
            if child.tag == 'length':
                range_node = Range.from_yin_node(child, int)
                new_type.length = range_node
            elif child.tag == "pattern":
                pattern_node = Pattern.from_yin_node(child)
                new_type.patterns.append(pattern_node)
        return new_type
    elif isinstance(new_type, DecimalType):
        for child in node:
            if child.tag == 'fraction-digits':
                pass  # fraction-digits is intentionally ignored. we use float to represent decimals
            if child.tag == 'range':
                range_node_float = Range.from_yin_node(child, float)
                new_type.range = range_node_float
        return new_type
    elif isinstance(new_type, LeafRefType):
        for child in node:
            if child.tag == 'require-instance':
                pass  # require-instance is intentionally ignored.
                      # run-time check of reference is not implemented.
            if child.tag == 'path':
                path = child.get("value")
                assert path is not None
                new_type.path = path.split('/')
                new_type.is_absolute = path.startswith('/')
        return new_type
    elif isinstance(new_type, UnionType):
        for child in node:
            assert child.tag == "type"
            new_type.add_member(parse_type(child, parent=new_type))
        return new_type
    else:
        raise TypeError("Unrecognized type")


def parse_leaf(node: ElementType, parent: YANGElement):
    assert node.tag == "leaf" or node.tag == 'leaf-list'
    obj = LeafNode()
    obj.set_parent(parent)
    obj.name = _xml_node_clean_get(node, 'name')
    obj.is_list = node.tag == 'leaf-list'
    for child in node:
        if child.tag == 'type':
            obj.type = parse_type(child, parent)
        elif child.tag == "default":
            # FIXME: This is broken for UnionType because we can't statically determine a py_type for it.
            obj.default = obj.type.py_type(child.get('value'))
        elif child.tag == 'config':
            obj.config = child.get('value') == 'true'
        elif child.tag == 'mandatory':
            obj.mandatory = child.get('value') == 'true'
        elif child.tag == 'if-feature':
            obj.feature = child.get('name')
    return obj


def _parse_subnode(parent: YANGElement, child_node: ElementType):
    if child_node.tag == 'leaf' or child_node.tag == 'leaf-list':
        leaf = parse_leaf(child_node, parent)
        parent.set_local(leaf.name, leaf)
    elif child_node.tag == 'container':
        nested_container = parse_container(child_node, parent)
        parent.set_local(nested_container.name, nested_container)
    elif child_node.tag == 'list':
        list_node = parse_list(child_node, parent)
        parent.set_local(list_node.name, list_node)


def parse_container(node: ElementType, parent: YANGElement) -> ContainerNode:
    assert node.tag == "container"
    container = ContainerNode()
    container.set_parent(parent)
    container.name = _xml_node_clean_get(node, 'name')
    child_node: ElementType
    for child_node in node:
        _parse_subnode(container, child_node)
    return container


def parse_list(node: ElementType, parent: YANGElement) -> ListNode:
    assert node.tag == "list"
    list_node = ListNode()
    list_node.set_parent(parent)
    list_node.name = _xml_node_clean_get(node, 'name')
    child_node: ElementType
    for child_node in node:
        _parse_subnode(list_node, child_node)
        if child_node.tag == 'key':
            list_node.keys.extend(_xml_node_clean_get(child_node, 'value').split(' '))
        elif child_node.tag == 'unique':
            list_node.unique_fields.extend(_xml_node_clean_get(child_node, 'tag').split(' '))
    return list_node


def parse_augment(node: ElementType, parent: YANGElement) -> AugmentNode:
    assert node.tag == "augment"
    path = _xml_node_clean_get(node, 'target-node')
    is_absolute = path.startswith('/')
    augment_node = AugmentNode(path.split('/'), is_absolute)
    augment_node.set_parent(parent)
    augment_node.name = path
    # Augment nodes are anonymous and can't be referenced 
    # Here we just use path as name to store in local namespace so we can evaluate its target later.
    for child_node in node:
        _parse_subnode(augment_node, child_node)
    return augment_node


def parse_module(module_name: str, parent: YANGElement, module_index: dict[str, ElementType]) -> Module:
    """

    :param module_name: name of the module to import
    :param parent: parent node, i.e. the root node of parsing context
    :param module_index: a dict mapping module name to module XML nodes.
    :return:
    """
    if parent.has_local(module_name):
        obj = parent.lookup(module_name)
        assert isinstance(obj, Module)
        return obj
    if module_name not in module_index:
        raise KeyError(f"Importing unknown module {module_name}")
    node = module_index[module_name]
    assert node.tag[-6:] == "module"  # [-6:] drops xml namespace prefix
    module = Module()
    module.set_parent(parent)
    module.name = _xml_node_clean_get(node, 'name')

    child_node: ElementType
    for child_node in node:
        if child_node.tag == 'prefix':
            module.prefix = _xml_node_clean_get(child_node, 'value')
        elif child_node.tag == 'organization':
            for org_subnode in child_node:
                if org_subnode.tag == "text":
                    assert org_subnode.text is not None
                    module.organization = org_subnode.text.strip()
        elif child_node.tag == 'typedef':
            typedef = parse_typedef(child_node, module)
            module.set_local(typedef.name, typedef)
        elif child_node.tag == 'container':
            container = parse_container(child_node, module)
            module.set_local(container.name, container)
        elif child_node.tag == 'import':
            external_module = parse_module(_xml_node_clean_get(child_node, 'module'), parent, module_index)
            # TODO: Check cyclic import and avoid stack overflow.
            prefix: str = _xml_node_clean_get(child_node[0], 'value')
            for name, elem in external_module.items():
                if ':' not in name:  # Otherwise, the name is imported from another module.
                    module.set_local(f"{prefix}:{name}", elem)
        elif child_node.tag == "augment":
            augment = parse_augment(child_node, module)
            module.set_local(augment.name, augment)
    parent.set_local(module.name, module)
    return module


def resolve_leafref_and_augment(node: YANGElement):
    for _, child in node.items():
        if isinstance(child, (ListNode, ContainerNode, Module)):
            resolve_leafref_and_augment(child)
        elif isinstance(child, LeafNode) and isinstance(child.type, LeafRefType):
            path = child.type.path
            referee = resolve_reference(child, path, child.type.is_absolute)
            if not isinstance(referee, LeafNode):
                raise ValueError(f"Leafref {'/'.join(path)} is not valid. "
                                 f"Target should be leaf, got {referee.kind} instead.")
            child.type.target = referee
        elif isinstance(child, AugmentNode):
            referee = resolve_reference(child, child.path, child.is_absolute)
            if not isinstance(referee, (ContainerNode, ListNode, Module)):
                raise ValueError(f"Augment {'/'.join(path)} is not valid. "
                                 f"Target should be container, list or module, got {referee.kind} instead.")
            for augment_name, augment_node in child.items():
                referee.set_local(augment_name, augment_node)
        

def resolve_reference(referrer: YANGElement, path: list[str], is_absolute: bool):
    kind = referrer.kind
    curr = referrer
    if is_absolute:  # resolve to root node if using absolute path.
        while curr.get_parent():
            curr = curr.get_parent()
    for elem in path:
        if elem == '.' or elem == '': # we allow duplicated '/' in path, e.g "a//b/.///./c" == "a/b/c"
            continue
        elif elem == '..':
            parent = curr.get_parent()
            if parent is not None:   # Otherwise, this is root node. using '..' on root node has no effect
                curr = parent
            if isinstance(curr, Module) and isinstance(curr.get_parent(), RootNode):
                # special-casing modules because they don't count as a level in xpath expressions
                curr = curr.get_parent()
        elif isinstance(curr, RootNode):
            # special-casing modules again because they don't count as a level in xpath expressions
            for module in curr.iter_locals():
                if module.has_local(elem):
                    curr = module.lookup_local(elem)
                    break
            else:
                raise ValueError(
                    f"{kind} {'/'.join(path)} is not valid, failed to resolve part '{elem}'."
                )
        else:
            if not curr.has_local(elem):
                raise ValueError(
                    f"{kind} {'/'.join(path)} is not valid, failed to resolve part '{elem}'."
                )
            curr = curr.lookup_local(elem)
    return curr


def prepare_modules(nodes: Iterable[ElementType]) -> dict[str, ElementType]:
    result = {}
    for module_node in nodes:
        result[_xml_node_clean_get(module_node, 'name')] = module_node
    return result


def parse_xml(text: str) -> ElementType:
    xml_iter = iterparse(BytesIO(text.encode('utf-8')))
    for _, elem in xml_iter:
        _, _, elem.tag = elem.tag.rpartition('}')  # strip "xmlns"
    return xml_iter.root
