from __future__ import annotations

import abc
import copy
import re
from typing import Callable, Iterable, TypeVar, Generic, Type, Optional, Any, Union
from typing_extensions import Self

from as_mgmt.parser import exc
from as_mgmt.typing_helper import ElementType

T = TypeVar("T")

_INT_ABS_MAX = 2 ** 64


class YANGElement(metaclass=abc.ABCMeta):
    kind: str = "unknown_yang_element"
    # Element type, such as "module", "type", "container", "list", "leaf"

    name: str
    # Plain object name, such as: port, common, interface.

    def __repr__(self):
        return f"<YANG {self.kind} {self.name}>"

    _parent: Optional['YANGElement']

    _globals: dict[str, 'YANGElement']
    _locals: dict[str, 'YANGElement']
    # dicts used to store name scopes of a module.
    # "global" scope contains identifiers globally visible, typically built-in identifiers
    # "local" scope contains identifiers only visible in the current context.

    when: Optional[str]
    # Usually introduced by "when" statements,
    # this is used by verifier generators to determine if this field is usable at runtime
    # according to the feature flags given by applications.

    feature: Optional[str]

    # Typically introduced by "if-feature" statement, this is used by the server to
    # toggle features according to, such as, ASIC platform capability.
    # Example: "(not foo) or (bar and baz)",
    # where foo, bar, baz are feature flags that may be toggled by the server at startup.

    def __init__(self):
        self.name = '__anonymous__'
        self._globals = {}
        self._locals = {}
        self._parent = None
        self.when = self.feature = ""
        # TODO: verify when and feature by property setters.

    def set_parent(self, parent: 'YANGElement'):
        self._globals = parent._globals  # pylint: disable=protected-access
        self._parent = parent

    def lookup(self, name: str) -> 'YANGElement':
        """
        Lookup a name in the scope of this element.
        """
        prefix = self.lookup_module_prefix()
        if name.startswith(f"{prefix}:"):
            # We supports two lookup method for names in local module.
            # 1. Use name directly, e.g. "ipv4-prefix"
            # 2. Use with prefix declared in module prefix statement: "inet:ipv4-prefix"
            # Prefixes are always required when accessing imported objects. 
            name = name[len(prefix)+1:]
        if hasattr(self, name):
            return getattr(self, name)
        if name in self._locals:
            return self._locals[name]
        parent = self._parent
        while parent is not None:
            if name in parent._locals:        # pylint: disable=protected-access
                return parent._locals[name]   # pylint: disable=protected-access
            parent = parent._parent           # pylint: disable=protected-access
        if name in self._globals:
            return self._globals[name]
        raise NameError(f"Undefined symbol '{name}' in YANG {self.kind} {self.name}")

    def set_local(self, name: str, value: 'YANGElement'):
        self._locals[name] = value

    def set_global(self, name: str, value: 'YANGElement'):
        self._globals[name] = value

    def items(self):
        """Iterate over local namespace, i.e. sub-statements"""
        return self._locals.items()

    def has_local(self, name: str):
        prefix = self.lookup_module_prefix()
        if name.startswith(f"{prefix}:"):
            name = name[len(prefix)+1:]
        return name in self._locals
    
    def get_parent(self):
        return self._parent
    
    def lookup_local(self, name: str) -> 'YANGElement':
        prefix = self.lookup_module_prefix()
        if name.startswith(f"{prefix}:"):
            name = name[len(prefix)+1:]
        if name in self._locals:
            return self._locals[name]
        raise NameError(f"Undefined symbol '{name}' in YANG {self.kind} {self.name} when parsing xpath")
    
    def iter_locals(self) -> Iterable[YANGElement]:
        for local in self._locals.values():
            yield local
    
    def lookup_module_prefix(self) -> str:
        parent = self
        while parent is not None:
            if isinstance(parent, Module):
                return parent.prefix
            parent = parent.get_parent()
        return ""
    
    @property
    def orig_qualified_name(self) -> str:
        """
        Original qualified name, not affected by import statements.
        Useful for constructing mapping between YANG elements and python type.
        """
        names = [self.name]
        parent = self._parent
        while parent is not None and not isinstance(parent, RootNode):
            names.append(parent.name) 
            parent = parent._parent  # pylint: disable=protected-access
        return ":".join(names[::-1])


class Module(YANGElement):
    """Represents a YANG module object"""
    kind = "module"

    def __init__(self):
        super().__init__()
        self._prefix: Optional[str] = None
        self.organization = "__unknown__"
        
    @property
    def prefix(self) -> str:
        """Default identifier prefix of objects in this module."""
        assert self._prefix is not None, "Missing prefix for module object"
        return self._prefix
    
    @prefix.setter
    def prefix(self, value: str):
        self._prefix = value


class ConstraintType(YANGElement):
    kind = 'constraint_type'


class DataType(YANGElement, Generic[T], metaclass=abc.ABCMeta):
    """YANG Data types, either builtin or defined by user using a typedef statement"""
    kind = "type"

    py_type: Type[T]
    # Python type used to hold the value

    value: Optional[T]
    # Data value
    
    @abc.abstractmethod
    def generate_verifier(self) -> Callable[[Union[str, float, bool]], Union[str, float, bool]]:
        """
        Verify and convert data types.
        We allow loose types with string(e.g. "10" is a valid int) because 
        command-line input are untyped and always string
        """
        

RT = TypeVar("RT", str, int, float, bool)


class DataVerifier(YANGElement):
    error_app_tag: Optional[str]
    error_message: Optional[str]

    def __init__(self):
        super().__init__()
        self.error_app_tag = None
        self.error_message = None

    def _parse_err_msg(self, node: ElementType) -> Self:
        for child in node:
            if child.tag == 'error-app-tag':
                self.error_app_tag = child.get('value')
            elif child.tag == 'error-message':
                assert child[0].text is not None
                self.error_message = child[0].text.strip()
                # typical xml text will contain many spaces and line breaks around them.
                # we use "strip" method to get rid of them.
        return self


class Range(DataVerifier, Generic[RT]):
    """
    RFC 7950: section 9.2.4.1, 9.2.5
    YANG Range statement.
    the border of the range can be an integer or floating point number
    """

    value: set[tuple[RT, RT]]
    # one or more (closed) intervals of valid values
    # example:
    # "1..4" -> {(1, 4)}
    # "1..100|200|300..400" -> {(1, 100), (200,200), (300, 400)}

    def __init__(self, value_type: Type[RT]):
        super().__init__()
        self.value_type: Type[RT] = value_type
        self.value = set()

    @classmethod
    def from_yin_node(cls, node: ElementType, content_type: Type[RT]) -> 'Range[RT]':
        obj = cls(content_type)
        obj._parse_err_msg(node)
        range_val = node.get("value")
        if range_val is None:
            raise exc.InvalidModelException("Range value not specified")
        obj._parse_range(range_val)
        return obj

    def _parse_range(self, range_val: str):
        # TODO: Add support for "min" "max" value: min..-1|1..max
        sections: list[str] = range_val.split('|')
        for single_range in sections:
            from_, _, to_ = single_range.partition('..')
            if not to_:
                self.value.add((self.value_type(from_), self.value_type(from_)))
            elif to_ == 'max':
                self.value.add((self.value_type(from_), self.value_type(2**64)))
            else:
                self.value.add((self.value_type(from_), self.value_type(to_)))
            
    def __str__(self) -> str:
        ranges: list[str] = []
        for lower, upper in self.value:
            if upper == _INT_ABS_MAX:
                ranges.append(f"[{lower}, +inf)")
            if upper == lower:
                ranges.append(f"{upper}")
            else:
                ranges.append(f"[{lower}, {upper}]")
        return ', '.join(ranges)
    
    def verify(self, value: Any, name: str) -> None:
        if not self.value:
            return
        for lower, upper in self.value:
            if lower <= value <= upper:
                return
        raise ValueError(f"{name} not within range {self}")


class Pattern(DataVerifier):
    """
    RFC 7950: section 9.4.5
    YANG Pattern statement, a regular expression to verify string argument
    """

    value: str
    invert: bool
    # If true, strings that does not match the given expression pass the check.

    def __init__(self):
        super().__init__()
        self.value = ""
        self.invert = False

    @classmethod
    def from_yin_node(cls, node: ElementType) -> 'Pattern':
        obj = cls()
        obj._parse_err_msg(node)
        value = node.get("value")
        assert value is not None
        obj.value = value
        if len(node) and node[0].tag == 'modifier' and node[0].get("value") == 'invert-match':
            obj.invert = True
        return obj


class IntegerType(DataType):
    """
    Integer types defined by YANG models and typedefs based on them.
    RFC 7950 section 9.2
    """
    py_type = int

    range: Range[int]
    # User defined integer range definition.

    _intrinsic_range: Optional[tuple[int, int]]
    # Since python does not have sized integer types,
    # we use this extra range to emulate ranged integer types(uint8, int32...) defined by YANG standard.

    def __init__(self, intrinsic_range=None):
        super().__init__()
        self.range = Range(int)  # empty range
        self._intrinsic_range = intrinsic_range
        
    def _verify(self, value):
        value = int(value)
        if self._intrinsic_range:
            lower, upper = self._intrinsic_range
            if not lower <= value <= upper:
                raise ValueError(f"Value not within range [{lower}, {upper}]")
        if self.range:
            self.range.verify(value, "Value")
        return value
        
    def generate_verifier(self):
        return self._verify


class StringType(DataType):
    py_type = str

    length: Range
    patterns: list[Pattern]
    # a list regular expressions to verify the string, as defined by RFC 7950 section 9.4.5

    def __init__(self):
        super().__init__()
        self.length = Range(int)
        self.patterns = []
        
    def _verify(self, value):
        if not isinstance(value, str):
            raise TypeError(f"Expected type str, got {type(value).__name__}")
        for pattern in self.patterns:
            matched = bool(re.match(pattern.value, value))
            if matched and pattern.invert:
                raise ValueError(f"Matched pattern {pattern.value}")
            if not matched and not pattern.invert:
                raise ValueError(f"Can't match pattern {pattern.value}")
        if self.length:
            self.length.verify(len(value), "Length")
        return value
        
    def generate_verifier(self):
        return self._verify


class BooleanType(DataType[bool]):
    py_type = bool
    
    def _verify(self, value):
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            if value.lower() == "true":
                return True
            elif value.lower() == "false":
                return False
            else:
                raise ValueError(f"Could not determine the truthiness of string '{value}'")
        else:
            raise ValueError(f"Could not determine the truthiness of'{value}'")
        
    def generate_verifier(self):
        return self._verify


class EnumType(DataType[str]):
    py_type = str

    options: list[str]

    def __init__(self):
        super().__init__()
        self.options = []
        
    def _verify(self, value):
        if not isinstance(value, str):
            raise TypeError(f"Expecting string(enum), got {type(value).__name__}")
        if value not in self.options:
            raise ValueError(f"'{value}' is not a valid enum option")
        return value
        
    def generate_verifier(self):
        return self._verify


class BinaryType(DataType[bytes]):
    py_type = bytes

    length: Optional[Range]
    
    def _verify(self, value):
        raise NotImplementedError("Binary types are currently not supported")
        
    def generate_verifier(self):
        return self._verify
    

class DecimalType(DataType[float]):
    """
    Float number types.
    YANG defines decimal64 as a fixed-point decimal type,
    but we just use floats for simplicity.
    gNMI also uses floats, so this doesn't affect protocol implementation.
    """
    
    py_type = float

    range: Range[float]
    # User defined integer range definition.

    _intrinsic_range: Optional[tuple[int, int]]
    # Since python does not have sized integer types,
    # we use this extra range to emulate ranged integer types(uint8, int32...) defined by YANG standard.

    def __init__(self):
        super().__init__()
        self.range = Range(float)
    
    def _verify(self, value):
        value = float(value)
        if self.range:
            self.range.verify(value, "Value")
        return value
        
    def generate_verifier(self):
        return self._verify
    

class UnionType(DataType[Any]):
    _member_types: list[DataType]
    
    def __init__(self):
        super().__init__()
        self._member_types = []
        
    def add_member(self, member: DataType):
        self._member_types.append(member)
        
    def _chain_verifiers(self, verifiers):
        def _verify(value):
            exceptions = []
            for verifier in verifiers:
                try:
                    return verifier(value)
                except Exception as err:  # pylint: disable=broad-except
                    exceptions.append(err)
            # TODO: Raise a special error type that wraps all errors in the union type.
            raise exceptions[-1]
        return _verify
        
    def generate_verifier(self):
        return self._chain_verifiers([member.generate_verifier() for member in self._member_types])


class LeafRefType(DataType[str]):
    # py_type of this type is determined later when resolving the referenced node.
    path: list[str]
    is_absolute: bool
    _target: Optional[LeafNode]
    
    def __init__(self):
        super().__init__()
        self._target = None
        self.path = []
        self.is_absolute = False
        
    def generate_verifier(self):
        return self.target.type.generate_verifier()
    
    @property
    def target(self) -> LeafNode:
        if self._target is None:
            raise ValueError("Leafref target not resolved")
        return self._target
    
    @target.setter
    def target(self, value: LeafNode):
        self._target = value


class IdentityRefType(DataType[str]):
    """
    NOT IMPLEMENTED
    Reference identity objects, as defined by RFC7950 section 7.10
    This can be regarded as a fancy enum type with multiple-inheritance support.
    """
    py_type = str
    name: str


class EmptyType(DataType[None]):

    def generate_verifier(self):
        def raise_error(_):
            raise TypeError("Empty leaf node can not have any value.")
        
        return raise_error


class LeafNode(YANGElement):
    type: DataType

    default: Any
    config: bool
    mandatory: bool
    is_list: bool

    def __init__(self):
        super().__init__()
        self.default = None
        self.config = True
        self.is_list = self.mandatory = False
        self.type = EmptyType()


class ListNode(YANGElement):
    kind = 'list'

    keys: list[str]
    unique_fields: list[str]

    def __init__(self):
        super().__init__()
        self.keys = []
        self.unique_fields = []


class GroupingNode(YANGElement):
    kind = "grouping"


class ContainerNode(YANGElement):
    kind = "container"
    
    
class AugmentNode(YANGElement):
    """
    YANG Augment statement, defined by RFC7950 section 7.17
    Reference resolve routine copies its child elements to the target path 
    """
    
    kind = "augment"
    
    path: list[str]
    is_absolute: bool
    
    def __init__(self, path: list[str], is_absolute: bool):
        super().__init__()
        self._target = None
        self.path = path
        self.is_absolute = is_absolute


BUILTIN_TYPES: dict[str, YANGElement] = {
    'uint8': IntegerType((0, 255)),
    'uint16': IntegerType((0, 65535)),
    'uint32': IntegerType((0, 2 ** 32 - 1)),
    'uint64': IntegerType((0, 2 ** 64 - 1)),

    'int8': IntegerType((-128, 127)),
    'int16': IntegerType((-32768, 32767)),
    'int32': IntegerType((-2 ** 31, 2 ** 31 - 1)),
    'int64': IntegerType((-2 ** 63, 2 ** 64 - 1)),

    'binary': BinaryType(),
    'boolean': BooleanType(),
    'enumeration': EnumType(),
    'string': StringType(),
    'decimal64': DecimalType(),

    'leafref': LeafRefType(),
    'union': UnionType(),
    'empty': EmptyType()
}

__KEY = __VALUE = None
for __KEY, __VALUE in BUILTIN_TYPES.items():
    __VALUE.name = __KEY
    
del __KEY, __VALUE


class RootNode(YANGElement):
    """
    An empty root node, used to initialize parsing context.
    """
    kind = 'root'

    def __init__(self):
        super().__init__()
        self._globals = copy.copy(BUILTIN_TYPES)
