import io
import logging

from pyang.context import Context
from pyang.repository import Repository
from pyang.statements import validate_module
from pyang.translators.yin import emit_yin
from pyang.yang_parser import YangParser
from pyang.error import err_to_str

LOG = logging.getLogger(__name__)


class _Opts:
    yin_canonical = True
    yin_pretty_strings = True


class ManualRepository(Repository):
    """
    Pyang uses repositories to store YANG modules scattered in different files.
    """
    # The original implementation searches file system according to command line options and env variables.
    # This is not what we need here, so we manually discovery the files and add them to the repo object.

    def __init__(self):
        self.yang_data: dict[str, str] = {}
        
    def add(self, name: str, text: str) -> None:
        self.yang_data[name] = text

    def get_modules_and_revisions(self, ctx):
        return [
            (name, "", name)
            for name in self.yang_data
        ]

    def get_module_from_handle(self, handle: str):
        return self.yang_data[handle]


class Compiler:
    """
    Converts YANG model to YIN XML document,
    which is then used as the intermediate representation for verification and code generation.
    """

    def __init__(self, repo: ManualRepository):
        
        self._ctx = Context(repo)
        self._ctx.opts = _Opts()
        self._parser = YangParser()

    def compile_yin(self) -> list[str]:
        """
        Compile YANG models to YIN XML files.
        """
        modules = {}
        for module_name, _, handle in self._ctx.repository.get_modules_and_revisions(self._ctx):
            modules[module_name] = self._parser.parse(
                self._ctx, handle,
                self._ctx.repository.get_module_from_handle(handle)
            )
        yin_data = []
        for module_name, module_stmt in modules.items():
            if module_stmt is None:
                LOG.error("Encountered invalid module %s", module_name)
                for err in self._ctx.errors:
                    LOG.error(err_to_str(err[1], err[2]))
                    LOG.error(err[0].label())
                raise ValueError("Parse failed.")
            validate_module(self._ctx, module_stmt)
            stream = io.StringIO()
            emit_yin(self._ctx, module_stmt, stream)
            yin_data.append(stream.getvalue())
        return yin_data
    