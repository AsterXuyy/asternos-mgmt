
class InvalidModelException(ValueError):
    pass


class NotImplementedModelException(ValueError, NotImplementedError):
    pass
