import logging
from typing import Callable

from as_mgmt.app.registry import ModuleMetadata, PathRegistry, PathNode
from as_mgmt.parser import elements
from as_mgmt.serdes.registry import SerdesRegistry

LOG = logging.getLogger(__name__)


def _chain_call(first:Callable, second: Callable) -> Callable:
    def _chained(*args):
        return second(first(*args))
    return _chained
    

class ModulePathLoader:
    
    def __init__(self, root: elements.RootNode):
        self.path_registry = PathRegistry()
        self.serdes_registry = SerdesRegistry.instance()
        self.root = root
        
    def parse_module_to_path_registry(self):
        for _, elem in self.root.items():
            if isinstance(elem, elements.Module):
                # module names are not used in resource URL or tree.
                self.path_registry.modules.add(ModuleMetadata(elem.name, elem.organization, version="v1"))
                # We have not yet added support for multiple versions.
                # Use a fixed "v1" version string is enough for now.
                self._load_into_registry(elem, [])
    
    def _construct_type_processors(self, type_obj: elements.DataType) -> tuple[Callable, Callable]:
        verifier = type_obj.generate_verifier()
        ser, des = self.serdes_registry.get_api_serdes(type_obj.orig_qualified_name)
        return ser, _chain_call(verifier, des)
    
    def _load_into_registry(self, elem: elements.YANGElement, path: list[str]) -> None:
        sub_containers = {}
        sub_lists = {}
        has_leaf = False
        for name, obj in elem.items():
            if isinstance(obj, elements.LeafNode):
                assert not isinstance(obj, elements.Module)
                type_obj = obj.type
                ser, des = self._construct_type_processors(type_obj)
                node = PathNode(
                    node_type='leaf_list' if obj.is_list else "leaf",
                    serializer=ser, deserializer=des
                )
                self.path_registry.tree.add(path + [name], node)
                has_leaf = True
            elif isinstance(obj, elements.ContainerNode):
                sub_containers[name] = obj
            elif isinstance(obj, elements.ListNode):
                sub_lists[name] = obj
        if isinstance(elem, elements.ContainerNode):
            assert len(sub_lists) <= 1
            # assertion failure should never happen if YANG validator works correctly
            is_list_wrap = (len(sub_lists) == 1)
            if is_list_wrap and has_leaf:
                raise ValueError("Container with list may not have leaf nodes")
            node = PathNode(node_type="container", list_wrap_container=is_list_wrap)
            self.path_registry.tree.add(path, node)
        if isinstance(elem, elements.ListNode):
            assert not sub_lists
            node = PathNode(node_type="list", list_keys=elem.keys)
            self.path_registry.tree.add(path, node)
        for name, container in sub_containers.items():
            self._load_into_registry(container, path + [name])
        for name, list_node in sub_lists.items():
            self._load_into_registry(list_node, path + [name])
