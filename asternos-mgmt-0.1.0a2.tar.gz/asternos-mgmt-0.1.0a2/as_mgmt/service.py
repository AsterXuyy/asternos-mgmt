import asyncio
import logging
import os
import secrets
import signal
import sys

from tornado.httpserver import HTTPServer
from as_mgmt.config import setup_config

import as_mgmt.http.request
import as_mgmt.cli.server
import as_mgmt.gnmi.request
from as_mgmt.log import setup_logging
from as_mgmt.app.registry import PathRegistry
from as_mgmt.app.proto_server import ProtoServer
from as_mgmt.loader import ResourcePackageLoader
from as_mgmt.netconf.protocol import NetconfServer
from as_mgmt.parser import yang, yin, elements, loader

from .config import cfg

LOG = logging.getLogger(__name__)


def load_resource_namespace() -> PathRegistry:
    os.makedirs(os.path.expanduser("~/.as-mgmt/klish/"), exist_ok=True)
    yang_repo = yang.ManualRepository()
    pkg_loader = ResourcePackageLoader([], [])
    pkg_loader.find_additional_modules()
    pkg_loader.load_modules()
    for name, content in pkg_loader.iter_content(lambda x: x.endswith('.yang')):
        yang_repo.add(name, content.decode('utf-8'))
    for name, content in pkg_loader.iter_content(lambda x: x.endswith('.xml') or x.endswith(".xsd")):
        # Put all klish XML definitions to a centralized place
        # so it can be loaded by Klish process later.
        path = os.path.expanduser(f'~/.as-mgmt/klish/{name}')
        with open(path, "wb") as fd:
            fd.write(content)
        
    compiler = yang.Compiler(yang_repo)
    yin_data = compiler.compile_yin()
    yang_modules = yin.prepare_modules([yin.parse_xml(module_xml) for module_xml in yin_data])
    root = elements.RootNode()
    for key in yang_modules:
        yin.parse_module(key, root, yang_modules)
    yin.resolve_leafref_and_augment(root)
    registry_loader = loader.ModulePathLoader(root)
    registry_loader.parse_module_to_path_registry()
    path_registry = registry_loader.path_registry
    path_registry.set_inst_controllers()
    path_registry.set_inst_commands()
    return path_registry


def init_key() -> str:
    os.makedirs(os.path.expanduser("~/.as-mgmt/"), exist_ok=True)
    with open(os.path.expanduser('~/.as-mgmt/cli-secret-key'), 'w', encoding='utf-8') as fd:
        key = secrets.token_hex(128)
        fd.write(key)
        return key


def _install_signal_handlers(shutdown_fut: asyncio.Future[int]):
    def _handler():
        if shutdown_fut.done():
            LOG.warning("Received SIGINT or SIGTERM more than once. Forcefully shutting down.")
            sys.exit(-1)
        LOG.info("Received SININT or SIGTERM. Shutting down gracefully...")
        shutdown_fut.set_result(0)
    
    loop = asyncio.get_event_loop()
    loop.add_signal_handler(signal.SIGINT, _handler)
    loop.add_signal_handler(signal.SIGTERM, _handler)


async def loop_main(reg: PathRegistry):
    proto_server = ProtoServer(reg)
    http_app = as_mgmt.http.request.make_app(proto_server)
    http_server = HTTPServer(http_app, ssl_options=as_mgmt.http.request.create_ssl_context())
    http_server.listen(cfg.http.port, cfg.http.address)
    netconf_server = NetconfServer(proto_server)
    cli_server = HTTPServer(
        as_mgmt.cli.server.make_cli_app(proto_server),
        ssl_options=as_mgmt.http.request.create_ssl_context()
    )
    cli_server.listen(8089, '127.0.0.1', reuse_port=True)
    grpc_server = as_mgmt.gnmi.request.make_grpc_server(proto_server)
    http_server.start()
    await netconf_server.run()
    cli_server.start()
    proto_server.run()
    await grpc_server.start()
    
    shutdown_fut = asyncio.Future[int]()
    _install_signal_handlers(shutdown_fut)
    await shutdown_fut
    
    LOG.info("Gracefully shutting down management server ...")
    LOG.info("Shutting down HTTP server ...")
    http_server.stop()
    LOG.info("Shutting down command line server ...")
    cli_server.stop()
    LOG.info("Shutting down NETCONF server ...")
    await netconf_server.stop()
    LOG.info("Shutting down gNMI server ...")
    await grpc_server.stop(grace=3)
    await grpc_server.wait_for_termination()
    LOG.info("Shutting down core protocol server ...")
    await proto_server.stop()


def main():
    setup_config()
    setup_logging()
    init_key()
    reg = load_resource_namespace()
    asyncio.run(loop_main(reg))
    LOG.info("Exiting, goodbye ...")


if __name__ == "__main__":
    main()
