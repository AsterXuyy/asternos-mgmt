import asyncio
from typing import Iterable, TypeVar, Generic, AsyncIterator, Any
from unittest import mock

_T = TypeVar("_T")


class MockedAsyncIterable(Generic[_T]):

    def __init__(self, iterable: Iterable[_T]):
        self._iterable = iterable
        self.calls: list[Any] = []

    async def __aiter__(self) -> AsyncIterator[_T]:
        for item in self._iterable:
            await asyncio.sleep(0)
            yield item


class MockedAsyncIterableMethod(MockedAsyncIterable, Generic[_T]):

    def __call__(self, *args, **kwargs) -> 'MockedAsyncIterableMethod':
        self.calls.append(mock.call(*args, **kwargs))
        return self
