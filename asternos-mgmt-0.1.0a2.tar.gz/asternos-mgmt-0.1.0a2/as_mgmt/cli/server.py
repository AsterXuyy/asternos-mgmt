import os
import logging

from asyncio import Future
from typing import Awaitable
from uuid import UUID, uuid4

from tornado.web import RequestHandler, Application

from as_mgmt.app.proto_server import (
    AbstractProtoServer, AbstractProtoClient, Notification, Request, 
    RequestID, RequestContext, UserClientID, Response, Action
)
from as_mgmt.typing_helper import DataNodeType

LOG = logging.getLogger(__name__)


class CommandProtoClient(AbstractProtoClient):
    _resp_futures: dict[RequestID, Future[tuple[list[Exception], DataNodeType]]]
    
    def __init__(self, server: AbstractProtoServer):
        self._server = server
        self._converter = server.get_command_protocol_converter()
        self._client_id = self._server.add_client(self)
        self._resp_futures = {}
    
    def response_callback(self, response: Response):
        assert isinstance(response, Response), "Unexpected response type"
        request_id = response.request_id
        self._resp_futures[request_id].set_result((response.exceptions, response.body))
        self._resp_futures.pop(request_id)
        
    def notification_callback(self, notification: Notification):
        raise RuntimeError("Notifications are not supported by Command line API")
    
    async def send_request(self, request_uuid: UUID, cmds: list[str]) -> tuple[str, int]:
        # TODO: Use a real user client id if required.
        try:
            datastore, path, action, body, last_cmd = self._converter.convert_from_cmds(cmds)
        except ValueError as err:
            msg = f"Error parsing command sequence {', '.join(cmds)}: {str(err)}"
            LOG.warning(msg)
            return msg, 400
        request = Request(
            self._client_id, UserClientID(""), RequestID(str(request_uuid)),
            RequestContext(), datastore, path, Action(action), body
        )
        future: Future[tuple[list[Exception], DataNodeType]] = Future()
        self._resp_futures[request.request_id] = future
        self._server.add_request(request)
        exceptions, resp_body = await future
        if exceptions:
            return last_cmd.render_errors(exceptions), 400
        else:
            try:
                return last_cmd.render(resp_body), 200
            except TypeError:  
                # Special-casing "show running-config" and "show this"
                # FIXME: This seems confusing and should be refactored.
                return self._converter.dump_data_as_commands(path, resp_body), 200


class CommandHttpEndpointHandler(RequestHandler):  # pylint: disable=abstract-method
    """Interact with command line client using HTTP"""
    
    def initialize(self, proto_client: CommandProtoClient) -> None:
        self._proto_client = proto_client
        self._request_uuid = uuid4()
        self._secret = self._load_cred()
        
    def _load_cred(self) -> str:
        with open(os.path.expanduser('~/.as-mgmt/cli-secret-key'), 'r', encoding='utf-8') as fd:
            return fd.read().strip()
        
    def _load_body(self) -> list[str]:
        if not self.request.body:
            return []
        if not self.request.headers['Content-Type'].startswith("text/plain"):
            self.set_status(400)
            self.write("Unsupported request content type, expected text/plain; charset=utf-8")
            return []
        try:
            return self.request.body.decode("utf-8").split('\n')
        except ValueError:
            self.set_status(400)
            self.write("Unsupported content encode, expected text/plain; charset=utf-8")
            return []
        
    async def _handle(self) -> None:
        self.set_header('X-Request-Id', str(self._request_uuid))
        self.set_header('Content-Type', "text/plain")
        if not self.request.headers['X-Command-Key'] == self._secret:
            self.set_status(403)
            self.write("Internal Error: Invalid credential for command server.")      
            return 
        cmds = self._load_body()
        text, code = await self._proto_client.send_request(self._request_uuid, cmds)
        self.set_status(code)
        self.write(text)
        
    def post(self) -> Awaitable[None]:
        return self._handle()


def make_cli_app(server: AbstractProtoServer):
    # NOTE: This app MUST NOT be exposed to non local hosts.
    proto_client = CommandProtoClient(server)
    return Application([
        (r"/v1/command", CommandHttpEndpointHandler, {'proto_client': proto_client})
    ])
