from as_mgmt.exc import MgmtBaseException
from as_mgmt.typing_helper import DataNodeType


class TabulateRenderer:
    
    def __call__(self, value: DataNodeType) -> str:
        return 'Not Implemented: This is a placeholder'
        
        
class SimpleRenderer:
    
    def __call__(self, value: DataNodeType) -> str:
        return 'Not Implemented: This is a placeholder'


class DictRenderer:
    
    def __call__(self, value: DataNodeType) -> str:
        return 'Not Implemented: This is a placeholder'


class ListRenderer:
    
    def __call__(self, value: DataNodeType) -> str:
        return 'Not Implemented: This is a placeholder'
    

class DumpConfigRenderer:
    
    def __call__(self, _: DataNodeType) -> str:
        raise TypeError("This config-dumping command should be rendered by server")
    

class DefaultErrorRenderer:
    def __call__(self, exceptions: list[Exception]) -> str:
        result: list[str] = []
        if not exceptions:
            return ""
        if isinstance(exceptions[0], MgmtBaseException):
            code = exceptions[0].http_status_code
        else:
            code = 500
        if code in [500, 404]:
            # We consider "404" as an internal error
            # because klish should have filtered out invalid command sequence,
            # thus this case indicates an programming error.
            result.append("Internal error when executing command: ")
        for exception in exceptions:
            if isinstance(exception, MgmtBaseException):
                result.append(exception.format_http_resp()['message'])
            else:
                result.append(str(exception))
        return '\n'.join(result)

    
def null_renderer(_: DataNodeType) -> str:
    return ""
    