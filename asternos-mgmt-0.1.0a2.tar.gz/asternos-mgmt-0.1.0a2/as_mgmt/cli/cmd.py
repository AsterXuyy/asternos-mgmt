import abc
import copy
import re

from typing import Callable, Mapping, Optional, Union, Any, cast

from parse import parse, search

from as_mgmt.app.registry import PathElem, PathRegistry
from as_mgmt.cli.exc import DataNotFound
from as_mgmt.typing_helper import DataNodeType, SimpleJsonType

from .renderer import null_renderer, TabulateRenderer, DefaultErrorRenderer


_SubCmdType = Optional[list['AbstractCommand']]
_DictFmtType = Union[str, dict[str, str]]
_ConvertFuncType = tuple[Callable[[dict], DataNodeType], Callable[[DataNodeType], dict]]


def cfg(pattern: str, path: str,
        sub_cmds: _SubCmdType = None, 
        converter: Union[None, _DictFmtType, _ConvertFuncType] = None, *, 
        renderer: Callable[[DataNodeType], str] = null_renderer,
        err_renderer: Callable[[list[Exception]], str] = DefaultErrorRenderer(),
        priority: int = 0) -> 'AbstractCommand':
    """
    Factory function to create and register a configurative CLI command.
    :param pattern: A format string used to: a) extract parameters from user input
    or b) format command line when exporting config via CLI. Examples are:
    "port {port_name}", "ip bgp {asn_id}"
    
    :param path: A path in the configuration tree that this command maps to.
    This parameter should contain a relative path to its parent command.
    params extracted from "format" of this command and its parents may be used.
    
    :param converter: Defines how to convert command line into standard requests.
    This might be one of the following types of value:
    1. A dict containing request data, which will be considered a "merge"(or HTTP PATCH)
       request to the given path. Parameters extracted from "pattern" parameter
       (either from current command or its parents) may be used to format this function.
       NOTE: We only support a simple object or a dict without nested structure, as defined by
       _DictFmtType. This is due to implementation complexity constrains.
       Use custom callable renderers for complex cases.
    2. A tuple of callables, the first converts command into request body, and the second
       converts json-like structure back to command line.
    3. None(not specified). In this case, this command do not incur and operation and 
       serves only as a container of other commands(pure klish view).
    
    :param sub_cmds: Optionally a list of subcommands. 
    If not empty, this command corresponds to a klish "view".
    
    :param renderer: Optionally a callable that transforms response into readable string.
    If not specified, (unlike the "show" command below), the response is ignored.
    
    :param err_renderer: Optionally provide a callable to convert errors into readable string.
    If not specified, the "message" field in REST API response body is used.
    
    :param priority: Specify command dependency using priority. When dumping configuration data,
    commands with higher priority will appear first.
    # TODO: Provide a more robust detection method, such as directly setting dependency.
    #       This prevents developers unintentionally breaking dependencies when assigning new priorities.
    """
    cmd = ConfigureCommand(pattern, path, converter, 
                           renderer, err_renderer, priority)
    if sub_cmds:
        for sub_cmd in sub_cmds:
            cmd.add_sub_cmd(sub_cmd)
    PathRegistry.add_command(cmd)
    return cmd


def show(pattern: str, path: str, 
         renderer: Callable[[DataNodeType], str] = TabulateRenderer(),
         err_renderer: Callable[[list[Exception]], str] = DefaultErrorRenderer()) -> 'AbstractCommand':
    """
    Factory function to create and register a data-querying CLI command.
    :param pattern: Same as function "cfg".
    :param path: Same as function "cfg".
    
    :param renderer: Optionally a callable that transforms response into readable string.
    If not specified, the following default behavior is used.
    1. If the result is an empty dict or list, an empty string is generated and command line
       user sees no output.
    2. If the result is a single string, int, float value, apply Python str() method.
    3. If the result is a list of dict, we assume it is a 
    
    We expect the structure of a command response remains unchanged during multiple requests,
    so some of its traits may be cached to avoid excessive trial.
    User may explicitly designate predefined renderers in ./renderers.py to force a specific behavior
    or customize them.
    """
    cmd = ShowCommand(pattern, path, renderer, err_renderer)
    PathRegistry.add_command(cmd)
    return cmd


class AbstractCommand(metaclass=abc.ABCMeta):
    """Interface definition for various kinds of commands"""
    is_cfg_cmd: bool = False
    
    parent: Optional['AbstractCommand']
    children: list['AbstractCommand']
    priority: int

    @property
    @abc.abstractmethod
    def path(self) -> list[PathElem]:
        ...
        
    # Method group 1: parse user command input
    @abc.abstractmethod
    def parse_cmd(self, cmd: str) -> Union[None, dict[str, SimpleJsonType]]:
        """
        Parse command line from user and extract variables from it.
        Implementation MAY convert or not convert the type of the params.
        Both will be handled correctly by the API.
        Return None if the given command does not match.
        """
        
    @abc.abstractmethod
    def convert(self, context: dict[str, SimpleJsonType]) -> tuple[list[PathElem], str, DataNodeType]:
        """
        PGenerate a request from the result of parse_cmds.
        The return value is a tuple of (relative_path, action, body)
        Set action to "skip" to avoid any action.
        """
   
    # Method group 2: dump configuration as commands.
    @abc.abstractmethod
    def parse_path_body(self, path: list[PathElem], body: DataNodeType
                        ) -> dict[str, SimpleJsonType]:
        """
        Parse a pair of path and body of an existing resource 
        and extract command-line parameters from it.
        Return None if the given path does not match,
        Otherwise, return a tuple of (remainder_path, context)
        """
     
    @abc.abstractmethod
    def dump(self, context: Mapping[str, SimpleJsonType]) -> str:
        """
        Format command string from the result of parse_path_body
        """
        
    # Method group 3: result renderer
    @abc.abstractmethod
    def render(self, result: DataNodeType) -> str:
        """
        Render the result value of a command.
        The result MAY have multiple lines and will be presented as-is to the users.
        """
        
    @abc.abstractmethod
    def render_errors(self, exceptions: list[Exception]) -> str:
        """
        Render error message from one or more exceptions returned
        """
        
    @abc.abstractmethod
    def load_path(self, reg: PathRegistry):
        ...
        
    @property
    def abs_path(self) -> list[PathElem]:
        if self.parent:
            return self.parent.abs_path + self.path
        return self.path
    
    # Common internal utilities
    
    def _format_value(self, context: dict[str, SimpleJsonType], value: Any) -> str:
        if not isinstance(value, str):
            raise TypeError(
                f"Command definition error: can not format {type(value).__name__} value {value}, "
                "expected a string."
            )
        return value.format(**context)
     

class ConfigureCommand(AbstractCommand):
    is_cfg_cmd: bool = True

    def __init__(self, pattern: str, raw_path: str,
                 converter: Union[None, _DictFmtType, _ConvertFuncType], 
                 renderer: Callable[[DataNodeType], str],
                 err_renderer: Callable[[list[Exception]], str],
                 priority: int) -> None:
        super().__init__()
        self._main_pattern, self._sub_patterns = parse_pattern(pattern)
        self._raw_path = raw_path
        self._path: Optional[list[PathElem]] = None
        self._converter = converter
        self._renderer = renderer
        self._err_renderer = err_renderer
        self.priority = priority
        
        self.children = []
        self.parent = None
        
    @property
    def path(self) -> list[PathElem]:
        if self._path is None:
            raise ValueError("Command path not parsed with YANG models")
        return self._path
    
    def load_path(self, reg: PathRegistry):
        self._path, _ = reg.parse_gnmi_path(self._raw_path)

    def add_sub_cmd(self, cmd: AbstractCommand) -> None:
        cmd.parent = self
        self.children.append(cmd)
        
    def parse_cmd(self, cmd: str) -> Union[None, dict[str, SimpleJsonType]]:
        result: dict[str, SimpleJsonType] = {}
        if self._sub_patterns:
            main_match = search(self._main_pattern, cmd)
        else:  
            # Make things simpler when no subcommand is involved.
            # In this case, users do not need to specify :S formatter for all parameters.
            main_match = parse(self._main_pattern, cmd)
        if main_match is None:
            return None
        result.update(main_match.named)
        for pattern in self._sub_patterns:
            match = search(pattern, cmd)
            if match is not None:
                result.update(match.named)
        return result
    
    def _format_item(self, context: dict[str, SimpleJsonType], obj: _DictFmtType) -> _DictFmtType:
        if isinstance(obj, dict):
            for key, value in obj.items():
                obj[key] = self._format_value(context, value)
            return obj
        return self._format_value(context, obj)
    
    def convert(self, context: dict[str, SimpleJsonType]) -> tuple[list[PathElem], str, DataNodeType]:
        path = copy.deepcopy(self.path)
        for elem in path:
            elem.kv_pairs = [
                (key, self._format_value(context, value))
                for key, value in elem.kv_pairs
            ]
        if self._converter is None:
            return path, "merge", {}
        if isinstance(self._converter, tuple):  # _ConvertFuncType
            return path, 'merge', self._converter[0](context)
        # else: _DictFmtType
        result = copy.deepcopy(self._converter)
        return path, 'merge', cast(DataNodeType, self._format_item(context, result))
    
    def _parse_value(self, fmt: str, val: Any) -> dict[str, SimpleJsonType]:
        if not isinstance(val, str):
            val = str(val)
        result = parse(fmt, val, evaluate_result=True)
        if not result:
            raise DataNotFound("Parse Failed: pattern not matched")
        return result.named
    
    def _parse_item(self, fmt: _DictFmtType, val: DataNodeType) -> dict[str, SimpleJsonType]:
        result = {}
        if not isinstance(fmt, dict):
            return self._parse_value(fmt, val)
        if not isinstance(val, dict):
            raise ValueError("Parse Failed: fmt is dict but value is not.")
        for key, item_fmt in fmt.items():
            if key not in val:
                raise DataNotFound(f"Parse Failed: {key} not found in config.")
            result.update(self._parse_value(item_fmt, val[key]))
        return result
    
    def parse_path_body(self, path: list[PathElem], body: DataNodeType
                        ) -> dict[str, SimpleJsonType]:
        if len(path) < len(self.path):
            raise ValueError("Given path too short.")
        var: dict[str, SimpleJsonType] = {}
        for actual, conceptual in zip(path, self.path):
            if len(actual.kv_pairs) != len(conceptual.kv_pairs):
                raise DataNotFound(f"Expecting {len(conceptual.kv_pairs)} path attributes, got "
                                    f"{len(actual.kv_pairs)} instead.")
            # As require by the definition of PathElem and gNMI path style,
            # The kv_pairs MUST be ordered by the key. Thus we don't sort it again here.
            for (actual_name, value), (conceptual_name, format_) in zip(actual.kv_pairs, conceptual.kv_pairs):
                if actual_name != conceptual_name:
                    raise ValueError(f"Failed to parse key {conceptual_name}={format_}")
                if match := parse(format_, value, evaluate_result=True):
                    var.update(match.named)
        if isinstance(self._converter, tuple):  # _ConvertFuncType
            var.update(self._converter[1](body))
        elif self._converter is not None:
            var.update(self._parse_item(self._converter, body))
        return var
        
    def dump(self, context: Mapping[str, SimpleJsonType]) -> str:
        result: list[str] = [self._main_pattern.format(**context)]
        for pattern in self._sub_patterns:
            result.append(pattern.format(**context))
        return ' '.join(result)
    
    def render(self, result: DataNodeType) -> str:
        return self._renderer(result)
        
    def render_errors(self, exceptions: list[Exception]) -> str:
        return self._err_renderer(exceptions)
    

class ShowCommand(AbstractCommand):
    
    def __init__(self, pattern: str, raw_path: str, 
                 renderer: Callable[[DataNodeType], str],
                 err_renderer: Callable[[list[Exception]], str]):
        super().__init__()
        self._pattern = pattern
        self._raw_path = raw_path
        self._path: Optional[list[PathElem]] = None
        self._renderer = renderer
        self._err_renderer = err_renderer
        
        self.children = []
        self.parent = None
        
    @property
    def path(self) -> list[PathElem]:
        if self._path is None:
            raise ValueError("Command path not parsed with YANG models")
        return self._path
    
    def load_path(self, reg: PathRegistry):
        self._path, _ = reg.parse_gnmi_path(self._raw_path)

    def add_sub_cmd(self, cmd: AbstractCommand) -> None:
        raise TypeError("Show commands may not have subcommands.")
        
    def parse_cmd(self, cmd: str) -> Union[None, dict[str, SimpleJsonType]]:
        result = parse(self._pattern, cmd, case_sensitive=True, evaluate_result=True)
        if result is None:
            return None
        return result.named
    
    def convert(self, context: dict[str, SimpleJsonType]) -> tuple[list[PathElem], str, DataNodeType]:
        path = copy.deepcopy(self.path)
        for elem in path:
            elem.kv_pairs = [
                (key, self._format_value(context, value))
                for key, value in elem.kv_pairs
            ]
        return path, "get", {}
    
    def parse_path_body(self, path: list[PathElem], body: DataNodeType
                        ) -> dict[str, SimpleJsonType]:
        # "show" commands do not participate in config dump.
        return {}
        
    def dump(self, context: Mapping[str, SimpleJsonType]) -> str:
        return self._pattern.format(**context)
    
    def render(self, result: DataNodeType) -> str:
        return self._renderer(result)
        
    def render_errors(self, exceptions: list[Exception]) -> str:
        return self._err_renderer(exceptions)


def parse_pattern(pattern: str) -> tuple[str, list[str]]:
    """
    Parse command pattern, extract subcommands.
    e.g. "acl-entry {entry_id} src-ip {src_ip} action {action}" 
         -> ('acl-entry {entry-id}', 'src_ip')
    """
    main = pattern.replace('<', '{').replace('>', '}')
    # Supports two formats. Params may be enclosed in "{}"(python format) or "<>"(AsterNOS doc format)
    flag_first = True
    subs: list[str] = []
    for match in re.finditer(r"(\[[A-Za-z0-9-_ {}]+\])", main):
        if flag_first:
            main = main[:match.start()]
            flag_first = False
        subs.append(match.groups()[0][1:-1].strip())  # remove '[' and ']'
    
    return main.strip(), subs
