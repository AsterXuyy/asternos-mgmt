import asyncio
import itertools
import json
import os
import unittest

from asyncio import Queue, Task
from typing import Callable, ClassVar, Optional
from unittest import mock

from tornado.httpserver import HTTPServer
from tornado.httpclient import AsyncHTTPClient, HTTPRequest
from as_mgmt.app.converter.cmd import CommandMatchResult
from as_mgmt.app.registry import ModuleMetadata, PathElem

from as_mgmt.app.proto_server import (
    Request, Response, AbstractProtoClient, ClientID, AbstractProtoServer
)
from as_mgmt.cli.cmd import cfg
from as_mgmt.cli.server import make_cli_app
from as_mgmt.config import set_option
from as_mgmt.http.request import make_app
from as_mgmt.service import init_key

class MockProtocolServer(AbstractProtoServer):
    _req_channel: Queue[Request]
    _clients: dict[ClientID, AbstractProtoClient]
    
    def __init__(self) -> None:
        self._req_channel = Queue()
        self._id_gen = itertools.count()
        self._clients = {}
        self._resp_args: tuple[list[Exception], dict] = ([], {})
        self._task: Optional[Task] = None
        
        self.requests_log: list[Request] = []
        self.capability_value: list[ModuleMetadata] = []
        
    def add_client(self, client: AbstractProtoClient) -> ClientID:
        client_id = ClientID(next(self._id_gen))
        self._clients[client_id] = client
        return client_id

    def add_request(self, request: Request) -> None:
        self._req_channel.put_nowait(request)
        
    async def _request_handler_entrypoint(self) -> None:
        while True:
            req = await self._req_channel.get()
            self.requests_log.append(req)
            self._clients[req.client_id].response_callback(
                Response(req.user_client_id, req.request_id, self._resp_args[0], self._resp_args[1])
            )
        
    def run(self) -> None:
        self._task = asyncio.create_task(self._request_handler_entrypoint())
        
    def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
        self._task = None
        
    def set_response_rest(self, body: dict, errs: list[Exception]):
        self._resp_args = (errs, body)
        
    def capability(self) -> list[ModuleMetadata]:
        return self.capability_value
        
    def parse_rest_path(self, path: str) -> list[PathElem]:
        return []
    
    def get_netconf_protocol_converter(self):
        raise NotImplementedError()
    
    def get_command_protocol_converter(self):
        mock_converter = mock.Mock()
        mock_converter.convert_from_cmds.return_value = CommandMatchResult(
            "running", [], "get", {}, cfg("placeholder", "/")
        )
        return mock_converter
        
class _HttpCommon(unittest.IsolatedAsyncioTestCase):
    
    port: ClassVar[int]
    
    def custom_setup(self, make_app_func: Callable[[AbstractProtoServer], None]) -> None:
        self.proto_server = MockProtocolServer()                     # pylint: disable=attribute-defined-outside-init
        self.server = HTTPServer(make_app_func(self.proto_server))   # pylint: disable=attribute-defined-outside-init
        self.server.listen(self.port, '127.0.0.1', reuse_port=True)
        self.client = AsyncHTTPClient()                              # pylint: disable=attribute-defined-outside-init
        init_key()
        
    async def asyncSetUp(self) -> None:
        await super().asyncSetUp()
        self.server.start()
        self.proto_server.run()
        
    async def asyncTearDown(self) -> None:
        self.client.close()
        self.proto_server.stop()
        self.server.stop()
        await super().asyncTearDown()


class TestHttpServer(_HttpCommon):
    # TODO: Add a test where Content-Type header is missing.
    port = 8088
    
    def setUp(self) -> None:
        set_option('http', 'disable_auth', True)
        return self.custom_setup(make_app)

    async def test_standard_get(self) -> None:
        self.proto_server.set_response_rest({"resp": "content"}, [])
        resp = await self.client.fetch(
            HTTPRequest(
                "http://localhost:8088/rest/v1/running/interfaces/Ethernet1",
                method="GET",
                headers={'Content-Type': "application/json"},
            ),
            raise_error=False
        )
        self.assertEqual(resp.code, 200)
        self.assertEqual(json.loads(resp.body.decode('utf-8')), {"resp": "content"})
        
    async def test_request_invalid_body_json(self) -> None:
        resp = await self.client.fetch(
            HTTPRequest(
                "http://localhost:8088/rest/v1/running/interfaces/Ethernet1",
                method="POST",
                body="{123",
                headers={'Content-Type': "application/json"},
            ),
            raise_error=False
        )
        self.assertEqual(resp.code, 400)
        self.assertEqual(json.loads(resp.body.decode('utf-8')), {
            "errors": [{
                 "error_tag": "http.bad_body",
                 "message": "Failed to decode request body as json: "
                            "Expecting property name enclosed in double quotes: line 1 column 2 (char 1)",
                 "data": {}
            }]
        })
        
    async def test_request_invalid_content_type(self) -> None:
        resp = await self.client.fetch(
            HTTPRequest(
                "http://localhost:8088/rest/v1/running/interfaces/Ethernet1",
                method="POST",
                body="<html></html>",
                headers={'Content-Type': "text/html"}
            ),
            raise_error=False
        )
        self.assertEqual(resp.code, 400)
        self.assertEqual(json.loads(resp.body.decode('utf-8')), {
            "errors": [{
                 "error_tag": "http.bad_content_type",
                 "message": "Unsupported request content type, expected application/json; charset=utf-8",
                 "data": {}
            }]
        })
        
    async def test_standard_post(self) -> None:
        ...
        
    async def test_standard_put(self) -> None:
        ...
        
    async def test_standard_delete(self) -> None:
        ...
        
    async def test_standard_patch_op_path_value_triplets(self) -> None:
        ...
        
    async def test_standard_patch_dict_merge(self) -> None:
        ...
        
    async def test_get_return_multiple_errors(self) -> None:
        ...


class TestCommand(_HttpCommon):
    port = 8089
    
    def setUp(self) -> None:
        return self.custom_setup(make_cli_app)
        
    def _load_cred(self) -> str:
        with open(os.path.expanduser('~/.as-mgmt/cli-secret-key'), 'r', encoding='utf-8') as fd:
            return fd.read().strip()

    async def test_send_command_request_invalid_credentials(self) -> None:
        resp = await self.client.fetch(
            HTTPRequest(
                "http://localhost:8089/v1/command",
                method="POST",
                headers={
                    "Content-Type": "text/plain",
                    "X-Command-Key": "12345"
                },
                body="configure running\nport ethernet 0"
            ),
            raise_error=False
        )
        self.assertEqual(resp.body.decode("utf-8"), "Internal Error: Invalid credential for command server.")
        self.assertEqual(len(self.proto_server.requests_log), 0)
        
    async def test_send_command_request(self) -> None:
        key = self._load_cred()
        self.proto_server.set_response_rest({}, [Exception("Boom!")])
        resp = await self.client.fetch(
            HTTPRequest(
                "http://localhost:8089/v1/command",
                method="POST",
                headers={
                    "Content-Type": "text/plain",
                    "X-Command-Key": key
                },
                body="configure running\n  port ethernet 0"
            ),
            raise_error=False
        )
        self.assertEqual(resp.body.decode("utf-8"), "Internal error when executing command: \nBoom!")
        self.assertEqual(len(self.proto_server.requests_log), 1)
        req = self.proto_server.requests_log[0]
        assert isinstance(req, Request)
        self.assertEqual(req.datastore, "running")
    

class TestHttpServerAuth(_HttpCommon):
    # TODO: Add a test where Content-Type header is missing.
    port = 8088
    
    def setUp(self) -> None:
        super().setUp()
        set_option('http', 'disable_auth', False)
        self.custom_setup(make_app)
        
        self.fake_auth = {
            'admin': 'asteros',
            'zxy': "abcdefg"
        }

        def do_auth(usr, pwd):
            return self.fake_auth.get(usr) == pwd
        
        self.pam_patcher = mock.patch("as_mgmt.netconf.stream.pam.authenticate")
        self.pam_mock = self.pam_patcher.start()
        self.pam_mock.side_effect = do_auth
        
    def tearDown(self) -> None:
        self.pam_patcher.stop()
        super().tearDown()
    
    async def test_not_authenticated_return_401(self) -> None:
        resp = await self.client.fetch(
            HTTPRequest(
                "http://localhost:8088/rest/v1/running/interfaces",
                method="GET",
                headers={'Content-Type': "application/json"},
            ),
            raise_error=False
        )
        self.assertEqual(resp.code, 401)
        self.assertEqual(json.loads(resp.body.decode('utf-8')), {
            "errors": [{
                 "error_tag": "http.not_authenticated",
                 "message": "Login required",
                 "data": {}
            }]
        })
    
    async def test_not_authenticated_root_redirect_login_page(self) -> None:
        resp = await self.client.fetch(
            HTTPRequest(
                "http://localhost:8088/",
                method="GET",
                headers={'Content-Type': "application/json"},
                follow_redirects=False
            ),
            raise_error=False
        )
        self.assertEqual(resp.code, 302)
        self.assertEqual(resp.headers['Location'], "/ui/login")
        
    async def test_login_and_cookie(self) -> None:
        resp = await self.client.fetch(
            HTTPRequest(
                "http://localhost:8088/rest/login",
                method="POST",
                headers={'Content-Type': "application/json"},
                body=json.dumps({'username': "admin", "password": "asteros"})
            ),
            raise_error=False
        )
        self.assertEqual(resp.code, 200)
        self.assertIn('signed_username', resp.headers['Set-Cookie'])
        self.assertIn('username=admin', resp.headers['Set-Cookie'])
        