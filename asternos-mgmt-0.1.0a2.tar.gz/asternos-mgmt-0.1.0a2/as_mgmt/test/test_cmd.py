import unittest

from as_mgmt.cli.cmd import parse_pattern


class TestParsePattern(unittest.TestCase):
    
    def test_parse_simple_command(self):
        result = parse_pattern("speed {spd}")
        self.assertEqual(result[0], "speed {spd}")
        self.assertEqual(result[1], [])
        result = parse_pattern("speed <spd>")
        self.assertEqual(result[0], "speed {spd}")
        
    def test_parse_sub_cmd(self):
        result = parse_pattern("acl-entry <id> [src-ip <src-_ip>] [action <action>]")
        self.assertEqual(result[0], "acl-entry {id}")
        self.assertEqual(result[1], ["src-ip {src-_ip}", "action {action}"])
