import typing
import unittest

from lxml import etree

from as_mgmt.parser import yin
from as_mgmt.parser import elements


class TestParseYINTypes(unittest.TestCase):

    def setUp(self) -> None:
        self.root = elements.RootNode()

    def test_parse_integer_range_enumerated(self):
        data_type = yin.parse_type(etree.fromstring("""
          <type name="uint64">
            <range value="1000|10000|25000|40000|50000|100000|400000">
              <error-message>
                <value>
                  Invalid Ethernet interface speed
                </value>
              </error-message>
              <error-app-tag value="port-speed-invalid"/>
            </range>
          </type>
        """), self.root)
        assert isinstance(data_type, elements.IntegerType)
        self.assertSetEqual(
            data_type.range.value, {
                (1000, 1000), (10000, 10000), (25000, 25000),
                (40000, 40000), (50000, 50000), (100000, 100000),
                (400000, 400000),
            }
        )
        self.assertEqual(data_type.range.error_message, "Invalid Ethernet interface speed")
        self.assertEqual(data_type.range.error_app_tag, "port-speed-invalid")

    def test_parse_integer_range_interval(self):
        data_type = yin.parse_type(etree.fromstring("""
          <type name="uint32">
            <range value="1312..9216">
              <error-message>
                <value>
                  Invalid MTU value
                </value>
              </error-message>
              <error-app-tag value="mtu-invalid"/>
            </range>
          </type>
        """), self.root)
        assert isinstance(data_type, elements.IntegerType)
        self.assertSetEqual(data_type.range.value, {(1312, 9216)})
        self.assertEqual(data_type.range.error_message, "Invalid MTU value")
        self.assertEqual(data_type.range.error_app_tag, "mtu-invalid")

    def test_parse_integer_range_complex(self):
        data_type = yin.parse_type(etree.fromstring("""
          <type name="int32">
            <range value="-100..-20|1|2|3|20..100">
              <error-message>
                <value>
                  Not conforming to this evil type
                </value>
              </error-message>
              <error-app-tag value="evil"/>
            </range>
          </type>
        """), self.root)
        assert isinstance(data_type, elements.IntegerType)
        self.assertSetEqual(data_type.range.value, {
            (-100, -20), (1, 1), (2, 2), (3, 3), (20, 100)
        })
        self.assertEqual(data_type.range.error_message, "Not conforming to this evil type")
        self.assertEqual(data_type.range.error_app_tag, "evil")

    def test_parse_integer_range_with_max(self):
        data_type = yin.parse_type(etree.fromstring("""
          <type name="uint32">
            <range value="1312..max">
              <error-message>
                <value>
                  Invalid MTU value
                </value>
              </error-message>
              <error-app-tag value="mtu-invalid"/>
            </range>
          </type>
        """), self.root)
        assert isinstance(data_type, elements.IntegerType)
        self.assertSetEqual(data_type.range.value, {(1312, 2**64)})
        self.assertEqual(data_type.range.error_message, "Invalid MTU value")
        self.assertEqual(data_type.range.error_app_tag, "mtu-invalid")
        data_type.generate_verifier()(1312)
        with self.assertRaisesRegex(ValueError, r"Value not within range \[1312, \+inf\)"):
            data_type.generate_verifier()(1311)

    def test_parse_enum_type(self):
        data_type = yin.parse_type(etree.fromstring("""
          <type name="enumeration">
            <enum name="untagged"/>
            <enum name="tagged"/>
            <enum name="priority_tagged"/>
          </type>
        """), self.root)
        assert isinstance(data_type, elements.EnumType)
        self.assertListEqual(data_type.options, ["untagged", "tagged", "priority_tagged"])

    def test_parse_string_type(self):
        data_type = yin.parse_type(etree.fromstring(r"""
          <type name="string">
            <length value="1..255"/>
            <pattern value="[a-zA-Z_][a-zA-Z0-9\-_.]*"/>
            <pattern value="[xX][mM][lL].*">
              <modifier value="invert-match"/>
            </pattern>
          </type>
        """), self.root)
        assert isinstance(data_type, elements.StringType)
        self.assertSetEqual(data_type.length.value, {(1, 255)})
        self.assertEqual(data_type.length.error_app_tag, None)
        self.assertEqual(data_type.length.error_message, None)
        self.assertEqual(data_type.patterns[0].value, r"[a-zA-Z_][a-zA-Z0-9\-_.]*")
        self.assertEqual(data_type.patterns[0].invert, False)
        self.assertEqual(data_type.patterns[1].value, r"[xX][mM][lL].*")
        self.assertEqual(data_type.patterns[1].invert, True)
        
    def test_parse_decimal_type(self):
        data_type = yin.parse_type(etree.fromstring(r"""
          <type name="decimal64">
            <fraction-digits value="4"/>
            <range value="1 .. 3.14 | 10 | 20..30.5"/>
          </type>
        """), self.root)
        assert isinstance(data_type, elements.DecimalType)
        self.assertSetEqual(data_type.range.value, {
            (1, 3.14), (10, 10), (20, 30.5)
        })
        
    def test_parse_union_type(self):
        data_type = yin.parse_typedef(etree.fromstring(r"""
            <typedef name="complex_union">
              <type name="union">
                <type name="int32">
                  <range value="1"/>
                </type>
                <type name="union">
                  <type name="int32">
                    <range value="2"/>
                  </type>
                  <type name="string">
                    <length value="3"/>
                  </type>
                </type>
              </type>
            </typedef>
        """), self.root)
        assert isinstance(data_type, elements.UnionType)
        verifier = data_type.generate_verifier()
        verifier(1)
        verifier(2)
        verifier("abc")
        with self.assertRaises((ValueError, TypeError)):
            verifier("abcdef")
        with self.assertRaises((ValueError, TypeError)):
            verifier(100)

    def test_typedef_add_type_to_globals(self):
        obj = yin.parse_typedef(etree.fromstring(r"""
          <typedef name="identifier">
            <type name="string">
              <length value="1..255"/>
              <pattern value="[a-zA-Z_][a-zA-Z0-9\-_.]*"/>
              <pattern value="[xX][mM][lL].*">
                <modifier value="invert-match"/>
              </pattern>
            </type>
          </typedef>
        """), self.root)
        self.assertEqual(obj.name, 'identifier')
        assert isinstance(obj, elements.StringType)


class TestParseYINContainer(unittest.TestCase):

    def setUp(self) -> None:
        self.root = elements.RootNode()

    def test_simple_leaf(self):
        node = yin.parse_leaf(etree.fromstring("""
          <leaf name="basic_leaf">
            <type name="uint32"/>
            <default value="8848"/>
            <config value="true"/>
            <mandatory value="true"/>
            <if-feature name="basic_feature and advance_feature"/>
          </leaf>
        """), self.root)

        assert isinstance(node, elements.LeafNode)
        self.assertIs(node.type, elements.BUILTIN_TYPES['uint32'])
        self.assertEqual(node.default, 8848)
        self.assertEqual(node.config, True)
        self.assertEqual(node.mandatory, True)
        self.assertEqual(node.is_list, False)
        self.assertEqual(node.feature, "basic_feature and advance_feature")

    def test_simple_container(self):
        node = yin.parse_container(etree.fromstring("""
          <container name="basic_container_2">
            <leaf name="param_1">
              <type name="int32">
                <range value="100..200"/>
              </type>
            </leaf>
            <leaf name="param_2">
              <type name="string">
                <pattern value="[a-z]+"/>
              </type>
            </leaf>
          </container>
        """), self.root)
        assert isinstance(node, elements.ContainerNode)
        self.assertEqual(node.name, 'basic_container_2')
        members = dict(node.items())
        self.assertIn('param_1', members)
        assert isinstance(members['param_1'], elements.LeafNode)
        param_1 = typing.cast(elements.LeafNode, members['param_1'])
        assert isinstance(param_1.type, elements.IntegerType)
        param_1_type = typing.cast(elements.IntegerType, param_1.type)
        self.assertEqual(param_1_type.range.value, {(100, 200)})

        self.assertIn('param_2', members)
        assert isinstance(members['param_2'], elements.LeafNode)
        param_1 = typing.cast(elements.LeafNode, members['param_2'])
        assert isinstance(param_1.type, elements.StringType)
        param_1_type_ = typing.cast(elements.StringType, param_1.type)
        self.assertEqual(param_1_type_.patterns[0].value, "[a-z]+")

    def test_nested_container(self):
        node = yin.parse_container(etree.fromstring("""
          <container name="nested_container">
            <leaf name="outer">
              <type name="boolean"/>
            </leaf>
            <container name="the_nested">
              <leaf name="inner">
                <type name="boolean"/>
              </leaf>
            </container>
          </container>
        """), self.root)
        outer_members = dict(node.items())
        self.assertIn('outer', outer_members)
        assert isinstance(outer_members['outer'], elements.LeafNode)
        self.assertEqual(outer_members['outer'].name, "outer")
        self.assertEqual(outer_members['outer'].type.py_type, bool)

        self.assertIn('the_nested', outer_members)
        assert isinstance(outer_members['the_nested'], elements.ContainerNode)
        inner_members = dict(outer_members['the_nested'].items())
        self.assertIn('inner', inner_members)

        assert isinstance(inner_members['inner'], elements.LeafNode)
        self.assertEqual(inner_members['inner'].name, "inner")
        self.assertEqual(inner_members['inner'].type.py_type, bool)

    def test_simple_list(self):
        node = yin.parse_list(etree.fromstring("""
          <list name="items">
            <key value="key1 key2"/>
            <unique tag="value"/>
            <leaf name="key1">
              <type name="string"/>
            </leaf>
            <leaf name="key2">
              <type name="string"/>
            </leaf>
            <leaf name="value">
              <type name="string"/>
            </leaf>
          </list>
        """), self.root)
        assert isinstance(node, elements.ListNode)
        self.assertEqual(node.name, 'items')

        members = dict(node.items())
        self.assertSetEqual({"key1", "key2", "value"}, set(members.keys()))
        for leaf in members.values():
            assert isinstance(leaf, elements.LeafNode)

        self.assertEqual(node.keys, ['key1', 'key2'])
        self.assertEqual(node.unique_fields, ['value'])

    def test_container_with_list(self):
        node = yin.parse_container(etree.fromstring("""
          <container name="simple_list">
            <leaf name="size">
              <type name="uint32"/>
            </leaf>
            <list name="resources">
              <key value="key"/>
              <leaf name="key">
                <type name="string"/>
              </leaf>
              <leaf name="value">
                <type name="string"/>
              </leaf>
            </list>
          </container>
        """), self.root)
        container_members = dict(node.items())
        self.assertEqual(len(container_members), 2)
        self.assertIn('size', container_members)
        self.assertIn('resources', container_members)

        list_node = node.lookup('resources')
        assert isinstance(list_node, elements.ListNode)
        self.assertEqual(list_node.name, 'resources')
        self.assertEqual(list_node.keys, ['key'])
        self.assertEqual(list_node.unique_fields, [])
        list_members = dict(list_node.items())
        self.assertEqual(len(list_members), 2)
        self.assertIn('key', list_members)
        self.assertIn('value', list_members)

    def test_container_with_list_and_list_with_container(self):
        node = yin.parse_container(etree.fromstring("""
          <container name="nested_list">
            <list name="outer">
              <container name="the_nested">
                <list name="inner">
                  <leaf name="item">
                    <type name="string"/>
                  </leaf>
                </list>
              </container>
            </list>
          </container>
        """), self.root)
        inner_container = node.lookup('outer').lookup('the_nested')
        assert isinstance(inner_container, elements.ContainerNode)
        inner_list = node.lookup('outer').lookup('the_nested').lookup('inner')
        self.assertEqual(inner_container.name, "the_nested")
        assert isinstance(inner_list.lookup('item'), elements.LeafNode)

    def test_directly_nested_list(self):
        node = yin.parse_container(etree.fromstring("""
          <container name="direct_nested_list">
            <list name="outer">
              <leaf name="blah">
                <type name="string"/>
              </leaf>
              <list name="inner">
                <leaf name="blah">
                  <type name="string"/>
                </leaf>
              </list>
            </list>
          </container>
        """), self.root)
        assert isinstance(node.lookup('outer').lookup('inner').lookup('blah'), elements.LeafNode)
        
    def test_leafref_type(self):
        stub_module = elements.Module()
        stub_module.prefix = "blah"
        self.root.set_local("stub", stub_module)
        stub_module.set_parent(self.root)
        node = yin.parse_container(etree.fromstring("""
           <container name="leafref_container">
             <leaf name="basic_leaf">
               <type name="uint32"/>
             </leaf>
             <leaf name="simple_ref">
               <type name="leafref">
                 <path value="../../../../../leafref_container////./././././././basic_leaf/../basic_leaf"/>
               </type>
             </leaf>
           </container>
        """), stub_module)
        stub_module.set_local(node.name, node)
        yin.resolve_leafref_and_augment(node)
        ref = node.lookup('simple_ref')
        assert isinstance(ref, elements.LeafNode)
        assert isinstance(ref.type, elements.LeafRefType)
        self.assertIs(
            ref.type.target,
            node.lookup('leafref_container').lookup('basic_leaf')
        )
        
    def test_leafref_type_absolute_path_with_prefix(self):
        stub_module = elements.Module()
        stub_module.prefix = "this-is-prefix"
        self.root.set_local("stub", stub_module)
        stub_module.set_parent(self.root)
        node = yin.parse_container(etree.fromstring("""
           <container name="leafref_container">
             <leaf name="basic_leaf">
               <type name="uint32"/>
             </leaf>
             <leaf name="simple_ref">
               <type name="leafref">
                 <path value="/this-is-prefix:leafref_container/basic_leaf/../this-is-prefix:basic_leaf"/>
               </type>
             </leaf>
           </container>
        """), stub_module)
        stub_module.set_local(node.name, node)
        yin.resolve_leafref_and_augment(node)
        ref = node.lookup('simple_ref')
        assert isinstance(ref, elements.LeafNode)
        assert isinstance(ref.type, elements.LeafRefType)
        self.assertIs(
            ref.type.target,
            node.lookup('leafref_container').lookup('basic_leaf')
        )
        
    def test_leafref_type_bad_reference_path(self):
        node = yin.parse_container(etree.fromstring("""
           <container name="leafref_container">
             <leaf name="basic_leaf">
               <type name="uint32"/>
             </leaf>
             <leaf name="simple_ref">
               <type name="leafref">
                 <path value="../broken"/>
               </type>
             </leaf>
           </container>
        """), self.root)
        with self.assertRaisesRegex(ValueError, ".*broken.*"):
            yin.resolve_leafref_and_augment(node)
        

class TestParseYINModuleAndImport(unittest.TestCase):

    def setUp(self) -> None:
        self.root = elements.RootNode()
        self.module_index = yin.prepare_modules([
            yin.parse_xml("""
<module name="exporting-module"
        xmlns="urn:ietf:params:xml:ns:yang:yin:1"
        xmlns:exporting="asternos">
  <namespace uri="asternos"/>
  <prefix value="exporting"/>
  <organization>
    <text>
      AsterNOS
    </text>
  </organization>
  <typedef name="admin_status">
    <type name="enumeration">
      <enum name="up"/>
      <enum name="down"/>
    </type>
  </typedef>
  <container name="something">
    <leaf name="admin_status">
      <type name="admin_status"/>
    </leaf>
  </container>
</module>
            """),
            yin.parse_xml("""
<module name="first-importing-module"
        xmlns="urn:ietf:params:xml:ns:yang:yin:1"
        xmlns:first-importing="asternos">
  <namespace uri="asternos"/>
  <prefix value="first-importing"/>
  <import module="exporting-module">
    <prefix value="exp"/>
  </import>
  <container name="using">
    <leaf name="imported">
      <type name="exp:admin_status"/>
    </leaf>
  </container>
</module>
            """),
            yin.parse_xml("""
<module name="augmenting-module"
        xmlns="urn:ietf:params:xml:ns:yang:yin:1"
        xmlns:augmenting="asternos">
  <namespace uri="asternos"/>
  <prefix value="augmenting"/>
  <import module="first-importing-module">
    <prefix value="fim"/>
  </import>
  <augment target-node="/fim:using/">
    <leaf name="added">
      <type name="string"/>
    </leaf>
  </augment>
</module>
            """)
        ])

    def test_parse_module_with_typedef_and_container(self):
        module = yin.parse_module('exporting-module', self.root, self.module_index)
        typedef = typing.cast(elements.DataType, module.lookup("admin_status"))
        assert isinstance(typedef, elements.EnumType)
        self.assertEqual(typedef.name, "admin_status")
        self.assertEqual(module.organization, 'AsterNOS')

        container = typing.cast(elements.ConstraintType, module.lookup("something"))
        assert isinstance(container.lookup('admin_status'), elements.LeafNode)
        leaf = typing.cast(elements.LeafNode, container.lookup('admin_status'))
        assert isinstance(leaf.type, elements.EnumType)
        self.assertEqual(leaf.type.name, "admin_status")

    def test_import_module_with_prefix(self):
        module = yin.parse_module('first-importing-module', self.root, self.module_index)

        container = typing.cast(elements.ConstraintType, module.lookup("using"))
        assert isinstance(container.lookup('imported'), elements.LeafNode)
        leaf = typing.cast(elements.LeafNode, container.lookup('imported'))
        assert isinstance(leaf.type, elements.EnumType)
        self.assertEqual(leaf.type.name, "admin_status")

        self.assertTrue(module.has_local('exp:admin_status'))
        self.assertTrue(module.has_local('exp:something'))
        
        self.assertEqual(module.lookup("exp:something").orig_qualified_name, "exporting-module:something")
        self.assertEqual(module.lookup("exp:admin_status").orig_qualified_name, "exporting-module:admin_status")
        
    def test_augmenting_module(self):
        module = yin.parse_module('first-importing-module', self.root, self.module_index)
        yin.parse_module('augmenting-module', self.root, self.module_index)
        yin.resolve_leafref_and_augment(self.root)
        container = typing.cast(elements.ConstraintType, module.lookup("using"))
        self.assertTrue(container.has_local('added'))
