import asyncio
import time
import unittest

from as_mgmt import async_itertools
from as_mgmt.test_fixtures import MockedAsyncIterable


class TestAsyncItertools(unittest.IsolatedAsyncioTestCase):

    async def test_interleave_async_iterators(self):
        first = MockedAsyncIterable([1, 3, 5])
        second = MockedAsyncIterable([2, 4, 6])
        self.assertSetEqual(
            {item async for item in async_itertools.interleave(first, second)},
            {1, 2, 3, 4, 5, 6}
        )

    async def test_group_timeout(self):
        async def first_iterable():
            yield 1
            await asyncio.sleep(0.02)
            yield 1
            yield 1
            await asyncio.sleep(0.02)
            yield 1
            await asyncio.sleep(0.1)
            yield 1

        itr = async_itertools.group(first_iterable(), 0.1)
        self.assertEqual(
            [item async for item in itr], [1, 1]
        )

    async def test_group_interrupted_by_other_value(self):
        async def first_iterable():
            yield 1
            await asyncio.sleep(0.02)
            yield 1
            yield 2
            await asyncio.sleep(0.02)
            yield 1
            await asyncio.sleep(0.1)
            yield 1
            yield 1

        itr = async_itertools.group(first_iterable(), 0.1)
        self.assertEqual(
            [item async for item in itr], [1, 2, 1, 1]
        )

    async def test_group_return_last(self):
        async def first_iterable():
            yield 1
            await asyncio.sleep(0.02)
            yield 1
            yield 2
            await asyncio.sleep(0.02)
            yield 3
            yield 4

        itr = async_itertools.group(first_iterable(), 0.1).__aiter__()
        time1 = time.time()
        self.assertEqual(await itr.__anext__(), 1)
        time2 = time.time()
        self.assertGreater(time2 - time1, 0.015)
        self.assertEqual(await itr.__anext__(), 2)
        time3 = time.time()
        self.assertGreater(time3 - time2, 0.015)
        self.assertEqual(await itr.__anext__(), 3)
        time4 = time.time()
        self.assertLess(time4 - time3, 0.015)
        self.assertEqual(await itr.__anext__(), 4)
        time5 = time.time()
        self.assertLess(time5 - time4, 0.01)
