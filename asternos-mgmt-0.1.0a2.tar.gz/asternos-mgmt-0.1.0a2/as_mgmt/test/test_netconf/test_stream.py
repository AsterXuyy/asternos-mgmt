import asyncio
import os.path
import unittest
from unittest import mock

import asyncssh
from asyncssh import SSHClientSession

from as_mgmt.netconf.stream import start_netconf_server


FILE_PATH = os.path.abspath(os.path.dirname(__file__))

PUB_KEY_PATH = os.path.join(FILE_PATH, '../ssh_keys/ssh_host_ecdsa_key.pub')
KEY_PATH = os.path.join(FILE_PATH, '../ssh_keys/ssh_host_ecdsa_key')


class ReaderTestSSHClientSession(asyncssh.SSHClientSession):

    def __init__(self):
        self.storage = bytearray()

    def data_received(self, data: bytes, datatype: asyncssh.DataType) -> None:
        self.storage.extend(data)


class NetconfStreamTest(unittest.IsolatedAsyncioTestCase):

    def setUp(self) -> None:
        self.fake_auth = {'admin': 'asteros'}

        def do_auth(usr, pwd):
            return self.fake_auth.get(usr) == pwd

        self.pam_patcher = mock.patch("as_mgmt.netconf.stream.pam.authenticate")
        self.pam_mock = self.pam_patcher.start()
        self.pam_mock.side_effect = do_auth

    def tearDown(self) -> None:
        self.pam_patcher.stop()

    @staticmethod
    def _server_factory(handler):
        return start_netconf_server(
            handler, '127.0.0.1', 8830,
            ssh_server_keys=[KEY_PATH],
        )

    async def test_send_legacy_frames_to_server(self):
        received_frames = []

        async def handler(ctx, reader, writer):
            self.assertEqual(ctx.user, 'admin')
            while frame := await reader.read_legacy_frame():
                received_frames.append(frame)
            writer.close()
            await writer.wait_closed()

        server = await self._server_factory(handler)
        async with asyncssh.connect('127.0.0.1', 8830, preferred_auth='password',
                                    username='admin', password='asteros', known_hosts=None) as conn:
            channel, _ = await conn.create_session(SSHClientSession, subsystem='netconf')
            channel.set_encoding(None)
            channel.writelines([
                b'<hello>\n',
                b'<hello/>\n'
                b']]>]]>\n'
            ])
            channel.writelines([
                b'blah blah\n',
                b']]>]]>'
            ])
            channel.writelines([
                b'foo bar]]>]]>\nthis \n is incomplete and \n \t \r shall be \n\n\n discarded.'
            ])
            channel.close()
            await channel.wait_closed()
        await asyncio.sleep(0.01)
        self.assertEqual(len(received_frames), 3)
        self.assertEqual(received_frames[0], b'<hello>\n<hello/>\n')
        self.assertEqual(received_frames[1], b'\nblah blah\n')
        self.assertEqual(received_frames[2], b'foo bar')
        server.close()
        await server.wait_closed()

    async def test_send_standard_frame_to_server(self):
        received_frames = []

        async def handler(ctx, reader, writer):
            self.assertEqual(ctx.user, 'admin')
            while frame := await reader.read_standard_frame():
                received_frames.append(frame)
            writer.close()
            await writer.wait_closed()

        server = await self._server_factory(handler)
        async with asyncssh.connect('127.0.0.1', 8830, preferred_auth='password',
                                    username='admin', password='asteros', known_hosts=None) as conn:
            channel, _ = await conn.create_session(SSHClientSession, subsystem='netconf')
            channel.set_encoding(None)
            channel.writelines([
                b'\n#17\n'
                b'<hello>\n',
                b'<hello/>\n'
                b'\n##\n'
            ])
            channel.writelines([
                b'\n#4\n'
                b'blah ',
                b'\n#5\n'
                b'blah\n',
                b'\n#6\n'
                b']]>]]>'
                b'\n##\n'
            ])
            channel.close()
            await channel.wait_closed()
        await asyncio.sleep(0.01)
        self.assertEqual(len(received_frames), 2)
        self.assertEqual(received_frames[0], b'<hello>\n<hello/>\n')
        self.assertEqual(received_frames[1], b'blah blah\n]]>]]>')
        server.close()
        await server.wait_closed()

    async def test_send_invalid_standard_frame_to_server(self):
        has_msg = False

        async def handler(_, reader, writer):
            nonlocal has_msg
            while frame := await reader.read_standard_frame():
                print(f"Unexpected frame: {frame.decode('utf-8')}")
                has_msg = True
            writer.close()
            await writer.wait_closed()

        server = await self._server_factory(handler)
        async with asyncssh.connect('127.0.0.1', 8830, preferred_auth='password',
                                    username='admin', password='asteros', known_hosts=None) as conn:
            channel, _ = await conn.create_session(SSHClientSession, subsystem='netconf')
            channel.set_encoding(None)
            channel.writelines([
                b'#17\n'
                b'<hello>\n',
                b'<hello/>\n'
                b'\n##\n'
            ])
            channel.writelines([
                b'\n##\n',
                b'##\n',
                b'\n##123abc',
                b'\n#12345\n'
            ])
            channel.writelines([
                b'\n#4\n'
                b'qwertyuio',
            ])
            channel.close()
            await channel.wait_closed()
        await asyncio.sleep(0.01)
        server.close()
        await server.wait_closed()
        if has_msg:
            self.fail("Received invalid message. No message should be received in this test case.")

    async def test_receive_legacy_frame_from_server(self):
        async def handler(_, reader, writer):
            writer.write_legacy_frame(b"<hello>hello world!<hello/>")
            writer.write_legacy_frame(b"<hello><hello/>")
            while await reader.read_standard_frame():
                pass
            writer.close()
            await writer.wait_closed()

        server = await self._server_factory(handler)
        client_session = ReaderTestSSHClientSession()

        async with asyncssh.connect('127.0.0.1', 8830, preferred_auth='password',
                                    username='admin', password='asteros', known_hosts=None) as conn:
            channel, _ = await conn.create_session(lambda: client_session, subsystem='netconf')
            channel.set_encoding(None)
            await asyncio.sleep(0.01)
            channel.close()
            await channel.wait_closed()

        await asyncio.sleep(0.01)
        server.close()
        await server.wait_closed()
        self.assertEqual(client_session.storage, b"<hello>hello world!<hello/>\n]]>]]>\n<hello><hello/>\n]]>]]>\n")

    async def test_receive_standard_frame_from_server(self):
        async def handler(_, reader, writer):
            writer.write_standard_frame(b"<hello>hello world!<hello/>")
            writer.write_standard_frame(b"<hello><hello/>")
            while await reader.read_standard_frame():
                self.fail("No message should be received in this test case.")
            writer.close()
            await writer.wait_closed()

        server = await self._server_factory(handler)
        client_session = ReaderTestSSHClientSession()
        async with asyncssh.connect('127.0.0.1', 8830, preferred_auth='password',
                                    username='admin', password='asteros', known_hosts=None) as conn:
            channel, _ = await conn.create_session(lambda: client_session, subsystem='netconf')
            channel.set_encoding(None)
            channel.write(b"<not a valid frame anyway>")
            await asyncio.sleep(0.01)
            channel.close()
            await channel.wait_closed()

        await asyncio.sleep(0.01)
        server.close()
        await server.wait_closed()
        self.assertEqual(client_session.storage, b"\n#27\n<hello>hello world!<hello/>\n##\n"
                                                 b"\n#15\n<hello><hello/>\n##\n")
