import asyncio
from collections import defaultdict
import contextlib
import functools
import os
import json
import re
import shutil
import sys
import unittest
import logging
from asyncio import subprocess
from concurrent.futures import ThreadPoolExecutor
from typing import ClassVar, Any, NamedTuple, Optional, Union

import redis
import redis.asyncio
from grpc import ssl_channel_credentials
from grpc.aio import Channel, secure_channel
from lxml import etree
from lxml.etree import tostring
from tornado.httpserver import HTTPServer
from tornado.httpclient import AsyncHTTPClient, HTTPResponse, HTTPRequest
from typing_extensions import TypeAlias

from as_mgmt import service
from as_mgmt.config import set_option, cfg
from as_mgmt.app.registry import PathRegistry
from as_mgmt.app.proto_server import ProtoServer
from as_mgmt.cli.server import make_cli_app
from as_mgmt.gnmi.request import make_grpc_server
from as_mgmt.http.request import CA_FALLBACK_LOCATION, create_ssl_context, make_app
from as_mgmt.netconf.protocol import NetconfServer
from as_mgmt.typing_helper import ElementType
from as_mgmt.utils import split_xml_ns

LOG = logging.getLogger(__name__)

MaybeXML: TypeAlias = Union[ElementType, str, bytes]


def _get_test_client_timeout() -> Union[float, None]:
    """
    Use a timeout to prevent tests from hanging if no debugger attached.
    Meanwhile, we don't want timeout when debugging because developers may add breakpoints
    and inspect the execution context, which may be interrupted by a timed-out request.
    """
    return 3 if sys.gettrace() is None else None


class RedisTestBase(unittest.IsolatedAsyncioTestCase):
    """
    This test class sets up connections to a real redis database.
    To run tests, install and run redis database in development environment.
    """

    def setUp(self) -> None:
        self._client_cleanups: list[redis.asyncio.Redis] = []
        self._pool = redis.asyncio.ConnectionPool.from_url("redis://localhost:6379", decode_responses=True)

    def tearDown(self) -> None:
        redis_cli = self.get_sync_redis(0)
        redis_cli.flushall()

    async def asyncTearDown(self) -> None:
        for client in self._client_cleanups:
            await client.close()

    @staticmethod
    def get_sync_redis(db_num: int) -> redis.Redis :
        return redis.Redis(host='localhost', port=6379, db=db_num, decode_responses=True)

    def get_async_redis(self, db_num: int) -> redis.asyncio.Redis:
        client: redis.asyncio.Redis = redis.asyncio.Redis(
            host='localhost', port=6379, db=db_num, decode_responses=True
        )
        self._client_cleanups.append(client)
        self.addAsyncCleanup(client.close)
        return client
    
    def load(self, data: dict[str, dict[str, str]], db_num: int):
        client = self.get_sync_redis(db_num)
        for key, hash_item in data.items():
            client.hset(key, mapping=hash_item)  # type: ignore[arg-type]
            client.zadd("AS_MGMT_KEY_INDEX", {key: 0})
    
    def load_data_and_construct_index(self, db_num: int, key: str, data: dict[str, Any]):
        client = self.get_sync_redis(db_num)
        client.hset(key, mapping={key: str(value) for key, value in data.items()})
        client.zadd("AS_MGMT_KEY_INDEX", {key: 0})


class LoadModulesTestBase(unittest.IsolatedAsyncioTestCase):
    """
    Base test case for those tests that require loading modules
    with the standard method in production.
    """
    
    path_reg: Optional[PathRegistry] = None
    
    @classmethod
    def setUpClass(cls) -> None:
        super().setUpClass()
        cls.path_reg = service.load_resource_namespace()
        
        
class _XmlCompareContext(NamedTuple):
    path: list[str]
    ignore_namespace: bool
    ordered: bool
    
        
class NetconfTestBase(unittest.IsolatedAsyncioTestCase):
    """
    Base test case that provides a NETCONF client implementation.
    """
    
    _nc_manager: ClassVar[Any]
    _thread_pool: ClassVar[ThreadPoolExecutor]
    
    @classmethod
    def setUpClass(cls) -> None:
        super().setUpClass()
        try:
            from ncclient import manager  # type: ignore[import]
            cls._nc_manager = manager
        except ImportError:
            LOG.warning("ncclient not found. NETCONF tests will be skipped")
            cls._nc_manager = None
            
        cls._thread_pool = ThreadPoolExecutor(max_workers=4)
        set_option('netconf', 'port', 8830)
        set_option('netconf', 'disable_auth', True)
        
    @classmethod
    def tearDownClass(cls) -> None:
        cls._thread_pool.shutdown()
        set_option('netconf', 'disable_auth', False)
        # Don't meddle with other test cases.
        super().tearDownClass()
        
    def setUp(self) -> None:
        super().setUp()
        self._manager: Any = None
        
    @contextlib.asynccontextmanager
    async def netconf_session(self, host: str = '127.0.0.1', port: int = 0):
        if self._nc_manager is None:
            self.skipTest("NETCONF client library ncclient not installed.")
        self._manager = await asyncio.get_running_loop().run_in_executor(
            self._thread_pool, functools.partial(
                self._nc_manager.connect, 
                host=host, port=port or cfg.netconf.port,
                hostkey_verify=False,
                username='__unittest__', password="__placeholder__",
                # user authentication is disabled under unit tests.
                manager_params={'timeout': _get_test_client_timeout()},
                # Following options skipped unwanted auth-related process,
                # speeding up tests significantly
                look_for_keys=False, allow_agent=False
            )
        )
        try:
            yield
        finally:
            await asyncio.get_running_loop().run_in_executor(
                self._thread_pool, self._manager.close_session
            )
        
    async def netconf_get_config(self, datastore: str, subtree_filter: MaybeXML) -> ElementType:
        """Send NETCONF get-config request.

        :param datastore: source datastore, e.g. "running", "operational", "startup"
        :param subtree_filter: subtree filter XML as defined by RFC6241
        :return: Request response
        """
        if isinstance(subtree_filter, ElementType):
            subtree_filter = etree.tostring(subtree_filter)
        result = await asyncio.get_running_loop().run_in_executor(
            self._thread_pool, functools.partial(
                self._manager.get_config, source=datastore, filter=subtree_filter
            )
        )
        return etree.fromstring(result.data_xml.encode('utf-8'))
        
    async def netconf_edit_config(self, datastore: str, config: MaybeXML) -> None:
        """Send NETCONF edit-config request.

        :param datastore: target datastore, e.g. "running", "candidate-5", "startup"
        :param config: config XML tree that defines data manipulation actions.
        :return: Request response
        """
        if isinstance(config, ElementType):
            config = etree.tostring(config)
        await asyncio.get_running_loop().run_in_executor(
            self._thread_pool, functools.partial(
                self._manager.edit_config, target=datastore, config=config
            )
        )
        
    @staticmethod
    def _fmt_path(path: list[str]):
        return '/' + '/'.join(path)

    @staticmethod
    def _tag_equal(first: ElementType, second: ElementType, ignore_namespace: bool) -> bool:
        if ignore_namespace:
            if split_xml_ns(first.tag)[1] != split_xml_ns(second.tag)[1]:
                return False
        else:
            if first.tag != second.tag:
                return False
        return True

    @staticmethod
    def _text_equal(first: Optional[str], second: Optional[str]) -> bool:
        if first is None or first.strip(' \n\t') == "":
            first = ""
        if second is None or second.strip(' \n\t') == "":
            second = ""
        return first == second
    
    @staticmethod
    def _subelem_count_equal(x: ElementType, y: ElementType, ignore_namespace: bool) -> bool:
        x_count: dict[str, int] = defaultdict(lambda: 0)
        y_count: dict[str, int] = defaultdict(lambda: 0)
        for x_child in x:
            if not ignore_namespace:
                x_count[x_child.tag] += 1
            else:
                x_count[split_xml_ns(x_child.tag)[1]] += 1
        for y_child in y:
            if not ignore_namespace:
                y_count[y_child.tag] += 1
            else:
                y_count[split_xml_ns(y_child.tag)[1]] += 1
        for k, v in x_count.items():
            if v != y_count[k]:
                return False
        return True
        
    def _subelem_unordered_equal(self, ctx, x: ElementType, y: ElementType):
        # This has O(n^2) complexity, which seems bad, but we didn't come up with better solution for now.
        for sub_x in x:
            matched = False
            for sub_y in y:
                try:
                    self._check_xml_equal(ctx, sub_x, sub_y)
                except AssertionError:
                    pass
                else:
                    matched  = True
                    break
            if not matched:
                self.fail(f"Sub elements at '{self._fmt_path(ctx.path)}' "
                          f"(unordered), can't find equal element {sub_x.tag}")
            
    def _check_xml_equal(self, ctx: _XmlCompareContext, x: ElementType, y: ElementType) -> None:
        if not self._tag_equal(x, y, ctx.ignore_namespace):
            self.fail(f'XML Tag differ at {self._fmt_path(ctx.path)}: "{x.tag}" != "{y.tag}"')
        x_attr = dict(x.items())
        y_attr = dict(x.items())
        ctx.path.append(split_xml_ns(x.tag)[1])
        attr_key_diff = set(x_attr.keys()).symmetric_difference(set(y_attr.keys()))
        if attr_key_diff:
            normalized_key_diff = {str(item) for item in attr_key_diff}
            self.fail(f'XML has different attribute at {self._fmt_path(ctx.path)}: {", ".join(normalized_key_diff)}')
        attr_val_diff: list[tuple[str, str]] = []
        for key in x_attr:
            if x_attr[key] != y_attr[key]:
                attr_val_diff.append((str(x_attr[key]), str(y_attr[key])))
        if attr_val_diff:
            self.fail(f'XML has different attribute at {self._fmt_path(ctx.path)}: '
                      + ",".join(f"{a} != {b}" for a, b in attr_val_diff))
        if not self._text_equal(x.text, y.text):
            self.fail(f'XML text differ at {self._fmt_path(ctx.path)}: "{x.text}" != "{y.text}"')
            
        if not self._subelem_count_equal(x, y, ctx.ignore_namespace):
            x_msg = ', '.join(f'"{str(i.tag)}"' for i in x)
            y_msg = ', '.join(f'"{str(i.tag)}"' for i in y)
            self.fail(f"Count of sub elements at '{self._fmt_path(ctx.path)}' differs:\n {x_msg}\n != \n{y_msg}")
            
        if ctx.ordered or len(x) == len(y) == 1:
            for sub_x, sub_y in zip(x, y):
                self._check_xml_equal(ctx, sub_x, sub_y)
        else:
            self._subelem_unordered_equal(ctx, x, y)
        ctx.path.pop()
        
    def assert_xml_equal(self, first: MaybeXML, second: MaybeXML, 
                         ignore_namespace: bool = True, ordered_elems=False) -> None:
        """Assert two XML documents, either represented as string or lxml Element objects, are equal."""
        if not isinstance(first, ElementType):
            first = etree.fromstring(first)
        if not isinstance(second, ElementType):
            second = etree.fromstring(second)
        try:
            self._check_xml_equal(_XmlCompareContext([], ignore_namespace, ordered_elems), first, second)
        except AssertionError as err:
            text = '\n'.join([
                "XML different. Dumping XML full test: ",
                tostring(first, pretty_print=True).decode('utf-8'),
                '----------------------------------------------------------------------------',
                tostring(second, pretty_print=True).decode('utf-8')
            ])
            raise AssertionError(text + '\n' + str(err)) from err
            
        
class FunctionalTestBase(RedisTestBase, LoadModulesTestBase, NetconfTestBase):
    """
    Base class for functional tests to set up environments.
    """
    
    def setUp(self) -> None:
        super().setUp()
        set_option('http', 'disable_auth', True)
        
        assert self.path_reg is not None
        self.proto_server = ProtoServer(self.path_reg)
        
        self.http_server = HTTPServer(
            make_app(self.proto_server),
            ssl_options=create_ssl_context()
        )
        self.http_server.listen(8088, reuse_port=True)
        self.http_client = AsyncHTTPClient()
        
        self.cli_server = HTTPServer(
            make_cli_app(self.proto_server),
            ssl_options=create_ssl_context()
        )
        self.cli_server.listen(8089, '127.0.0.1', reuse_port=True)
        self.grpc_server = make_grpc_server(self.proto_server)  
        self.netconf_server = NetconfServer(
            self.proto_server,
            [os.path.join(os.path.abspath(os.path.dirname(__file__)), 'ssh_keys/ssh_host_ecdsa_key')],
            [os.path.join(os.path.abspath(os.path.dirname(__file__)), 'ssh_keys/sshd_config')]
        )
        
        self.maxDiff = 2000
        
    async def asyncSetUp(self) -> None:
        await super().asyncSetUp()
        self.http_server.start()
        self.cli_server.start()
        self.proto_server.run()
        await self.grpc_server.start()
        await self.netconf_server.run()
        
    async def asyncTearDown(self) -> None:
        self.http_client.close()
        await self.proto_server.stop()
        self.http_server.stop()
        self.cli_server.stop()
        await self.grpc_server.stop(grace=1)
        await self.grpc_server.wait_for_termination()
        await self.netconf_server.stop()
        await super().asyncTearDown()
        
    def grpc_channel(self) -> Channel:
        """
        Create an asynchronous GRPC client channel to interact with the gNMI server.
        Usage:
        >>> async with self.grpc_channel() as channel:
        >>>     stub = gNMIStub(channel)
        >>>     await stub.Set(...)
        """
        with open(os.path.join(CA_FALLBACK_LOCATION, 'cert.pem'), 'rb') as fd:
            cert = fd.read()
        return secure_channel(
            'localhost:6030', 
            ssl_channel_credentials(cert),
            options=[('grpc.ssl_target_name_override', 'asterfusion.com'),
                     ('grpc.so_reuseport', 1)]
        )
        
    async def rest_request(self, url: str, method: str, body: Any = None) -> HTTPResponse:
        """Send a rest request to test server, return tornado HTTPResponse object"""
        if isinstance(body, (dict, list)):
            body = json.dumps(body)
            content_type = "application/json"
        else:
            content_type = "text/plain"
        resp = await self.http_client.fetch(
            HTTPRequest(
                os.path.join("https://localhost:8088/", url),
                headers={
                    "Content-Type": content_type
                },
                method=method,
                body=body,
                connect_timeout=3,
                request_timeout=_get_test_client_timeout(),
                validate_cert=False
            ),
            raise_error=False,
        )
        return resp
        
    def _remove_ansi_escape(self, text: str) -> str:
        # Copied from: https://stackoverflow.com/questions/14693701
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text)

    async def cli_command(self, cmds: list[str]) -> tuple[str, str]:
        """Send one or more command via klish, return a tuple of (stdout, stderr)"""
        klish_executable = shutil.which("clish")
        if klish_executable is None:
            self.skipTest("Klish is not installed, can not perform command line tests.")
        py_version_parts = sys.version.split('.')
        py_version = f"{py_version_parts[0]}.{py_version_parts[1]}"
        klish_proc = await asyncio.create_subprocess_exec(
            klish_executable, '--lockless', '--utf8', '-x', os.path.expanduser("~/.as-mgmt/klish"),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            env={
                "LD_LIBRARY_PATH": "/usr/local/lib",
                "LD_PRELOAD": f"/usr/lib/x86_64-linux-gnu/libpython{py_version}.so"
            }
            # Use LD_LIBRARY_PATH to add /usr/local/lib, where libraries of klish python plugin
            # resides when klish is installed with "make install" command.
            # This path is not searched by LD dynamic linker by default.
            # Use LD_PRELOAD to force change python version used by klish.
            # Note:
            # 1. Klish must be built with python limited API for stable ABI(which is the default).
            #    https://docs.python.org/3/c-api/stable.html
            # 2. This is ONLY FOR TEST PURPOSE.
            #    It does not work in production due to linux security context,
            #    which makes setuid programs ignore LD_PRELOAD.
            #    https://www.man7.org/linux/man-pages/man8/ld.so.8.html#ENVIRONMENT
        )
        comm_coro = klish_proc.communicate('\n'.join(cmds + [""]).encode('utf-8'))
        if sys.gettrace() is None:
            # Add a timeout to prevent test from hanging if no debugger attached.
            stdout, stderr = await asyncio.wait_for(comm_coro, 5)
        else:
            stdout, stderr = await comm_coro
        # An empty line is required at last or the last command will not be executed.
        return (
            self._remove_ansi_escape(stdout.decode('utf-8')), 
            self._remove_ansi_escape(stderr.decode('utf-8')), 
        )
        