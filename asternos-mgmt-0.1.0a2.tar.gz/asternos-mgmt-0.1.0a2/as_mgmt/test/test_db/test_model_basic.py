from as_mgmt.db.model import BaseModel, Field
from as_mgmt.db.exc import DataValidationFailedError, ModifyReadOnlyFieldException
from as_mgmt.test.base import RedisTestBase


class FirstTestModel(BaseModel):
    unique_key = Field(int, validator=lambda i: i < 100, primary_key=True)
    simple_field = Field(str, validator=lambda i: i.startswith('valid'))


class TestStorageModelBasic1(RedisTestBase):

    def test_create_model_kwargs(self):
        obj = FirstTestModel(unique_key=50, simple_field="valid_123454321")
        self.assertEqual(obj.unique_key, 50)
        self.assertEqual(obj.simple_field, "valid_123454321")

    def test_create_model_args(self) -> None:
        obj = FirstTestModel(50, "valid_123454321")
        self.assertEqual(obj.unique_key, 50)
        self.assertEqual(obj.simple_field, "valid_123454321")
        
    def test_create_model_extra_kwargs(self) -> None:
        self.assertRaisesRegex(
            TypeError, "Got extra keyword argument 'extra' for FirstTestModel",
            FirstTestModel, unique_key=50, simple_field="valid_123454321", extra=123
        )
        
    def test_create_model_extra_args(self) -> None:
        self.assertRaisesRegex(
            TypeError, "Got 2 extra positional parameters for FirstTestModel",
            FirstTestModel, 50, "valid_123454321", 1234567, "aaaaaaa"
        )
        
    def test_model_empty_default(self) -> None:
        obj = FirstTestModel(unique_key=50)
        self.assertIsNone(obj.simple_field)
    
    def test_model_set_attr(self) -> None:
        obj = FirstTestModel(unique_key=50)
        obj.simple_field = "valid_2"
        self.assertEqual(obj.simple_field, "valid_2")
        
    def test_model_set_attr_wrong_type(self) -> None:
        obj = FirstTestModel(unique_key=50)
        self.assertRaisesRegex(
            TypeError, "FirstTestModel.simple_field expects type str, got int instead.",
            setattr, obj, "simple_field", 123
        )
        
    def test_model_set_attr_validation_failure(self) -> None:
        obj = FirstTestModel(unique_key=50)
        self.assertRaisesRegex(
            DataValidationFailedError, "Failed to validate FirstTestModel.simple_field: validator returned False",
            setattr, obj, "simple_field", "not_valid"
        )
        
    def test_create_model_validation_failure(self) -> None:
        self.assertRaisesRegex(
            DataValidationFailedError, "Failed to validate FirstTestModel.simple_field: validator returned False",
            FirstTestModel, unique_key=50, simple_field="error"
        )
        
    def test_change_primary_key_not_allowed(self) -> None:
        obj = FirstTestModel(unique_key=50)
        self.assertRaisesRegex(
            ModifyReadOnlyFieldException, "FirstTestModel.unique_key is read only",
            setattr, obj, "unique_key", 70
        )
        
    def test_set_primary_to_same_value(self) -> None:
        obj = FirstTestModel(unique_key=50)
        obj.unique_key = 50  
        # no error in this case.
        # see comment in model.py: Field.__set__ for more details.


class SecondTestModel(BaseModel):
    first_primary = Field(str)
    second_primary = Field(str)
    default = Field(str, default="default")
    mandatory = Field(str, nullable=False)
    read_only = Field(str, read_only=True, nullable=True)


class TestStorageModelBasic2(RedisTestBase):
    
    def test_create_model_default_field(self) -> None:
        obj = SecondTestModel(first_primary="123", second_primary="456", mandatory="789")
        self.assertEqual(obj.default, "default")
        
    def test_check_model_complete(self) -> None:
        obj = SecondTestModel(first_primary="123", second_primary="456", mandatory="789")
        self.assertTrue(obj.is_complete())
        obj = SecondTestModel(first_primary="123", second_primary="456")
        self.assertFalse(obj.is_complete())
        obj.mandatory = "123"
        self.assertTrue(obj.is_complete())     
        
    def test_multi_inheritance_not_allowed(self) -> None:
        self.assertRaisesRegex(
            TypeError, "Multiple inheritance of Model classes is not allowed as it breaks the dependency resolver.",
            type, "Invalid", (FirstTestModel, SecondTestModel), {}
        )
        
    def test_read_only_field(self) -> None:
        obj = SecondTestModel(first_primary="123", second_primary="456", read_only="789")
        self.assertEqual(obj.read_only, '789')
        self.assertRaisesRegex(
            ModifyReadOnlyFieldException, "SecondTestModel.read_only is read only",
            setattr, obj, "read_only", "987"
        )
        
    def test_read_only_field_delayed_set(self) -> None:
        """Read only fields can be set for once if it does not exist."""
        obj = SecondTestModel(first_primary="123", second_primary="456")
        self.assertIsNone(obj.read_only)
        obj.read_only = "value"
        self.assertEqual(obj.read_only, "value")
        self.assertRaisesRegex(
            ModifyReadOnlyFieldException, "SecondTestModel.read_only is read only",
            setattr, obj, "read_only", "987"
        )

    def test_model_to_dict(self) -> None:
        obj = SecondTestModel(first_primary="123", second_primary="456")
        self.assertDictEqual(
            obj.to_dict(), {'first_primary': "123", "second_primary": "456", "default": "default"}
        )
        self.assertDictEqual(
            obj.to_dict(preserve_none=True), 
            {'first_primary': "123", "second_primary": "456", "default": "default",
             "mandatory": None, "read_only": None}
        )
