from enum import Enum
from typing import Any
from as_mgmt.db.engine import Engine, Datastore, SonicDB
from as_mgmt.db.exc import DuplicatedModelError, SessionError, DeleteReferencedError, InvalidReferenceError
from as_mgmt.db.session import Session
from as_mgmt.db.model import BaseModel, Field, Reference, ModelMeta
from as_mgmt.test.base import RedisTestBase


INITIAL_PORT_DATA: dict[str, dict[str, Any]] = {
    "PORT|Ethernet1": {
        "speed": "10000",
        "mtu": "9216",
        "__refcount__": "1"
    },
    "PORT|Ethernet2": {
        "speed": "25000",
        "mtu": "8888",
        "__refcount__": "1"
    },
    "PORT|Ethernet3": {
        "speed": "100000",
        "mtu": "1500",
        "__refcount__": "0"
    },
    "PORTCHANNEL|PortChannel0001": {
        "mode": "static",
    },
    "PORTCHANNEL_MEMBER|PortChannel0001|Ethernet1": {
        "priority": "65535"
    },
    "PORTCHANNEL_MEMBER|PortChannel0001|Ethernet2": {
        "priority": "12345"
    },
    "VLAN|1": {"NULL": "NULL"},
    "VLAN|2": {"NULL": "NULL"},
    "VLAN|3": {"NULL": "NULL"},
    "VLAN|4": {"NULL": "NULL"},
    "VLAN|5": {"NULL": "NULL"},
}

class Port(BaseModel):
    __table_name__ = "PORT"
    
    name = Field(str, primary_key=True)
    speed = Field(int)
    mtu = Field(int)
    
    
class LAGMode(str, Enum):
    STATIC = "static"
    LACP = "LACP"
    
    
class PortChannel(BaseModel):
    __table_name__ = "PORTCHANNEL"
    
    name = Field(str, primary_key=True)
    mode = Field(LAGMode)


class PortChannelMember(BaseModel):
    __table_name__ = "PORTCHANNEL_MEMBER"
    
    port_channel_name = Field(str, primary_key=True)
    port_name = Field(str, primary_key=True)

    priority = Field(int)
    
    port_ref = Reference(['port_name'], Port)
    port_channel_ref = Reference(
        ['port_channel_name'], PortChannel, on_del_cascade=True
    )
    

class Vlan(BaseModel):
    __table_name__ = "VLAN"
    
    vlan_id = Field(int, primary_key=True, validator=lambda i: 1 <= i <=4094)


class TestStorageModel1(RedisTestBase):
    
    def setUp(self) -> None:
        super().setUp()
        for key, value in INITIAL_PORT_DATA.items():
            self.load_data_and_construct_index(14, key, value)
        self.engine = Engine(SonicDB("CONFIG_DB"), Datastore("running"), self._pool)
        
    async def asyncTearDown(self) -> None:
        await self.engine.shutdown()

    async def test_bulk_read(self):
        """Load a model and all its key-value pairs"""
        async with Session(self.engine) as session:
            objs = await session.query(Port).all()
        self.assertEqual(3, len(objs))
        objs.sort(key=lambda x: x.name)
        self.assertEqual(objs[0].name, "Ethernet1")
        self.assertEqual(objs[0].speed, 10000)
        self.assertEqual(objs[0].mtu, 9216)
        self.assertEqual(objs[1].name, "Ethernet2")
        self.assertEqual(objs[1].speed, 25000)
        self.assertEqual(objs[1].mtu, 8888)
        self.assertEqual(objs[1].__refcount__, 1)
        self.assertEqual(objs[2].name, "Ethernet3")
        self.assertEqual(objs[2].speed, 100000)
        self.assertEqual(objs[2].mtu, 1500)
        
    async def test_bulk_read_with_key_filter(self):
        """Query objects via index and filter them via the only key field"""
        async with Session(self.engine, read_only=True) as session:
            objs = await session.query(Port).filter(Port.name == "Ethernet1").all()
        self.assertEqual(1, len(objs))
        obj = objs[0]
        self.assertEqual(obj.mtu, 9216)
        
    async def test_single_read_exact_one(self):
        async with Session(self.engine, read_only=True) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet1").exactly_one()
        self.assertEqual(obj.mtu, 9216)
        
    async def test_single_read_none(self):
        async with Session(self.engine, read_only=True) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet999").one_or_none()
        self.assertIsNone(obj)
        
    async def test_single_read_multi_result(self):
        async with Session(self.engine) as session:
            query = session.query(Port)
            with self.assertRaisesRegex(ValueError, "Multiple objects found"):
                await query.one_or_none()
                
    async def test_load_and_change_value(self):
        async with Session(self.engine) as session:
            obj = await session.query(Port).filter(
                Port.name == "Ethernet1"
            ).exactly_one()
            obj.speed = 1000
        async with Session(self.engine, read_only=True) as session:
            obj = await session.query(Port).filter(
                Port.name == "Ethernet1"
            ).exactly_one()
            self.assertEqual(obj.speed, 1000)
        self.assertEqual(
            await self.get_async_redis(14).hget("PORT|Ethernet1", 'speed'),
            "1000"
        )

    async def test_load_and_change_value_but_read_only(self):
        """Load a model in read only mode and try to modify it"""
        async with Session(self.engine, read_only=True) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet1").exactly_one()
            obj.speed = 1000  
            # No error currently, but the modification will not be saved.
            # This is the intended behavior. It is useful when implementing "dry-run" utilities.
        async with Session(self.engine, read_only=True) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet1").exactly_one()
            self.assertEqual(obj.speed, 10000)
        self.assertEqual(
            await self.get_async_redis(14).hget("PORT|Ethernet1", 'speed'),
            "10000"
        )
        
    async def test_update_model_set_none(self):
        async with Session(self.engine) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet1").exactly_one()
            obj.speed = None
        self.assertEqual(
            await self.get_async_redis(14).hget("PORT|Ethernet8", 'speed'),
            None
        )
        self.assertEqual(  # should not set placeholder field in this case.
            await self.get_async_redis(14).hget("PORT|Ethernet8", 'NULL'),
            None
        )
        async with Session(self.engine, read_only=True) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet1").exactly_one()
            self.assertIsNotNone(obj)
            self.assertIsNone(obj.speed)
            
    async def test_update_model_and_query_cached(self):
        """When querying objects modified but not committed, the modification should appear in the result"""
        async with Session(self.engine) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet1").exactly_one()
            obj.speed = 10001
            obj = await session.query(Port).filter(Port.name == "Ethernet1").exactly_one()
            self.assertEqual(obj.speed, 10001)
      
    async def test_bulk_read_with_multi_key_filter(self):
        """Query objects and filter them via multiple key fields"""

    async def test_bulk_read_with_non_key_filters(self):
        """Query objects and filter them via non-key fields"""
        
    async def test_bulk_read_with_mixed_filters(self):
        """Query objects and filter them via multiple key fields"""

    async def test_create_object_simple(self):
        """Test creating objects without complex features like reference"""
        async with Session(self.engine) as session:
            await session.add(Port(name="Ethernet8", speed=1000))
        self.assertEqual(
            await self.get_async_redis(14).hget("PORT|Ethernet8", 'speed'),
            "1000"
        )
        async with Session(self.engine, read_only=True) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet1").exactly_one()
            self.assertEqual(obj.speed, 10000)
        
    async def test_create_object_simple_empty_body(self):
        """Test creating objects, but it does not have any data in body(non-key fields)"""
        async with Session(self.engine) as session:
            await session.add(Port(name="Ethernet8"))
        self.assertEqual(
            await self.get_async_redis(14).hgetall("PORT|Ethernet8"),
            {'__refcount__': "0"}
        )
        async with Session(self.engine, read_only=True) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet8").exactly_one()
            self.assertIsNotNone(obj)
            self.assertIsNone(obj.speed)
            self.assertIsNone(obj.mtu)
        
    async def test_create_object_simple_but_read_only(self):
        async with Session(self.engine, read_only=True) as session:
            with self.assertRaisesRegex(SessionError, "Can not create objects in a read only session"):
                await session.add(Port(name="Ethernet8"))
        
    async def test_create_object_add_loaded_obj(self):
        async with Session(self.engine, read_only=True) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet1").exactly_one()
            with self.assertRaisesRegex(SessionError, "Model is not newly created"):
                await session.add(obj)

    async def test_delete_object_simple(self):
        """Test deleting objects without complex features like reference"""
        async with Session(self.engine) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet3").exactly_one()
            await obj.delete()
        self.assertEqual(
            await self.get_async_redis(14).hgetall("PORT|Ethernet3"),
            {}
        )
        
    async def test_create_object_already_exist(self):
        """Try to create a duplicated object, which should be restricted"""
        with self.assertRaisesRegex(
                DuplicatedModelError,
                "Duplicated PortChannel with key fields: name=PortChannel0001"):
            async with Session(self.engine) as session:
                await session.add(PortChannel(name="PortChannel0001"))
                
    async def test_double_create_object(self):
        async with Session(self.engine) as session:
            await session.add(PortChannel(name="PortChannel0002"))
            with self.assertRaisesRegex(
                    DuplicatedModelError,
                    "Duplicated PortChannel with key fields: name=PortChannel0002"):
                await session.add(PortChannel(name="PortChannel0002"))
                
    async def test_double_delete_object(self):
        """Unlike create, we expect no error when double deleting an object"""
        async with Session(self.engine) as session:
            obj = await session.query(Port).filter(Port.name == "Ethernet3").exactly_one()
            await obj.delete()
            await obj.delete()
            
    async def test_query_multi_primary_key_full(self):
        async with Session(self.engine) as session:
            obj = await session.query(PortChannelMember).filter(
                PortChannelMember.port_name == "Ethernet2",
                PortChannelMember.port_channel_name == "PortChannel0001"
            ).exactly_one()
            self.assertEqual(obj.priority, 12345)
            
    async def test_query_multi_primary_key_partial_cant_index(self):
        """Query a subset of the primary keys, and first primary key not included so that index can't be used"""
        async with Session(self.engine) as session:
            obj = await session.query(PortChannelMember).filter(
                PortChannelMember.port_name == "Ethernet1",
            ).exactly_one()
            self.assertEqual(obj.priority, 65535)

    async def test_load_object_with_full_key_allow_empty(self):
        """
        Load an empty object if it does not exist in the db. 
        This is useful when we want to "overwrite" or "merge" an object, e.g. HTTP PUT method.
        """
        
    async def test_extra_predicate_1(self):
        async with Session(self.engine) as session:
            result = await session.query(Vlan).filter(
                Vlan.vlan_id != 1,
                Vlan.vlan_id < 5
            ).all()
        self.assertSetEqual({item.vlan_id for item in result}, {2, 3, 4})
        
    async def test_extra_predicate_2(self):
        async with Session(self.engine) as session:
            result = await session.query(Vlan).filter(
                # It is, however, not possible to write this as 1 < Vlan.vlan_id < 5
                Vlan.vlan_id < 5,
                Vlan.vlan_id > 1
            ).all()
        self.assertSetEqual({item.vlan_id for item in result}, {2, 3, 4})    
        
    async def test_extra_predicate_3(self):
        async with Session(self.engine) as session:
            result = await session.query(Vlan).filter(
                Vlan.vlan_id <= 4,
                Vlan.vlan_id >= 3
            ).all()
        self.assertSetEqual({item.vlan_id for item in result}, {3, 4})    
        
    async def test_extra_predicate_4(self):
        async with Session(self.engine) as session:
            result = await session.query(Vlan).filter(
                Vlan.vlan_id.not_in([1, 3, 5])
            ).all()
        self.assertSetEqual({item.vlan_id for item in result}, {2, 4})    
        
    async def test_extra_predicate_5(self):
        async with Session(self.engine) as session:
            result = await session.query(Vlan).filter(
                Vlan.vlan_id.in_([1, 4, 5])
            ).all()
        self.assertSetEqual({item.vlan_id for item in result}, {1, 4, 5})    
        
    async def test_load_referee_from_referrer(self):
        """Load Ethernet or PortChannel object from referencing PortChannelMember"""
        async with Session(self.engine) as session:
            member = await session.query(PortChannelMember).filter(
                PortChannelMember.port_name == "Ethernet1",
            ).exactly_one()
            port = await session.query(Port).filter(Port.name == "Ethernet1").exactly_one()
            channel = await session.query(PortChannel).filter(PortChannel.name == "PortChannel0001").exactly_one()
            self.assertEqual(
                await session.query(member.port_ref).exactly_one(),
                port
            )
            self.assertEqual(
                await session.query(member.port_channel_ref).exactly_one(),
                channel
            )

    async def test_create_reference(self):
        """Create objects with reference and test incrementing reference count"""
        async with Session(self.engine) as session:
            member = PortChannelMember('PortChannel0001', 'Ethernet3', 1000)
            await session.add(member)
            port = await session.query(Port).filter(
                Port.name == "Ethernet3",
            ).exactly_one()
            self.assertEqual(port.__refcount__, 1)
            channel = await session.query(PortChannel).filter(
                PortChannel.name == "PortChannel0001"
            ).exactly_one()
            self.assertEqual(channel.__refcount__, 0)  
            # on_delete_cascade references do not change refcount
        self.assertEqual(
            await self.get_async_redis(14).hget(
                "PORT|Ethernet3", '__refcount__'
            ),
            "1"
        )
        self.assertEqual(
            await self.get_async_redis(14).hget(
                "PORTCHANNEL|PortChannel0001", '__refcount__'
            ),
            "0"
        )
        
    async def test_create_reference_preloaded(self):
        """Compared with the previous test, here referee models are loaded before creating the referrer."""
        async with Session(self.engine) as session:
            port = await session.query(Port).filter(
                Port.name == "Ethernet3",
            ).exactly_one()
            channel = await session.query(PortChannel).filter(PortChannel.name == "PortChannel0001").exactly_one()
            self.assertEqual(port.__refcount__, 0)
            member = PortChannelMember('PortChannel0001', 'Ethernet3', 1000)
            await session.add(member)
            self.assertEqual(port.__refcount__, 1)
            self.assertEqual(channel.__refcount__, 0)  # on_delete_cascade references do not change refcount
        self.assertEqual(
            await self.get_async_redis(14).hget("PORT|Ethernet3", '__refcount__'),
            "1"
        )
        self.assertEqual(
            await self.get_async_redis(14).hget("PORTCHANNEL|PortChannel0001", '__refcount__'),
            "0"
        )

    async def test_delete_reference(self):
        async with Session(self.engine) as session:
            member = await session.query(PortChannelMember).filter(
                PortChannelMember.port_name == "Ethernet1",
            ).exactly_one()
            await member.delete()
            port = await session.query(Port).filter(
                Port.name == "Ethernet1",
            ).exactly_one()
            self.assertEqual(port.__refcount__, 0)
            channel = await session.query(PortChannel).filter(PortChannel.name == "PortChannel0001").exactly_one()
            self.assertEqual(channel.__refcount__, 0)
        self.assertEqual(
            await self.get_async_redis(14).hget("PORT|Ethernet1", '__refcount__'),  "0"
        )
        self.assertEqual(
            await self.get_async_redis(14).hget("PORTCHANNEL|PortChannel0001", '__refcount__'), "0"
        )
        
    async def test_delete_reference_preloaded(self):
        async with Session(self.engine) as session:
            port = await session.query(Port).filter(
                Port.name == "Ethernet1",
            ).exactly_one()
            channel = await session.query(PortChannel).filter(PortChannel.name == "PortChannel0001").exactly_one()
            member = await session.query(PortChannelMember).filter(
                PortChannelMember.port_name == "Ethernet1",
            ).exactly_one()
            await member.delete()
            self.assertEqual(port.__refcount__, 0)
            self.assertEqual(channel.__refcount__, 0)
        self.assertEqual(
            await self.get_async_redis(14).hget("PORT|Ethernet1", '__refcount__'),  "0"
        )
        self.assertEqual(
            await self.get_async_redis(14).hget("PORTCHANNEL|PortChannel0001", '__refcount__'), "0"
        )

    async def test_delete_referenced_restricted(self):
        """Make sure that an object with non-zero reference count can not be deleted"""
        async with Session(self.engine) as session:
            port = await session.query(Port).filter(
                Port.name == "Ethernet2",
            ).exactly_one()
            with self.assertRaises(DeleteReferencedError):
                await port.delete()

    async def test_delete_referenced_cascade(self):
        """Test deleted referencing objects for 'cascade delete' references"""
        async with Session(self.engine) as session:
            channel = await session.query(PortChannel).filter(PortChannel.name == "PortChannel0001").exactly_one()
            await channel.delete()
            port = await session.query(Port).filter(
                Port.name == "Ethernet1",
            ).exactly_one()
            self.assertEqual(port.__refcount__, 0)
        self.assertFalse(
            await self.get_async_redis(14).exists("PORTCHANNEL_MEMBER|PortChannel0001|Ethernet1")
        )
        self.assertFalse(
            await self.get_async_redis(14).exists("PORTCHANNEL_MEMBER|PortChannel0001|Ethernet2")
        )
        self.assertFalse(
            await self.get_async_redis(14).exists("PORTCHANNEL|PortChannel0001")
        )
        
    async def test_create_object_referencing_not_exist(self):
        """Test create an object whose reference does not exist"""
        msg = "Detected invalid referenced to PortChannel object with storage key PORT|Ethernet666"
        with self.assertRaisesRegex(InvalidReferenceError, msg):
            async with Session(self.engine) as session:
                member = PortChannelMember('PortChannel0001', 'Ethernet666', 1000)
                await session.add(member)

    async def test_create_object_referencing_not_exist_delete_cascade(self):
        """Test create an object whose reference does not exist, with on delete cascade referee."""
        msg = "Detected invalid referenced to PortChannel object with storage key PORTCHANNEL|PortChannel0005"
        with self.assertRaisesRegex(InvalidReferenceError, msg):
            async with Session(self.engine) as session:
                member = PortChannelMember('PortChannel0005', 'Ethernet3', 1000)
                await session.add(member)
    
    # TODO: The following reference tests require non-primary-key referrer fields.
    #       We might use something like ACLs to write this test.   
    async def test_modify_object_to_reference_another_object(self):
        ...
            
    async def test_modify_object_to_reference_not_exist(self):
        ...

    async def test_concurrency_write_while_read(self):
        """
        1. Read some objects,
        2. Write to these objects before the read sequence completes.
        No error should occur in this case.
        Note: pure read operation(read-only session) do not create any locks or similar restrictions.
        """

    async def test_concurrency_write(self):
        """
        1. Read and then write an object
        2. Before it completes, initiate another similar operation simultaneously.
        Due to our optimistic concurrency control, the first operation will fail and abort.
        """

    async def test_concurrency_reference_delete(self):
        """
        1. Delete a referenced object with __ref_count__ = 0
        2. Before it completes, try to create an object referencing this object(ondelete restrict)
        The delete operation will fail because it detects an operation(referencing) on the key to delete.
        """

    async def test_concurrency_reference_delete_cascade_mode(self):
        """Similar with the previous test case, but the reference is 'ondelete cascade' mode"""

    async def test_concurrency_bulk_load_watch(self):
        """Simulating bulk resource modification and its concurrency control"""
        
    def test_check_model_index(self):
        self.assertIn(Port.__table_name__, ModelMeta.models)
        self.assertIs(ModelMeta.models[Port.__table_name__], Port)
        
    def test_check_root_model(self):
        self.assertIn(Port, ModelMeta.root_models)
        self.assertIn(PortChannel, ModelMeta.root_models)
        self.assertNotIn(PortChannelMember, ModelMeta.root_models)
        
    def test_reflect_model_cls(self):
        self.assertIs(
            ModelMeta.reflect_db("PORT|Ethernet0", '|'),
            Port
        )
        self.assertIs(
            ModelMeta.reflect_db("WHATEVER|Ethernet0", '|'),
            None
        )
