
import os
import unittest

from grpc import ssl_channel_credentials
from grpc.aio import secure_channel
from as_mgmt.app.registry import ModuleMetadata

from as_mgmt.gnmi.request import make_grpc_server
from as_mgmt.gnmi.gnmi.gnmi_pb2_grpc import gNMIStub
from as_mgmt.gnmi.gnmi.gnmi_pb2 import CapabilityRequest, CapabilityResponse, ModelData, Encoding
from as_mgmt.http.request import CA_FALLBACK_LOCATION
from as_mgmt.test.test_http.test_rest_server import MockProtocolServer


class TestGNMIServer(unittest.IsolatedAsyncioTestCase):
    
    def setUp(self) -> None:
        self.proto_server = MockProtocolServer()
        self.server = make_grpc_server(self.proto_server)
        with open(os.path.join(CA_FALLBACK_LOCATION, 'cert.pem'), 'rb') as fd:
            self._cert = fd.read()
        
    async def asyncSetUp(self) -> None:
        self.proto_server.run()
        await self.server.start()
        
    async def asyncTearDown(self) -> None:
        self.proto_server.stop()
        await self.server.stop(grace=1)
        await self.server.wait_for_termination()
        
    def channel_factory(self):
        return secure_channel(
            'localhost:6030', 
            ssl_channel_credentials(self._cert),
            options=[('grpc.ssl_target_name_override', 'asterfusion.com'),
                     ('grpc.so_reuseport', 1)]
        )
    
    async def test_get_capabilities(self) -> None:
        self.proto_server.capability_value = [
            ModuleMetadata("port", "Asterfusion", "v1"),
            ModuleMetadata("route", "abc", "v2"),
        ]
        async with self.channel_factory() as channel:
            stub = gNMIStub(channel)
            result: CapabilityResponse = await stub.Capabilities(CapabilityRequest(extension=[]))
            self.assertEqual(result.extension, [])
            self.assertEqual(result.gNMI_version, "0.10.0")
            self.assertEqual(Encoding.Name(result.supported_encodings[0]), 'JSON')
            self.assertEqual(
                result.supported_models, [
                    ModelData(name="port", organization="Asterfusion", version="v1"),
                    ModelData(name="route", organization="abc", version="v2"),
                ]
            )
