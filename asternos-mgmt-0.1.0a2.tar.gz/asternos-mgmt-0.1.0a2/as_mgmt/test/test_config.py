import os
import sys
import unittest
from enum import Enum
from unittest import mock

from as_mgmt import config


class TestConfig(unittest.TestCase):
    
    def setUp(self) -> None:
        super().setUp()
        self._backup = config.reset_config()
        
    def tearDown(self) -> None:
        config.restore_config(self._backup)
        super().tearDown()
        
    def test_register_simple_opt_and_use_cmd_arg(self) -> None:
        config.register_opt([
            config.Opt("section", "name", str, help_="this is an example", cmd_abbr='n')
        ])
        with mock.patch.object(sys, "argv", ["as_mgmt", '-n', "values"]):
            config.setup_config()
        self.assertEqual(config.cfg.section.name, "values")
        # test force override
        config.set_option('section', 'name', "overridden")
        self.assertEqual(config.cfg.section.name, "overridden")
        
    def test_invalid_option_names(self) -> None:
        self.assertRaisesRegex(
            ValueError, "Invalid option name",
            config.Opt, "section", "name-name", str, help_="this is an example", cmd_abbr='n'
        )
        self.assertRaisesRegex(
            ValueError, "Invalid section name",
            config.Opt, "section!section", "name", str, help_="this is an example", cmd_abbr='n'
        )
        self.assertRaisesRegex(
            ValueError, "Can not use reserved names",
            config.Opt, "section", "help", str, help_="this is an example", cmd_abbr='h'
        )
        self.assertRaisesRegex(
            ValueError, "Invalid command line abbreviated option name",
            config.Opt, "section", "name", str, help_="this is an example", cmd_abbr='abc'
        )
        
    def test_get_default_and_invalid_option(self):
        config.register_opt([
            config.Opt("section", "name", str, help_="this is an example", cmd_abbr='n', default="values"),
            config.Opt("section", "other", str, help_="this is another example", cmd_abbr='p')
        ])
        with mock.patch.object(sys, "argv", ["as_mgmt"]):
            config.setup_config()
        with self.assertRaisesRegex(AttributeError, "Unknown config option sec.n"):
            config.cfg.sec.n  # pylint: disable=pointless-statement
        with self.assertRaisesRegex(AttributeError, "Unspecified config option section.other"):
            config.cfg.section.other  # pylint: disable=pointless-statement
        self.assertEqual(config.cfg.section.name, "values")
        
    def test_config_via_env_var(self):
        config.register_opt([
            config.Opt("section", "name", int, help_="this is an example"),
        ])
        with mock.patch.object(sys, "argv", ["as_mgmt"]):
            with mock.patch.object(os, "environ", {"MGMT_SECTION_NAME": "123"}):
                config.setup_config()
        self.assertEqual(config.cfg.section.name, 123)
        
    def test_config_via_cfg_file_and_enum(self):
        with open("/tmp/mgmt-test-cfg.toml", "w", encoding="utf-8") as fd:
            fd.writelines([
                "[section]\n",
                'name = "first"\n'
            ])
        
        class Some(str, Enum):
            FIRST = "first"
            SECOND = "SECOND"
        
        with mock.patch.object(sys, "argv", ["as_mgmt", "--config-file", "/tmp/mgmt-test-cfg.toml"]):
            config.register_opt([
                config.Opt("section", "name", Some, help_="this is an example"),
            ])
            config.setup_config()
        self.assertIsInstance(config.cfg.section.name, Some)
        self.assertEqual(config.cfg.section.name, Some.FIRST)
