import unittest
from .base import RedisTestBase, LoadModulesTestBase


def _setupAsyncioRunner(self):  # pylint: disable=invalid-name
    # Overrides IsolatedAsyncioTestCase._setupAsyncioRunner,
    # Disables event loop debug mode, which makes tests(especially NETCONF) run much faster.
    import asyncio  # pylint: disable=import-outside-toplevel
    assert self._asyncioRunner is None, 'asyncio runner is already initialized'  # pylint: disable=protected-access
    runner = asyncio.Runner(debug=False)
    self._asyncioRunner = runner  # pylint: disable=protected-access


setattr(unittest.IsolatedAsyncioTestCase, '_setupAsyncioRunner', _setupAsyncioRunner)

del unittest
del _setupAsyncioRunner
