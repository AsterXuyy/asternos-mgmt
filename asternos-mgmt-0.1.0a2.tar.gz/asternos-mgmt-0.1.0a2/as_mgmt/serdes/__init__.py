"""
serdes = Serialization and deserialization.
This module mainly serves the following goals:
1. Provide an interface to register mappings from YANG types to Python classes,
   define how they are parsed/serialized in different APIs.
2. Provide an interface to register database storage classes, that can
   be properly serialized and store in redis databases and used in models.
3. Unify the usage of types in API and storage classes, which means this module
   serves as a common dependency of various component.
   This saves applications from converting types manually and repetitively.
"""
from .registry import add_type, serializable, trivially_serializable, SerdesRegistry
