
from typing import Callable, ClassVar, TypeVar, Union, Type

from .abc import SerializableType

def _unit(x):
    return x


class SerdesRegistry:
    _yang_index: dict[str, tuple[Callable, Callable]]
    #          module.name  api_serializer, api_deserializer
    
    _db_index: dict[type, tuple[Callable, Callable]]
    
    _instance: ClassVar[Union['SerdesRegistry', None]] = None
    
    def __init__(self) -> None:
        self._yang_index = {}
        self._db_index = {}

    def get_api_serdes(self, qualified_name: str) -> tuple[Callable, Callable]:
        if qualified_name not in self._yang_index:
            return _unit, _unit
        return self._yang_index[qualified_name]
    
    def get_db_serdes(self, py_type: type) -> tuple[Callable, Callable]:
        if py_type not in self._db_index:
            return str, py_type
        return self._db_index[py_type]
    
    def add(self, py_type, yang_qualified_name, api_ser, api_des, db_ser, db_des):
        self._yang_index[yang_qualified_name] = (api_ser, api_des)
        self._db_index[py_type] = (db_ser, db_des)
        
    @classmethod
    def instance(cls):
        if not cls._instance:
            cls._instance = cls()
        return cls._instance


T = TypeVar("T", bound=SerializableType)
T2 = TypeVar("T2")


def serializable(cls: Type[T]) -> Type[T]:
    """
    Mark a class as serializable and bind it to a YANG data type.
    This may be used as a class decorator:
    >>> @bind_type
    >>> class SomeType:
    ...     ...
    """
    reg = SerdesRegistry.instance()
    reg.add(
        cls, cls.yang_type, cls.serialize_api, cls.deserialize_api,
        cls.serialize_db, cls.deserialize_db
    )
    return cls


def trivially_serializable(yang_qualified_name: str) -> Callable[[Type[T2]], Type[T2]]:
    def cls_decorator(cls: Type[T2]) -> Type[T2]:
        reg = SerdesRegistry.instance()
        reg.add(
            cls, yang_qualified_name, cls.__str__, cls.__call__,
            cls.__str__, cls.__call__,
        )
        return cls
    return cls_decorator


K = TypeVar("K")
R = TypeVar("R")


def add_type(cls: type, yang_qualified_name: str,
             api_serializer: Callable[[R], K], 
             api_deserializer: Callable[[K], R],
             db_serializer: Callable[[R], K], 
             db_deserializer: Callable[[K], R]) -> None:
    """
    Added an existing type to serdes registry
    by providing its associated YANG typename and serialize/deserialize functions.
    """
    reg = SerdesRegistry.instance()
    reg.add(
        cls, yang_qualified_name, api_serializer, api_deserializer,
        db_serializer, db_deserializer
    )
