import abc

from typing import (
    Protocol, Union, runtime_checkable, ClassVar
)
from typing_extensions import TypeAlias, Self

BaseType: TypeAlias = Union[int, float, str]


@runtime_checkable
class TriviallySerializableType(Protocol):
    """
    A trivially serializable type MUST meet the following requirements:
    1. Defines __str__ method, and its return value MUST be a valid serialization of the object.
    2. Has a valid overload of __init__ method, which MUST accepts exactly one str parameter and
       serves as a deserialization method.
    3. Defines yang_type as a class attribute, which may be defined and used separately in YANG models.
    For type-checking overload in python, see https://docs.python.org/3/library/typing.html#typing.overload
    See builtin.MacAddress for a concrete example.
    Users SHOULD NOT inherit this class. This only serves as an explicit declaration
    and may improve code readability.
    """
    
    yang_type: ClassVar[str]
    
    @abc.abstractmethod
    def __init__(self, value: str) -> None:
        ...
        
    @abc.abstractmethod
    def __str__(self) -> str:
        ...
 
        
@runtime_checkable
class SerializableType(Protocol):
    """
    Optionally, user may use standalone methods for serialization and deserialization.
    """
    
    yang_type: ClassVar[str]
    
    @abc.abstractmethod
    def serialize_api(self) -> BaseType:
        ...
        
    @classmethod
    @abc.abstractmethod
    def deserialize_api(cls, val: BaseType) -> Self:
        ...
        
    @abc.abstractmethod
    def serialize_db(self) -> BaseType:
        ...
        
    @classmethod
    @abc.abstractmethod
    def deserialize_db(cls, val: BaseType) -> Self:
        ...
