import logging

from logging.handlers import SysLogHandler

from as_mgmt.config import cfg, register_opt, Opt


register_opt([
    Opt('log', 'level', str, 'Set global logging level', default='INFO'),
    Opt('log', 'disable_stderr', bool, "Don't write logs to stderr", default=False),
    Opt('log', 'syslog', bool, "Write logs to syslog", default=False),
    Opt('log', 'file', str, "Specify a file to write logs", default=""),
])


def setup_logging():
    """Set default loggers and output format"""
    handlers: list[logging.Handler] = []
    if not cfg.log.disable_stderr:
        handlers.append(logging.StreamHandler())
    if cfg.log.syslog:
        handlers.append(SysLogHandler())
    if cfg.log.file:
        handlers.append(logging.FileHandler(cfg.log.file))
    logging.basicConfig(
        format="%(asctime)s - [%(levelname)8s] %(message)s (%(filename)s:%(lineno)s)",
        handlers=handlers,
        level=cfg.log.level.upper(),
    )
