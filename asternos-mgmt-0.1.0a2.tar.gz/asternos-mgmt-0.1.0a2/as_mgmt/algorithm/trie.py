from __future__ import annotations
import abc

from typing import (
    Generic, Sequence, TypeVar, MutableMapping, Optional, Iterable, Callable
)

K = TypeVar('K')
V = TypeVar("V")


class Node(Generic[K, V]):
    parent: Optional[Node[K, V]]
    children: MutableMapping[K, Node[K, V]]
    key: K  # Element in the prefix tree.
    value: V  # Associated data on this node.

    __slots__ = ('parent', 'children', 'key', 'value')
    
    def __init__(self, key: K, value: V, parent: Optional[Node] = None):
        self.key = key
        self.parent = parent
        self.children = {}
        self.value = value

    def __repr__(self):
        return f"<Node key={self.key}>"


class PrefixTree(Generic[K, V]):
    """
    An implementation of prefix trees, also known as trie trees.
    This data structure is wildly used in our framework, including:
    1. An index used to find and reject overlapping ip networks.
    2. An index of elements in YANG data models, which contains 
    3. An index of request handlers and their registered path.
    Then generic param K, V represents KeyType and ValueType.
    KeyType is the element type of the sequence to be indexed, and
    ValueType is the user data associated with the sequence. Examples:
    
    >>> ip_index: PrefixTree[byte, bool]
    >>> path_index: PrefixTree[str, ValidatorType]
    
    """
    root: Node[K, V]
    
    def __init__(self, root_key: K, value_default_factory: Callable[[], V]) -> None:
        self._factory = value_default_factory
        self.root = Node(root_key, value_default_factory())

    def add(self, item: Sequence[K], value: V) -> None:
        curr = self.root
        for elem in item:
            if elem not in curr.children:
                curr.children[elem] = Node(elem, self._factory(), curr)
            curr = curr.children[elem]
        curr.value = value
        
    def remove(self, item: Sequence[K]) -> None:
        node = self.get_node(item)
        while node.parent:
            if node.value is not None:
                return
            if not node.children:
                node.parent.children.pop(node.key)
            node = node.parent
            
    def get_node(self, item: Sequence[K]) -> Node[K, V]:
        curr = self.root
        for elem in item:
            if elem not in curr.children:
                raise KeyError(f"Path {item} not found in tree")
            curr = curr.children[elem]
        return curr
        
    def get(self, item: Sequence[K]) -> V:
        node = self.get_node(item)
        if node.value is None:  # this is a intermediate node without associated data
            raise KeyError(f"Path {item} not found in tree")
        return node.value
        
    def find_subnodes(self, prefix: Sequence[K]) -> PostOrderTreeIterator[K, V]:
        return PostOrderTreeIterator(self.root, prefix)
        
    def __contains__(self, item: Sequence[K]) -> bool:
        """
        Check wether there is an EXACT MATCH of the given sequence or path.
        """
        curr = self.root
        for elem in item:
            if elem not in curr.children:
                return False
            curr = curr.children[elem]
        return True
        
    def __iter__(self):
        return PostOrderTreeIterator(self.root)
        

class TreeIterator(Generic[K, V]):
    def __init__(self, root: Node[K, V]):
        self._curr = root
        
    @abc.abstractmethod
    def __next__(self):
        ...
        
    def __iter__(self):
        return self
        
    def seek(self, path: Sequence[K]) -> None:
        for item in path:
            if item not in self._curr.children:
                raise ValueError(f"Invalid path: {path}")
            self._curr = self._curr.children[item]
                
        
class PostOrderTreeIterator(TreeIterator[K, V]):
    """
    Post-order, depth first iteration over data node and its path RELATIVE to the start node.
    """
    
    _stack: list[tuple[Node[K, V], bool]]

    def __init__(self, root: Node[K, V], start: Sequence[K] = ()):
        super().__init__(root)
        self._stack = []
        self.seek(start)
        self._stack.append((self._curr, False))
        
    def __next__(self) -> tuple[V, Iterable[K]]:
        while self._stack:
            item, visited = self._stack[-1]
            if visited and item.value is not None:
                result = (item.value, (p_item[0].key for p_item in self._stack))
                self._stack.pop()
                return result
            self._stack[-1] = (self._stack[-1][0], True)  # mark as visited
            for node in self._stack[-1][0].children.values():
                self._stack.append((node, False))  # push all child nodes
        raise StopIteration()
