import asyncio
import functools
import logging
import re

from typing import Optional, TypeVar, Callable, Coroutine
from typing_extensions import ParamSpec

from .typing_helper import ElementType

LOG = logging.getLogger(__name__)


def remove_prefix(string: str, prefix: str) -> str:
    if string[0:len(prefix)] == prefix:
        return string[len(prefix):]
    return string


def check_int(string: str) -> bool:
    if not string:
        return False
    if string[0] in ('-', '+'):
        return string[1:].isdigit()
    return string.isdigit()

P = ParamSpec('P')
T = TypeVar("T", bound=Coroutine)


def shield_from_cancel(func: Callable[P, T]) -> Callable[P, T]:
    @functools.wraps(func)
    def shielded(*args, **kwargs):
        return asyncio.shield(func(*args, **kwargs))
    return shielded


def regex_validate(pattern: str) -> Callable[[str], bool]:
    compiled_regex = re.compile(pattern)
    def validator(text: str) -> bool:
        return compiled_regex.match(text) is not None
    
    return validator


def split_xml_ns(tag: str) -> tuple[str, str]:
    match = re.match(r"(?:{(\S+)}(\S+))", tag)
    if match is None:
        return "", tag
    namespace, stripped_tag = match.groups()
    return namespace, stripped_tag


def get_xml_only_child(elem: ElementType) -> Optional[ElementType]:
    for child in elem:
        return child
    return None
