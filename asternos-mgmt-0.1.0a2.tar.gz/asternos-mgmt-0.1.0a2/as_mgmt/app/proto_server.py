"""
This module defines the protocol between protocol implementation(e.g. NETCONF, cli, REST API),
which is called "clients", and unified request handlers, which is called severs.
Clients do not directly call server methods. Instead, the use a queue structure(called channel)
to communicate with server coroutines. 
"""

import abc
import asyncio
import contextlib
import itertools
import logging
import traceback
from dataclasses import dataclass
from enum import Enum
from typing import Awaitable, NewType, Optional, Sequence, Union
from asyncio import CancelledError, Queue, QueueFull

from redis import asyncio as redis

from as_mgmt import db, utils
from as_mgmt.app.base import SessionContext, ControllerLoader
from as_mgmt.db.session import Session
from as_mgmt.exc import MgmtBaseException
from as_mgmt.typing_helper import DataNodeType

from .registry import ModuleMetadata, PathElem, PathParseError, PathRegistry
from .converter import NetconfConverter, CommandConverter
from .exc import (
    DataVerificationError, RequestBacklogFull, InvalidPathError,
    MethodNotAllowed, ServerShutDown, UnknownInternalError, BatchGetNotSupportedException
)

LOG = logging.getLogger(__name__)

MAX_REQUEST_BACKLOG_SIZE = 128
REQUEST_HANDLER_COROUTINE_COUNT = 8

ClientID = NewType("ClientID", int)
UserClientID = NewType("UserClientID", str)
RequestID = NewType("RequestID", str)


class Action(str, Enum):
    GET = "get"
    CREATE = "create"
    REPLACE = "replace"
    MERGE = "merge"
    DELETE = "delete"
    DUMP_CONFIG = "dump"
    
    SUBSCRIBE = "subscribe"
    UNSUBSCRIBE = "unsubscribe"


@dataclass
class RequestContext:
    user: Optional[str] = None  # The user identity of the connected client
    remote_host: Optional[str] = None  # Host/address identity of the connected client
    remote_port: Optional[int] = None  # remote tcp port for underlying ssh connection
    local_host: Optional[str] = None
    local_port: Optional[int] = None   # Local ip/port of the connection


@dataclass
class Request:
    """Standard request class using json-like structural data"""
    client_id: ClientID
    # ID used to identify the protocol client
    user_client_id: UserClientID
    # Allocated by protocol client, this is used to distinguish remote user clients, 
    # so that we know to which client we should send the response.
    request_id: RequestID
    # Unique request id for each request.
    request_context: RequestContext
    # Optional user context info used for logging, authorization and other auxiliary utilities.
    datastore: str
    path: list[PathElem]
    action: Action
    body: DataNodeType
    # Request body, converted to json representation.

    
@dataclass
class Response:
    """Standard response class using json-like structural data"""
    user_client_id: UserClientID
    request_id: RequestID
    # wrapped exception, ideally a formal, serializable error as defined by as_mgmt.exc
    exceptions: list[Exception] 
    body: dict
    
    
@dataclass
class Notification:  # or telemetry
    user_client_id: UserClientID
    path: str  
    # where this notification message originates.
    # this path is always "gnmi" style path
    body: Union[dict, list]
    

class AbstractProtoClient(metaclass=abc.ABCMeta):
    
    @abc.abstractmethod
    def response_callback(self, response: Response):
        """
        Called by the server to send a response to a user client
        This method IS NOT ASYNC and MUST NOT BLOCK.
        A typical implementation is to put the response in a size limited queue,
        and another coroutine acts as the consumer of this queue to actually write data to user.
        """
        
    @abc.abstractmethod
    def notification_callback(self, notification: Notification):
        """
        Called by the server to send a notification, telemetry or an alarm message to a user client.
        Similarly, this method IS NOT ASYNC and MUST NOT BLOCK.
        """
        

class AbstractProtoServer(metaclass=abc.ABCMeta):
    
    @abc.abstractmethod
    def add_client(self, client: AbstractProtoClient) -> ClientID:
        """Register a protocol client to the server"""
        
    @abc.abstractmethod
    def add_request(self, request: Request) -> None:
        """Add a new request to(possibly) the server's request queue"""
        
    @abc.abstractmethod
    def run(self) -> None:
        """Start server processing coroutines."""
        
    @abc.abstractmethod
    def capability(self) -> list[ModuleMetadata]:
        """Return the capability of this server."""
        
    @abc.abstractmethod
    def get_netconf_protocol_converter(self) -> NetconfConverter:
        """
        Return a converter that can convert request/response between NETCONF and JSON-like python dict/list.
        """
        
    @abc.abstractmethod
    def get_command_protocol_converter(self) -> CommandConverter:
        """
        Return a converter that can convert request/response between NETCONF and JSON-like python dict/list.
        """
        
    @abc.abstractmethod
    def parse_rest_path(self, path: str) -> list[PathElem]:
        """
        Parse REST styled path and convert it to PathElem objects.
        """


class ProtoServer(AbstractProtoServer):
    
    _req_channel: Queue[Request]
    _clients: dict[ClientID, AbstractProtoClient]
    _tasks: list[asyncio.Task]
    
    def __init__(self, path_registry: PathRegistry) -> None:
        self._req_channel = Queue(maxsize=MAX_REQUEST_BACKLOG_SIZE)
        self._id_gen = itertools.count()
        self._clients = {}
        self._registry = path_registry
        self._tasks = []
        # TODO: Make this configurable.
        self._db_pool = redis.ConnectionPool.from_url("redis://localhost:6379", decode_responses=True)
        
    def add_client(self, client: AbstractProtoClient) -> ClientID:
        client_id = ClientID(next(self._id_gen))
        self._clients[client_id] = client
        return client_id

    def add_request(self, request: Request) -> None:
        try:
            self._req_channel.put_nowait(request)
        except QueueFull as err:
            raise RequestBacklogFull(MAX_REQUEST_BACKLOG_SIZE) from err
        
    @contextlib.asynccontextmanager
    async def _with_session_context(self, datastore: str):
        _store = db.Datastore(datastore)
        ctx = SessionContext(
            cfg_db=Session(db.Engine(db.SonicDB.CONFIG_DB, _store, self._db_pool)),
            app_db=Session(db.Engine(db.SonicDB.APP_DB, _store, self._db_pool), read_only=True),
            cnt_db=Session(db.Engine(db.SonicDB.COUNTER_DB, _store, self._db_pool), read_only=True),
            state_db=Session(db.Engine(db.SonicDB.STATE_DB, _store, self._db_pool), read_only=True),
            flex_cnt_db=Session(db.Engine(db.SonicDB.FLEX_COUNTER_DB, _store, self._db_pool), read_only=True),
        )
        async with contextlib.AsyncExitStack() as stack:
            await stack.enter_async_context(ctx.cfg_db)
            await stack.enter_async_context(ctx.app_db)
            await stack.enter_async_context(ctx.cnt_db)
            await stack.enter_async_context(ctx.flex_cnt_db)
            await stack.enter_async_context(ctx.state_db)
            yield ctx
            
    @staticmethod
    def _log_err(err: Exception) -> None:
        if not isinstance(err, MgmtBaseException):
            LOG.error("Unexpected error when calling controllers:")
            LOG.error(traceback.format_exc())
        elif LOG.level == logging.DEBUG:
            LOG.debug("Debug traceback of error:")
            LOG.debug(traceback.format_exc())
            
    async def _call_all_controller_dump_command(self, datastore) -> tuple[DataNodeType, list[Exception]]:
        result: dict[str, DataNodeType] = {}
        exc: list[Exception] = []
        async with self._with_session_context(datastore) as session_context:
            for name, controller in self._registry.iter_toplevel_resource_controllers():
                if not hasattr(controller, "get"):
                    exc.append(BatchGetNotSupportedException(type(controller).__name__))
                instance: object = ControllerLoader(session_context).load_controller(controller)
                try:
                    data = getattr(instance, "get")()
                    if isinstance(data, Awaitable):
                        data = await data
                except TypeError as err:
                    err_msg = str(err)
                    if 'missing' in err_msg and 'argument' in err_msg:
                        exc.append(BatchGetNotSupportedException(type(controller).__name__))
                    else:
                        self._log_err(err)
                except Exception as err:  # pylint: disable=broad-exception-caught
                    exc.append(err)
                    self._log_err(err)
                else:
                    if data is None:
                        continue
                    result[name] = data
        exc.extend(self._registry.serdes_body([], result, is_serialize=True))
        return result, exc   
            
    async def _call_controller(self, datastore: str,
                               path: list[PathElem], action: Action, body: DataNodeType
                               ) -> tuple[DataNodeType, list[Exception]]:
        try:
            controller, kwargs = self._registry.find_controller_and_kwargs(path)
        except (ValueError, PathParseError):
            return {}, [InvalidPathError('/'.join(str(item) for item in path))]
        except DataVerificationError as err:
            return {}, [err]  
        exceptions: Sequence[Exception] = self._registry.serdes_body(path, body, is_serialize=False)
        if exceptions:
            return {}, list(exceptions)
        action_ = action.value        
        if not hasattr(controller, action_):
            return {}, [MethodNotAllowed(action_)]
        try:
            async with self._with_session_context(datastore) as session_context:
                instance: object = ControllerLoader(session_context).load_controller(controller)
                if action_ in ['get', 'delete']:
                    result = await getattr(instance, action_)(**kwargs)
                else:
                    if isinstance(body, list):
                        # Split batched request to multiple calls.
                        result = [
                            await getattr(instance, action_)(body=body_item, **kwargs)
                            for body_item in body
                        ]
                    else:
                        result = await getattr(instance, action_)(body=body, **kwargs)
        except Exception as err:  # pylint: disable=broad-exception-caught
            exceptions = [err]
            self._log_err(err)
            return {}, exceptions
        if result is None:
            result = {}
        exceptions = list(exceptions) + list(self._registry.serdes_body(path, result, is_serialize=True))
        if isinstance(result, list):
            # Always wrap the result when querying collections.
            # This provides us the opportunity of adding extra information here, such as pagination.
            result = {"result": result}
            # An alternative is to use the resource name instead of "result" as the wrapper key.
            # We found this method unnecessarily complicated compared with the previous one.
            # result = {path[-1].name: result}
        if exceptions:
            return {}, list(exceptions)
        return result, []
        
    @utils.shield_from_cancel
    async def _handle_request(self, req: Request) -> Response:
        path_elems = req.path
        is_item_request = path_elems and path_elems[-1].item_request
        if not path_elems and req.action == Action.GET:  # dump configuration
            resp_body, exc = await self._call_all_controller_dump_command(req.datastore)
        else:
            resp_body, exc = await self._call_controller(req.datastore, path_elems, req.action, req.body)
        assert isinstance(resp_body, dict)
        if is_item_request and resp_body:
            # Process "single resource" request.
            # If all resource keys are specified, return that single resource dict directly
            # and remove any wrappers around it.
            resource_list = list(resp_body.values())[0]
            if isinstance(resource_list, list):
                if len(resource_list) == 1 and isinstance(resource_list[0], dict):
                    resp_body = resource_list[0]
        resp = Response(
            req.user_client_id, req.request_id,
            exc, resp_body
        )
        return resp
        
    async def _request_handler_entrypoint(self) -> None:
        while True:
            req = await self._req_channel.get()
            # Shield actual request processing from cancellation
            # so that database access and other transactional operations do not break.
            resp: Response
            try:
                resp = await self._handle_request(req)
            except CancelledError:
                resp = Response(
                    req.user_client_id, req.request_id,
                    [ServerShutDown()], {}, 
                )
            except BaseException:  # pylint: disable=broad-exception-caught
                LOG.error("Unexpected error during request handling:")
                LOG.error(traceback.format_exc())
                resp = Response(
                    req.user_client_id, req.request_id,
                    [UnknownInternalError()], {}, 
                )
            try:
                self._clients[req.client_id].response_callback(resp)
            except Exception:  # pylint: disable=broad-exception-caught
                LOG.error("Unexpected error when sending response to client:")
                LOG.error(traceback.format_exc())
        
    def run(self) -> None:
        if self._tasks:
            raise RuntimeError("Server already started.")
        for _ in range(REQUEST_HANDLER_COROUTINE_COUNT):
            self._tasks.append(
                asyncio.create_task(self._request_handler_entrypoint())
            )
            
    async def stop(self) -> None:
        for task in self._tasks:
            task.cancel()
        await asyncio.wait(self._tasks)
        self._tasks = []
        await self._db_pool.disconnect()
        
    def capability(self) -> list[ModuleMetadata]:
        return list(self._registry.modules)
        
    def parse_rest_path(self, path: str) -> list[PathElem]:
        return self._registry.parse_rest_path(path)[0] 
    
    def get_netconf_protocol_converter(self) -> NetconfConverter:
        return NetconfConverter(self._registry.tree)
    
    def get_command_protocol_converter(self) -> CommandConverter:
        return CommandConverter(self._registry.tree, self._registry.toplevel_commands)
