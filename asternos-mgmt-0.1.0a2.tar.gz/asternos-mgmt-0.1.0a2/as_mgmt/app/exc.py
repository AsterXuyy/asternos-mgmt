from as_mgmt import exc


class RequestBacklogFull(exc.MgmtBaseException):
    
    msg_format = "Server request backlog full, maxsize={maxsize}"
    
    def __init__(self, maxsize):
        self.data = {'maxsize': maxsize}
        super().__init__(maxsize=maxsize)


class InvalidPathError(exc.MgmtBaseException):
    
    msg_format = "Path {path} not found"
    http_status_code = 404
    grpc_error_code = exc.GrpcRespCode.NOT_FOUND
    netconf_error_tag = exc.NetconfErrorTag.UNKNOWN_ELEMENT
    
    error_tag = 'request.invalid_path'
    
    def __init__(self, path: str):
        super().__init__(path=path)
        self.data = {"path": path}


class MethodNotAllowed(exc.MgmtBaseException):
    
    msg_format = "Unsupported action {action}"
    http_status_code = 405
    grpc_error_code = exc.GrpcRespCode.UNIMPLEMENTED
    netconf_error_tag = exc.NetconfErrorTag.OPERATION_NOT_SUPPORTED
    
    error_tag = 'request.invalid_method'
    
    def __init__(self, action: str):
        super().__init__(action=action)
        self.data = {"action": action}


class DataVerificationError(exc.MgmtBaseException):
    
    msg_format = "{error_type} at {field}: {detail}"
    http_status_code = 400
    grpc_error_code = exc.GrpcRespCode.INVALID_ARGUMENT
    netconf_error_tag = exc.NetconfErrorTag.BAD_ELEMENT
    
    error_tag = 'request.validation_error.bad_value'
    
    def __init__(self, error_type: str, field: str, detail: str):
        self.data = {
            'error_type': error_type,
            'field': field,
            'detail': detail
        }
        super().__init__(**self.data)
        

class ExtraFieldError(exc.MgmtBaseException):
    msg_format = "Got following extra fields in request: {fields}"
    http_status_code = 400
    grpc_error_code = exc.GrpcRespCode.INVALID_ARGUMENT
    netconf_error_tag = exc.NetconfErrorTag.BAD_ELEMENT
    
    error_tag = 'request.validation_error.extra_field'
    
    def __init__(self, fields: list[str]):
        super().__init__(fields=fields)  
        
        
class InvalidCommandError(exc.MgmtBaseException):
    msg_format = "Invalid commands: {cmds}"
    error_tag = 'request.invalid_command'
    
    def __init__(self, commands: list[str]):
        self.data = {
            'cmds': commands
        }
        super().__init__(cmds=', '.join(commands))
    

class ServerShutDown(exc.MgmtBaseException):
    msg_format = "request aborted due to server shutdown"


class UnknownInternalError(exc.MgmtBaseException):
    msg_format = "Unknown internal error"


class BatchGetNotSupportedException(exc.MgmtBaseException):
    msg_format = ("Resource controller {controller_typename} does not support batch get operation. "
                  "This is not correct because config dump will not work without it. "
                  "Make sure that toplevel controllers have a 'get' method that accepts 0 arguments")
    
    def __init__(self, controller_typename):
        super().__init__(controller_typename=controller_typename)
        self.data = {
            'controller_typename': controller_typename
        }


# -----------Internal Errors----------- #
class InvalidXMLError(ValueError, exc.MgmtBaseException):
    netconf_error_tag = exc.NetconfErrorTag.BAD_ELEMENT
    msg_format = "Invalid XML: {message}"
    
    def __init__(self, bad_element, message) -> None:
        exc.MgmtBaseException.__init__(self, message=message, bad_element=bad_element)
        self.bad_element = bad_element
        self.message = message
        self.data = {
            'bad_element': bad_element,
        }


class InvalidSubtreeFilter(InvalidXMLError):
    msg_format = "Invalid subtree filter at tag {bad_element}: {message}"
    

class ImplicitOperationNotSupported(InvalidXMLError):
    
    def __init__(self, bad_element) -> None:
        super().__init__(
            bad_element,
            f"Operation(merge, delete, etc.) is not determined at {bad_element}. "
            "Using default operation or modifying multiple resources is not supported. "
            "Explicitly specify 'operation' attribute."
        )
