from __future__ import annotations
from calendar import c


from typing import Optional, Union

from lxml.etree import Element

from as_mgmt.algorithm import trie
from as_mgmt.app.exc import (
    InvalidSubtreeFilter, ImplicitOperationNotSupported,
    InvalidXMLError
)
from as_mgmt.app.registry import PathElem, PathNode
from as_mgmt.typing_helper import DataNodeType, ElementType
from as_mgmt.utils import split_xml_ns


class NetconfConverter:
    def __init__(self, tree: trie.PrefixTree[str, PathNode]) -> None:
        self._tree = tree

    @staticmethod
    def _parse_containment_node(xml: ElementType) -> tuple[Optional[ElementType], dict[str, str]]:
        # returns: 1. nested containment node(only one is supported now, raise an error if more are found)
        #          2. attribute filter dict.
        sub_xml_node: Optional[ElementType] = None
        params: dict[str, str] = {}
        for child in xml:
            if len(child) > 0:
                if sub_xml_node is not None:
                    raise InvalidSubtreeFilter(
                        xml.tag, "Subtree filter containment nodes with more than one "
                        "nested containment nodes are not supported."
                    )
                sub_xml_node = child
            elif not child.text:
                # NOTE: This case effectively requires a "not none" filter.
                #       Since we only support filtering key fields, this is not useful now.
                sub_xml_node = child
            else:
                params[child.tag] = child.text
        return sub_xml_node, params

    def parse_subtree_filter(self, xml: ElementType) -> list[PathElem]:
        """
        Parse NETCONF subtree filter, converting it into path representation before
        sending to the unified protocol server. 
        Currently in this demo, we provide a very limited version of subtree filters,
        ignoring extra resources and non-key field filters.
        """
        root = self._tree.root
        if split_xml_ns(xml.tag)[1] != "top":
            raise InvalidSubtreeFilter(xml.tag, f"expected 'top' as subtree filter root tag, got {xml.tag}")
        curr = root
        curr_xml = xml
        path_elems: list[PathElem] = []
        while curr_xml is not None:
            sub_xml, params = self._parse_containment_node(curr_xml)
            if sub_xml is None:
                break
            if sub_xml.tag not in curr.children:
                raise InvalidSubtreeFilter(sub_xml.tag, f"tag {sub_xml.tag} does not exist.")
            curr = curr.children[sub_xml.tag]
            path_name = sub_xml.tag
            # The 'list_wrap_container' branch changes the value of 'sub_xml'.
            # In that case, use tag of the container node instead of list node,
            # e.g. we should use "vlans" instead of "vlan" in the path.
            if params and curr.value['node_type'] == 'list':
                kv_pairs = [
                    (key, value)
                    for key, value in params.items() if key in curr.value['list_keys']
                ]
                curr_xml = sub_xml
            elif curr.value.get('list_wrap_container') and sub_xml is not None:  # path compression
                if sub_xml is not None:
                    sub_list_xml, _ = self._parse_containment_node(sub_xml)
                    if sub_list_xml is not None:
                        _, params = self._parse_containment_node(sub_list_xml)
                        curr_xml = sub_list_xml
                    else:  
                        #  e.g. <vlans> <vlan/> </vlans> 
                        #  This just have the same meaning with <vlans/>
                        #  (This only applies to list_wrap_container, as there must be exactly one type
                        #  of sub element named "vlan" inside "vlans")
                        params = {}
                        curr_xml = sub_xml
                else:  
                    #  e.g. <vlans/>
                    # a simple container level containment node without sub elements,
                    params = {}
                curr = list(curr.children.values())[0]
                kv_pairs = [
                    (key, value)
                    for key, value in params.items() if key in curr.value['list_keys']
                ]
            else:
                kv_pairs = []
                curr_xml = sub_xml
            elem = PathElem(path_name, kv_pairs)
            path_elems.append(elem)
        return path_elems

    @staticmethod
    def _parse_config_node(xml: ElementType) -> tuple[list[ElementType], dict[str, str]]:
        # returns: 1. nested containment node
        #          2. attribute dict.
        sub_xml_nodes: list[ElementType] = []
        attrs: dict[str, str] = {}
        child = None
        assert len(xml) > 0
        for child in xml:
            if len(child) > 0:
                sub_xml_nodes.append(child)
            elif child.text:
                attrs[child.tag] = child.text
            else:
                raise InvalidXMLError(
                    child.tag, 
                    f"Expected element with text or child tags at {child.tag}, got an empty tag instead."
                )
        return sub_xml_nodes, attrs
    
    def _xml_to_dict(self, xml: ElementType, node: trie.Node[str, PathNode]) -> dict[str, DataNodeType]:
        result: dict[str, DataNodeType] = {}
        for item in xml:
            if item.tag not in node.children: 
                ...  # Delayed error checking, will be checked by the deserializer in the protocol server.
            child_node = node.children[item.tag]
            if child_node.value['node_type'] == 'container':
                if child_node.value.get('list_wrap_container'):
                    result[item.tag] = self._parse_list_wrap_container(item, child_node)
                else:
                    result[item.tag] = self._xml_to_dict(item, child_node)
            elif child_node.value['node_type'] == 'list':
                result.setdefault(item.tag, []).append(self._xml_to_dict(item, child_node))  # type: ignore[union-attr] 
            elif child_node.value['node_type'] == 'leaf':
                result[item.tag] = item.text
            elif child_node.value['node_type'] == 'leaf_list':
                result.setdefault(item.tag, []).append(item.tag)  # type: ignore[union-attr] 
            else:
                raise InvalidXMLError(item.tag, f"Unexpected node_type {child_node.value['node_type']}")
        return result

    def _parse_list_wrap_container(self, xml: ElementType, node: trie.Node[str, PathNode]) -> list[DataNodeType]:
        list_node = list(node.children.values())[0]
        result: list[DataNodeType] = []
        for item in xml:
            if item.tag != list_node.key:
                raise InvalidXMLError(item.tag, f"Invalid tag {item.tag}, expecting {list_node.key}")
            if len(item) == 0:
                raise InvalidXMLError(item.tag, f"Expecting YANG list node at tag {item.tag}, got leaf instead.")
            result.append(self._xml_to_dict(item, list_node))
        return result
    
    def parse_edit_config(self, xml: ElementType) -> tuple[list[PathElem], str, DataNodeType]:
        """
        Parse NETCONF edit-config request, converting it into (path, action, body) triplet.
        
        :param xml: The XML element of the edit-config request. The root tag should be "top".
        :raises ImplicitOperationNotSupported: Raised when the path contains implicit operations.
           Users of this framework must explicitly specify the 'operation' or 'xc:operation' 
           attribute on resource types, and only one operation is allowed per request.
        :raises InvalidXMLError: Raised when the XML tag does not conform to RFC6241 or the YANG model.
        :return: A tuple of (path, action, body), ready to be sent to the unified protocol server.
        """
        # returns: a tuple of (path, action, body)
        curr = self._tree.root
        curr_xml = xml
        path: list[PathElem] = []
        body: DataNodeType = {}
        action: str = ""
        if split_xml_ns(xml.tag)[1] != "top":
            raise InvalidXMLError(xml.tag, f"expected 'top' as subtree filter root tag, got {xml.tag}")
        # Step 1: Parse path
        flag_found: bool = False
        while not flag_found:
            sub_xmls, attrs = self._parse_config_node(curr_xml)
            if op := curr_xml.get('operation', ''):
                action = op
                flag_found = True
            path_name = curr_xml.tag
            if len(sub_xmls) >= 2:  # This is a batch creation request. Stop parsing path immediately.
                path.append(PathElem(path_name, []))
                break
            if curr.value['node_type'] == 'container' and curr.value['list_wrap_container']:  
                # path compression
                curr = list(curr.children.values())[0]
                if sub_xmls:  # This is an item request 
                    curr_xml = sub_xmls[0]
                    if op := curr_xml.get('operation', ''):
                        action = op
                        flag_found = True
                    sub_xmls, attrs = self._parse_config_node(sub_xmls[0])
                else:  # This is a collection request
                    attrs = {}  # empty containment node, e.g. clearing a resource type.
            path.append(PathElem(path_name, [(k, v) for k, v in attrs.items() if k in curr.value['list_keys']]))
            if not sub_xmls or set(attrs.keys()) - set(curr.value.get('list_keys', [])):
                # 1. if no sub_xmls, we have reached the end of the path.
                #    this might be a "delete" operation without actual body.
                # 2. if non-key attrs(YANG leafs) found, we have entered body part and path parsing should end.
                break
            curr_xml = sub_xmls[0]
            if curr_xml.tag not in curr.children:
                raise InvalidXMLError(curr_xml.tag, f"Unknown tag {curr_xml.tag}")
            curr = curr.children[curr_xml.tag]
        if not action:
            raise ImplicitOperationNotSupported(curr_xml.tag)
        # Step 2: Parse body. Current XML should be the one with "operation" attribute.
        if curr.value.get('list_wrap_container'):
            body = self._parse_list_wrap_container(curr_xml, curr)
        else:
            body = self._xml_to_dict(curr_xml, curr)
        if action == 'create':
            path[-1].kv_pairs = []  # clear resource key for create operation, following RESTful convention.
        return list(path[1:]), action, body
    
    def _list_to_xml(self, data: DataNodeType, node: trie.Node[str, PathNode]) -> list[ElementType]:
        result: list[ElementType] = []
        if node.value['node_type'] == 'list':
            for item in data:
                if not isinstance(item, dict):
                    raise TypeError("Expecting dict as YANG list item.")
                elem = self._json_elem_to_xml(item, node)
                result.extend(elem)
        else:
            raise ValueError(f"Unexpected YANG node {node.value['node_type']} for lists")
        return result
    
    @staticmethod
    def _stringify_leaf(value: Union[str, int, float, bool]) -> str:
        if isinstance(value, bool):
            # boolean values MUST be lower case in NETCONF XML, according to RFC7950 section 9.5.1
            return str(value).lower()
        return str(value)
    
    def _json_elem_to_xml(self, data: DataNodeType, node: trie.Node[str, PathNode]) -> list[ElementType]:
        name = node.key
        if node.value.get('list_wrap_container'):   # 'reversed' path compression.
            node = list(node.children.values())[0]
            if not isinstance(data, list):
                raise TypeError(f"Expected list for YANG list wrap containers, got {type(data).__name__}")
            elem = Element(name)
            elem.extend(self._list_to_xml(data, node))
            return [elem]
        if node.value["node_type"] in ['container', 'list', 'null']:
            # "null" is typically for the root node.
            if not isinstance(data, dict):
                raise TypeError(f"Expected dict for YANG container and list item, got {type(data).__name__}")
            elem = Element(name)
            for key, value in data.items():
                if not isinstance(value, (dict, list)):  # leaf node
                    sub_elem = Element(key)
                    sub_elem.text = self._stringify_leaf(value)
                    elem.append(sub_elem)
                else:
                    converted_value = self._json_elem_to_xml(value, node.children[key])
                    elem.extend(converted_value)
            return [elem]
        if node.value["node_type"] in ['list', 'leaf_list']:
            result: list[ElementType] = []
            if node.value['node_type'] == 'leaf_list':
                for item in data:
                    elem = Element(node.key)
                    assert not isinstance(item, (dict, list))
                    elem.text = self._stringify_leaf(item)
                    result.append(elem)
            return result
        raise ValueError(f"Converter got unexpected node type {node.value['node_type']}")
        
    def format_get_data(self, path: list[PathElem], body: DataNodeType) -> ElementType:
        """
        Convert the JSON response body to XML format.

        :param path: Path to the JSON response body(i.e result of parse_subtree_filter).
        :param body: Response body.
        :return: XML response body, the root tag of which is "top".
        """
        assert isinstance(body, dict)
        curr = self._tree.root
        root_elem = Element('top')
        curr_xml = root_elem
        # Step 1: Reconstruct "path" to XML elements
        for item in path:
            curr = curr.children[item.name]
            next_elem = Element(curr.key)
            curr_xml.append(next_elem)
            curr_xml = next_elem
            if not curr.value.get('list_wrap_container'):  # 'reversed' path compression.
                continue
            curr = list(curr.children.values())[0]
            if item is path[-1]:
                continue
            new_next_elem = Element(curr.key)
            curr_xml.append(new_next_elem)
            for key, value in item.kv_pairs:
                elem = Element(key)
                elem.text = value
                new_next_elem.append(elem)
            curr_xml = new_next_elem
        # TODO: Process simple lists that are not wrapped in a container.
        # Step 2: Convert body to XML elements.
        if 'result' in body and len(body) == 1 and isinstance(body['result'], list):
            # remove "result" wrapper around collection requests.
            body = body['result']
        if isinstance(body, list):
            elems = self._list_to_xml(body, curr)
        else:
            elems = self._json_elem_to_xml(body, curr)
        curr_xml.extend(elems)
        return root_elem
    