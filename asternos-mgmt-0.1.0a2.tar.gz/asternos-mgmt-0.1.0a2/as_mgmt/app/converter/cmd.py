from __future__ import annotations

import contextlib
import re
from collections import ChainMap
from typing import NamedTuple

from as_mgmt.algorithm import trie
from as_mgmt.app.registry import PathElem, PathNode
from as_mgmt.cli.exc import DataNotFound
from as_mgmt.typing_helper import DataNodeType, SimpleJsonType
from as_mgmt.cli.cmd import AbstractCommand

DumpedCmdType = dict[str, tuple[int, 'DumpedCmdType']]
# The value is a tuple of (priority, sub_cmds)
# Can be sorted for the final result.


class CommandMatchResult(NamedTuple):
    datastore: str
    path: list[PathElem]
    action: str
    body: DataNodeType
    last_cmd: AbstractCommand


class CommandConverter:
    """Convert command sequence to request path and body."""
    
    def __init__(self, tree: trie.PrefixTree[str, PathNode],
                 toplevel_commands: list[AbstractCommand]) -> None:
        self._tree = tree
        self._toplevel_commands = toplevel_commands
        
    def _match_command_sequence(self, cmds_lines: list[str]
                               ) -> tuple[list[PathElem], str, DataNodeType, AbstractCommand]:
        cmds = self._toplevel_commands
        i = 0
        context = {}
        path = []
        assert cmds
        for line in cmds_lines:
            for cmd in cmds:
                match = cmd.parse_cmd(line)
                if match is not None:
                    context.update(match)
                    rel_path, action, body = cmd.convert(context)
                    path.extend(rel_path)
                    cmds = cmd.children
                    i += 1
                    break
            else:
                raise ValueError(f"Unknown command: {cmds_lines[-1]}")
        return path, action, body, cmd
    
    def dump_data_as_commands(self, path: list[PathElem], data: DataNodeType) -> str:
        """
        Convert API response to command sequence.

        :param path: path to the API response
        :param data: JSON-like response body
        :return: command text with multiple lines, each line is a command.
        """
        return _DumpCommandHelper(self._tree).dump(path, data)
    
    def convert_from_cmds(self, cmds: list[str]) -> CommandMatchResult:
        """
        Match and convert A SINGLE USER COMMAND
        The list of cmd_lines represents the "path of views" to the current command,
        For example: ["port ethernet", "speed 10000"],
        the latest command entered by the user is just "speed 10000"
        :returns: A tuple of (datastore, path, action, body, last_command)
           "last_command" may be used to render result and errors.
        """        
        if cmds[0].startswith("configure"):  # show command
            match = re.match("configure ([a-zA-Z0-9]+)", cmds[0])
            if match:
                datastore = match.groups()[0]
            else:
                datastore = "running"  # default cfg store for running config
            body_cmds = [item.strip() for item in cmds[1:]]
        elif match := re.match(r"show ([a-z]+)-config", cmds[0]):
            body_cmds = cmds
            datastore = match.groups()[0]
        else:  # top-level "show" commands. they always run in "operational" datastore.
            datastore = "operational"
            body_cmds = [cmds[-1]]
            # We mandate that show commands reside in top-level views.
            # They may be "imported" from other views, resulting in complex sequence.
            # We ignore such import operations by simply selecting the last command.
        path, action, body, cmd = self._match_command_sequence(body_cmds)
        return CommandMatchResult(datastore, path, action, body, cmd)


class _DumpCommandHelper:
    CMD_INDENT_SIZE = 2
    VIEW_EXIT_CMD = 'exit'
    # TODO: Make these constants configurable.
    
    def __init__(self, tree: trie.PrefixTree[str, PathNode]) -> None:
        self.tree = tree
        self.cmd_stack: list[str] = []
        self.result: DumpedCmdType = {}
        self.path_stack: list[PathElem] = []
        self.ctx_stack: list[dict[str, SimpleJsonType]] = []
        
    def dump(self, path: list[PathElem], data: DataNodeType) -> str:
        # TODO: utilize non-empty "path" parameter to implement "show this".
        assert len(path) == 0
        assert isinstance(data, dict)
        for key, child in self.tree.root.children.items():
            if key in data:
                self._proc_container(child, data[key])
        text: list[str] = []
        self._format_text(self.result, text, 0)
        return '\n'.join(text)
    
    def _format_text(self, cmd_dct: DumpedCmdType, text: list[str], indent: int):
        if not cmd_dct:
            return
        cmd_with_pri = [(-value[0], key) for key, value in cmd_dct.items()]
        # cmds with greater priority appear first.
        cmd_with_pri.sort()
        # TODO: Optimize sort of string with numeric value in it.
        for _, line in cmd_with_pri:
            text.append(f"{' ' * indent}{line}")
            self._format_text(cmd_dct[line][1], text, indent + self.CMD_INDENT_SIZE)
        if indent > 0:  # do not print exit command for the outmost level.
            text.append(f"{' ' * indent}exit")
        
    def _proc_list(self, name: str, node: trie.Node[str, PathNode], data: DataNodeType):
        assert node.value['node_type'] == 'list'
        assert isinstance(data, list)
        for item in data:
            assert isinstance(item, dict)
            path_elem = PathElem(name, [
                (k, str(item[k]))
                for k in sorted(node.value['list_keys'])
            ])
            self.path_stack.append(path_elem)
            with self._parse_push_command(node, item):
                self._proc_container(node, item)
            self.path_stack.pop()
        
    def _add_result(self, priority: int):
        curr = self.result
        for item in self.cmd_stack:
            if item not in curr:
                curr[item] = (priority, {})
            curr = curr[item][1]
            
    def _parse_sub_cmds(self, cmd: AbstractCommand, data: DataNodeType):
        for sub_cmd in cmd.children:
            if not sub_cmd.is_cfg_cmd:
                # Ignore "show" commands in configure views.
                # A typical case of this branch is "show this" command in various resources.
                continue
            if sub_cmd.path:
                # The sub commands has non-empty relative path related to the parent.
                # This means the should be processed with a subset of 'data' value
                # later at other node in the config tree
                continue
            try:
                ctx = sub_cmd.parse_path_body(self.path_stack, data)
            except DataNotFound:
                continue
            self.ctx_stack.append(ctx)
            self.cmd_stack.append(sub_cmd.dump(ChainMap(*self.ctx_stack)))
            self._add_result(sub_cmd.priority)
            self.ctx_stack.pop()
            self.cmd_stack.pop()
            
    @contextlib.contextmanager
    def _parse_push_command(self, node: trie.Node[str, PathNode], data: DataNodeType):
        if 'cfg_command' not in node.value:
            # no configure command associated, continue with child nodes.
            yield
            return
        cmd = node.value['cfg_command']
        ctx = cmd.parse_path_body(self.path_stack, data)
        self.ctx_stack.append(ctx)
        self.cmd_stack.append(cmd.dump(ChainMap(*self.ctx_stack)))
        self._add_result(cmd.priority)
        self._parse_sub_cmds(cmd, data)
        yield
        self.ctx_stack.pop()
        self.cmd_stack.pop()
        
    def _proc_container(self, node: trie.Node[str, PathNode], data: DataNodeType):
        has_cmd = False
        name = node.key
        if node.value.get('list_wrap_container'):
            # Path compression behavior:
            node = list(node.children.values())[0]
            self._proc_list(name, node, data)
            return
        for key, child in node.children.items():
            assert isinstance(data, dict)
            if key not in data:
                continue
            self.path_stack.append(PathElem(key, []))
            assert child.value is not None
            if child.value['node_type'] == 'list':
                # This should never happen due to the use of 'list_wrap_container'
                assert False
            elif child.value['node_type'] in ['container', 'list']:
                with self._parse_push_command(child, data[key]):
                    self._proc_container(child, data[key])
            else:  # leaf, leaf-list
                with self._parse_push_command(child, data[key]):
                    ...  # no other nested command for leaf node, do nothing.
            self.path_stack.pop()
        if has_cmd:
            self.ctx_stack.pop()
            self.cmd_stack.pop()
