from __future__ import annotations
from enum import Enum

import re
import typing

from dataclasses import dataclass
from typing import Callable, ClassVar, Literal, Sequence, Union, Any, TYPE_CHECKING, Iterable

from typing_extensions import TypedDict

from as_mgmt.algorithm import trie
from as_mgmt.app.exc import (
    DataVerificationError, ExtraFieldError
)
from as_mgmt.exc import MgmtBaseException
from as_mgmt.typing_helper import DataNodeType

if TYPE_CHECKING:  # pragma: no cover
    from as_mgmt.cli.cmd import AbstractCommand
    
    
class ControllerKind(str, Enum):
    RESOURCE = 'resource'
    RPC = "rpc"
    NOTIFICATION = "notification"


@dataclass
class ControllerTraits:
    """
    Holds traits and implemented features of a controller.
    This affects how mgmt framework will call each controller according to their capabilities.
    """
    key_name_index: dict[str, str]   # maps key name to controller parameter name
    filter_type_index: dict[str, type]
    kind: ControllerKind = ControllerKind.RESOURCE


class PathNode(TypedDict, total=False):
    
    node_type: Literal['leaf', 'leaf_list', 'container', 'list', 'null']
    list_wrap_container: bool
    # True if this node is a container AND it has exactly one child, which is a list
    list_keys: list[str]
    # keys of a list field.
    leaf_ref_path: list[str]
    
    controller: type
    controller_traits: ControllerTraits
    # controller class bound to this path.
    deserializer: Callable[[Union[str, float, bool]], Any]
    # verifier and deserializer defined by YANG model and type mapping(as_mgmt.serdes).
    serializer: Callable[[Union[str, float, bool]], Any]
    cfg_command: AbstractCommand


@dataclass
class PathElem:
    """
    Represents an element in XPath styled path, example:
    "/interfaces[name=Ethernet1]" -> PathElem("interfaces", ("name", "Ethernet1"))
    """
    
    name: str
    kv_pairs: list[tuple[str, str]]
    
    item_request: bool = False
    # If the last PathElem of a path set this attr to True,
    # The corresponding GET request is considered an item request.
    # Some SPIs(such as REST) will strip the list object in response and 
    # return a single resource object to clients.
    
    
@dataclass(frozen=True)
class ModuleMetadata:
    """
    Metadata of modules as requested by gNMI CapabilityResponse messages
    """
    
    name: str
    organization: str
    version: str
    

class PathParseError(Exception):
    ...


class PathRegistry:
    
    tree: trie.PrefixTree[str, PathNode]
    
    loaded_controllers: ClassVar[dict[str, type]] = {}
    loaded_commands: ClassVar[list['AbstractCommand']] = []
    
    @classmethod
    def add_controller(cls, path: str, controller: type) -> None:
        cls.loaded_controllers[path] = controller
        
    @classmethod
    def add_command(cls, cmd: AbstractCommand):
        cls.loaded_commands.append(cmd)
        
    def __init__(self):
        self.tree = trie.PrefixTree('top', lambda: {"node_type": "null"})
        # NOTE: Do not change the name/key of the root node.
        #       The name "top" is used as the root node of NETCONF XML request/response data.
        self.modules: set[ModuleMetadata] = set()
        self.toplevel_commands: list[AbstractCommand] = []
        # Commands without parents. Our search for matching CLI commands start here.

    def parse_rest_path(self, rest_path: str) -> tuple[list[PathElem], bool]:
        """
        Parse a rest-styled path into PathElem sequence. Example:
        "/interfaces/Ethernet1" -> [PathElem("interfaces", [("name", "Ethernet1")])]
        """
        parts = [i for i in rest_path.split("/") if i]
        elems: list[PathElem] = []
        i = 0
        node = self.tree.get_node([])
        is_item_request: bool = True
        while i < len(parts):
            if parts[i] not in node.children:
                raise PathParseError(f"Invalid path fragment {parts[i]}")
            node = node.children[parts[i]]
            if node.value.get('list_wrap_container'):
                # Path compression behavior:
                # Skip the container if the container has a list object as its member.
                # See also: https://github.com/openconfig/ygot/blob/master/docs/design.md#openconfig-path-compression
                node = list(node.children.values())[0]
            if node.value['node_type'] != 'list':
                elems.append(PathElem(parts[i], []))
            elif len(parts) - i - 1 < len(node.value['list_keys']):
                elems.append(PathElem(parts[i], []))
            else:
                elems.append(PathElem(parts[i], list(zip(node.value['list_keys'], parts[i+1:]))))
                i += len(node.value['list_keys'])
                is_item_request = (
                    is_item_request
                    and bool(node.value)
                    and len(node.value['list_keys']) == len(elems[-1].kv_pairs)
                )
            i += 1
            
        if is_item_request and elems:
            elems[-1].item_request = True
        
        return elems, is_item_request
    
    def parse_gnmi_path(self, path: str) -> tuple[list[PathElem], bool]:
        parts = [item for item in path.split('/') if item]
        elems: list[PathElem] = []
        node = self.tree.get_node([])
        is_item_request: bool = True
        for part in parts:
            match = re.match(r"(.+)\[(.+)\]", part)
            if not match:
                name = part
                kv_idx: list[tuple[str, str]] = []
            else:
                name, kv_str = match.groups()
                kv_idx = [
                    mo.groups()   # type: ignore[misc]
                    for mo in re.finditer(r"([a-zA-Z0-9_\-]+)=([a-zA-Z0-9_\{\}]+),?", kv_str)
                    # '{' and '}' are used to support parameter placeholders in path.
                ]
            if name not in node.children:
                raise PathParseError(f"Invalid path fragment {name}")
            node = node.children[name]
            if node.value.get('list_wrap_container'):
                # Path compression behavior
                node = list(node.children.values())[0]
            if kv_idx:
                if node.value['node_type'] != 'list':
                    raise PathParseError(f"Path fragment {name} does not accept parameters")                                      
                for key_name, _ in kv_idx:
                    if key_name not in node.value['list_keys']:
                        raise PathParseError(f"Unknown key name {key_name} for path fragment {name}")
                is_item_request = (
                    is_item_request
                    and len(node.value['list_keys']) == len(kv_idx)
                )
            elems.append(PathElem(name, kv_idx))
        
        if is_item_request and elems:
            elems[-1].item_request = True    
        
        return elems, is_item_request
    
    def set_controller_to_path_reg(self, path: str, controller: type):
        elems = path.split('/')
        curr = self.tree.root
        kv_idx_all = {}
        for elem in elems:
            if not elem:  # empty string allowed: '/vlans'  '//vlans'
                continue
            match = re.match(r"(.+)\[(.+)\]", elem)
            if not match:
                kv_idx: dict[str, str] = {}
                name = elem
            else:
                name, kv_str = match.groups()
                kv_idx = dict(
                    mo.groups()  # type: ignore[misc]
                    for mo in re.finditer(r"([a-zA-Z0-9_\-]+)={([a-zA-Z0-9_]+)},?", kv_str)
                )
            if name not in curr.children:
                raise PathParseError(f"Invalid path: {path}")
            curr = curr.children[name]
            if curr.value.get('list_wrap_container'):
                # Path compression behavior
                curr = list(curr.children.values())[0]
            if curr.value['node_type'] != 'null': 
                if curr.value['node_type'] != 'list' and kv_idx:
                    raise PathParseError(f"Invalid path {path}: elem {name} is not list node and does not have keys.")
                if set(kv_idx.keys()) != set(curr.value['list_keys']):
                    raise PathParseError(
                        f"Invalid path {path}: elem {name} expected keys: {set(curr.value['list_keys'])}, "
                        f"but got {set(kv_idx.keys())} instead."
                    )
            kv_idx_all.update(kv_idx)
        curr.value['controller'] = controller
        curr.value['controller_traits'] = ControllerTraits(
            key_name_index=kv_idx_all,
            filter_type_index={}  # NOT IMPLEMENTED
        )
        
    def _set_command_to_path_reg(self, cmd: AbstractCommand):
        path_elems = cmd.abs_path
        curr = self.tree.root
        for elem in path_elems:
            if elem.name not in curr.children:
                raise PathParseError(f"Found invalid command path: {'/'.join(i.name for i in path_elems)}")
            curr = curr.children[elem.name]
            if curr.value.get('list_wrap_container'):
                # Path compression behavior
                curr = list(curr.children.values())[0]
        if curr.value['node_type'] == 'null' and curr is not self.tree.root:
            # Special-casing root node because we want to register "show running command" to the root path.
            raise PathParseError(f"Found invalid command path: {'/'.join(i.name for i in path_elems)}")
        if cmd.is_cfg_cmd:
            # Each path node may be associated with as most one command.
            # Because command classes are crated from children to parents,
            # We can guarantee that, 
            # for multiple commands registered to the same path, either of the following is true:
            # 1. If the commands has parent-child relationship,
            #    the final value of cfg_command must be the parent command.
            # 2. Otherwise, these commands are aliases, and an arbitrary one is used to dump config.
            curr.value['cfg_command'] = cmd
    
    def set_inst_controllers(self):
        for key, value in self.loaded_controllers.items():
            self.set_controller_to_path_reg(key, value)
            
    def set_inst_commands(self):
        for cmd in self.loaded_commands:
            cmd.load_path(self)
        for cmd in self.loaded_commands:
            if not cmd.parent:
                self.toplevel_commands.append(cmd)
            self._set_command_to_path_reg(cmd)
        
    def find_controller_and_kwargs(self, path: list[PathElem]) -> tuple[type, dict]:
        curr = self.tree.root
        kwargs: dict[Any, Any] = {}
        for elem in path:
            if elem.name not in curr.children:
                raise PathParseError("Bad Path")
            curr = curr.children[elem.name]
            if curr.value.get('list_wrap_container'):
                # Path compression behavior:
                # Skip the container if the container has a list object as its member.
                # See also: https://github.com/openconfig/ygot/blob/master/docs/design.md#openconfig-path-compression
                curr = list(curr.children.values())[0]
            if curr.value['node_type'] == 'list':
                for key, value in elem.kv_pairs:
                    if key not in curr.children:
                        raise PathParseError("Bad Path")
                    node = curr.children[key].value
                    assert node is not None
                    assert node['deserializer'] is not None
                    try:
                        kwargs[key] = node['deserializer'](value)
                    except ValueError as err:
                        raise DataVerificationError('value_error', f"{key}", str(err) + "(In URL or path)") from err
                        
        if not curr.value or not curr.value['controller']:
            raise PathParseError("Bad Path")
        assert curr.value['controller_traits'] is not None
        return curr.value['controller'], {
            # Maps path parameter name to controller method parameter name.
            # For example, when using:
            # >>> @bind_path("/portchannels[name={lag_name}]/members[port={port}]")
            # We map "name" to lag_name before calling the controller.
            curr.value['controller_traits'].key_name_index[key]: value
            for key, value in kwargs.items()
        }
    
    def iter_toplevel_resource_controllers(self) -> Iterable[tuple[str, type]]:
        for name, node in self.tree.root.children.items():
            if node.value.get('list_wrap_container'):
                node = list(node.children.values())[0]
            if 'controller' in node.value  and node.value['controller_traits'].kind == ControllerKind.RESOURCE:
                yield name, node.value['controller']
    
    def serdes_body(self, path: list[PathElem], body: DataNodeType, is_serialize: bool) -> Sequence[MgmtBaseException]:
        helper = _SerdesHelper(self)
        return helper.serdes_body(path, body, is_serialize)
       

class _SerdesHelper:
    """
    Helper class as a component of dispatchers to implement
    request deserialization / response serialization
    """
    
    def __init__(self, reg: PathRegistry) -> None:
        self.reg = reg

    def _do_serdes(self, is_serialize, node: trie.Node[str, PathNode], 
                   field: str, value: Any, exc: list[MgmtBaseException]) -> Any:
        try:
            if is_serialize:
                return node.value['serializer'](value)
            return node.value['deserializer'](value)
        except ValueError as err:
            exc.append(DataVerificationError('value_error', field, str(err)))
            return None
        except TypeError as err:
            exc.append(DataVerificationError('type_error', field, str(err)))
            return None
    
    def _process_object(self, is_serialize: bool, node: trie.Node[str, PathNode],
                        body: dict[str, Any], exc: list[MgmtBaseException]) -> dict:
        assert isinstance(body, dict)
        body_keys = set(body.keys())
        for key, item in node.children.items():
            underscore_key = key.replace('-', '_')
            if is_serialize:
                target_key = key
            else:
                target_key = underscore_key
            
            if key in body:
                item_body = body[key]
                body_keys.discard(key)
                body.pop(key)
            elif underscore_key in body:
                item_body = body[underscore_key]
                body_keys.discard(underscore_key)
                body.pop(underscore_key)
            else:
                continue
            
            if item.value is not None and item.value.get('list_wrap_container'):
                # Path compression behavior:
                # Skip the container if the container has a list object as its member.
                # See also: https://github.com/openconfig/ygot/blob/master/docs/design.md#openconfig-path-compression
                item = list(item.children.values())[0]
            if item.value['node_type'] in ["container", "null"]:
                # item.value == "null": this happens at the root node when dumping config.
                if not isinstance(item_body, dict):
                    exc.append(DataVerificationError(
                        "type_error", key, f"expected dict(container), got {type(item_body).__name__}"
                    ))
                    continue
                body[target_key] = self._process_object(is_serialize, item, item_body, exc)
            elif item.value['node_type'] == "list":
                if not isinstance(item_body, list):
                    exc.append(DataVerificationError(
                        "type_error", key, f"expected list, got {type(item_body).__name__}"
                    ))
                    continue
                body[target_key] = [
                    self._process_object(is_serialize, item, list_obj, exc)
                    for list_obj in item_body
                ]
            elif item.value['node_type'] == 'leaf':
                if is_serialize and item_body is None:
                    # When serializing(formatting response), ignore any None leaf fields.
                    # This simplifies controllers' code since they don't need to test None for each attribute.
                    continue
                if not is_serialize and item_body is None:
                    # When deserializing(parsing request), leave None leaf fields as-is.
                    # In a MERGE request(e.g. HTTP PATCH), the controller MUST reset the value of a none fields,
                    # granting user the ability of removing a leaf node from configuration tree.
                    body[target_key] = None
                else:
                    body[target_key] = self._do_serdes(is_serialize, item, key, item_body, exc)
            elif item.value['node_type'] == 'leaf_list':
                if not isinstance(item_body, list):
                    exc.append(DataVerificationError(
                        "type_error", key, f"expected list(leaf-list), got {type(item_body).__name__}"
                    ))
                    continue
                body[target_key] = [
                    self._do_serdes(is_serialize, item, key, leaf_list_item, exc)
                    for leaf_list_item in item_body
                ]
            else:
                assert False
        
        if body_keys:
            if is_serialize:  # when generating request, silently ignore any extra key.
                for extra_key in body_keys:
                    body.pop(extra_key)
            else:  # when parsing user request, report extra keys as a bad request error.
                exc.append(ExtraFieldError(list(body_keys)))   
        
        return body
    
    def serdes_body(self, path: list[PathElem], body: DataNodeType, is_serialize: bool) -> Sequence[MgmtBaseException]:
        if not isinstance(body, (dict, list)):
            return [DataVerificationError(
                "type_error", "",
                "Request body should be a dictionary or list"
            )]
        # TODO: Support non-dict json types if required
        curr = self.reg.tree.root
        for elem in path:
            curr = curr.children[elem.name]
            if curr.value.get('list_wrap_container'):
                # Path compression behavior:
                # Skip the container if the container has a list object as its member.
                # See also: https://github.com/openconfig/ygot/blob/master/docs/design.md#openconfig-path-compression
                curr = list(curr.children.values())[0]
        exc: list[MgmtBaseException] = []
        if curr.value['node_type'] == "list":
            if not isinstance(body, list):
                # Creating a single object.
                # When using POST method on a collection,
                # Both single object creation(a dict) and batch creation(a list of dicts) are allowed.
                body = [body]
            key = path[-1].name
            for list_item in typing.cast(list[DataNodeType], body):
                if not isinstance(list_item, dict):
                    exc.append(DataVerificationError(
                        "type_error", key,
                        "Failed to parse JSON payload. Encountered nested list structure."
                    ))
                    continue
                self._process_object(is_serialize, curr, list_item, exc)
            return exc
        # Else: simple, non-collection resources, typically global config.
        if not isinstance(body, dict):
            exc.append(DataVerificationError(
                "type_error", path[-1].name,
                "Failed to parse JSON payload. Expected dict, got list instead."
            ))
        else:
            self._process_object(is_serialize, curr, body, exc)
        return exc
