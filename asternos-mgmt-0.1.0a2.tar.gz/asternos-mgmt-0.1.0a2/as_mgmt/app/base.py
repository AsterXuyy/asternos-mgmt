from __future__ import annotations

import asyncio
from collections import defaultdict
from dataclasses import dataclass
from typing import (
    Any, Callable, NamedTuple, Union, overload, Optional, Generic, TypeVar, Type
)

from typing_extensions import Self
from as_mgmt.db.session import Session

from .registry import PathRegistry


T = TypeVar('T', covariant=True)

class UpdateTuple(NamedTuple):
    path: list[str]
    # parsed object path. for example, "config/mtu" becomes ["config", "mtu"]
    op: str
    # typically one of: "add", "replace", "delete"
    data: dict[str, Any]
    

@dataclass
class SessionContext:
    cfg_db: Session
    app_db: Session
    cnt_db: Session
    state_db: Session
    flex_cnt_db: Session
    

class _DepInjectDescriptorMeta(type):
    
    def __new__(mcs, name: str, bases: tuple[type, ...], dct: dict[str, Any]):
        dct["index"] = defaultdict(lambda: [])  # Create a unique index class attribute for each UseXXX class.
        return super().__new__(mcs, name, bases, dct)


class _DepInjectDescriptorBase(Generic[T], metaclass=_DepInjectDescriptorMeta):
    
    index: dict[type, list[str]]
    _owner: Optional[type]
    _name: str
    
    def __init__(self) -> None:
        self._owner = None
        self._name = '__unbound__'
        
    def __set_name__(self, owner: type, name: str):
        self._owner = owner
        self._name = name
        self.index[owner].append(name)
    
    @overload
    def __get__(self, instance: None, owner: type) -> Self:
        ...

    @overload
    def __get__(self, instance: object, owner: type) -> T:
        ...

    def __get__(self, instance: object, owner: type) -> Union[Self, T]:
        assert self._owner is not None
        if instance is None:  # accessing classes instead of instances.
            return self
        field_hidden_name = self._field_hidden_name
        if not hasattr(instance, field_hidden_name):
            raise AttributeError(f"{self._owner.__name__}.{self._name} not set")
        return getattr(instance, field_hidden_name)
    
    @property
    def _field_hidden_name(self) -> str:
        # Use name prefixed with '__' to hide the real value in the instance's __dict__ attribute.
        return f'__{self._name}'


class UseSession(_DepInjectDescriptorBase[Session]):
    """
    Instruct the framework to provide database sessions for controller classes.
    This class handles datastore and transactions internally without bothering users.
    
    Instantiate this class as a class attribute, and it will be ready to use at runtime.
    >>> class SomeController:
    >>>     cfg_db = UseSession("CONFIG_DB")
    >>>     async def some_method(self):
    >>>         await session.add(SomeModel())
    >>>         ...
    
    When writing unit tests, this class attribute may be assigned a session object directly,
    without knowing how the framework handles db connections, datastores and transactions.
    >>> con = SomeController()
    >>> con.cfg_db = Session()
    >>> await con.some_method() == ...
    
    Mock objects are also acceptable:
    >>> con.cfg_db = mock.AsyncMock()
    >>> await con.some_method()
    >>> mock.add.assert_called()
    
    """
    
    def __init__(self, db_name: str) -> None:
        super().__init__()
        if db_name not in ["CONFIG_DB", "APP_DB", "COUNTER_DB", "STATE_DB", "FLEX_COUNTER_DB"]:
            raise ValueError(f"Unrecognized database name {db_name}")
        self.db_name = db_name
        
    @overload
    def __set__(self, instance: object, value: Session) -> None:
        """Direct set, typically used in unit tests"""
        
    @overload
    def __set__(self, instance: object, value: SessionContext) -> None:
        """Pass context, used in real implementation"""

    def __set__(self, instance: object, value: Union[Session, SessionContext]) -> None:
        assert self._owner is not None
        field_hidden_name = f'__{self._name}'
        if isinstance(value, SessionContext):
            if self.db_name == "CONFIG_DB":
                setattr(instance, field_hidden_name, value.cfg_db)
            elif self.db_name == "APP_DB":
                setattr(instance, field_hidden_name, value.app_db)
            elif self.db_name == "COUNTER_DB":
                setattr(instance, field_hidden_name, value.cnt_db)
            elif self.db_name == "STATE_DB":
                setattr(instance, field_hidden_name, value.state_db)
            elif self.db_name == "FLEX_COUNTER_DB":
                setattr(instance, field_hidden_name, value.flex_cnt_db)
            else:
                assert False, "Bad database name"
        else:
            setattr(instance, field_hidden_name, value)


class UseController(_DepInjectDescriptorBase[T]):
    """
    Instruct the framework to provide an instance of another controller,
    reusing its code and data.
    The called controller behaves as if it is called by the framework, within a standalone user request.
    
    Cyclic dependencies among multiple controller classes are not allowed.
    """
    
    def __init__(self, controller_cls: Type[T]) -> None:
        super().__init__()
        self._controller_cls = controller_cls
        
    def __set__(self, instance: object, value: Union[T, ControllerLoader]) -> None:
        if isinstance(value, ControllerLoader):
            setattr(instance, f'__{self._name}', value.load_controller(self._controller_cls))
        else:
            setattr(instance, f'__{self._name}', value)
            
            
class UseState(_DepInjectDescriptorBase[T]):
    """
    Instruct the framework to store state for a single user.
    Typically, a controller instance is ephemeral and destroyed after completing a request.
    This helper class enables controllers to store state between multiple request of a single user.
    Users are identified by username or API Key, regardless of the API used(REST, NETCONF, etc.)
    
    NOTE: This class does not provide coroutine safety, use UseLock if necessary.
        Typical scenario is when there are I/O operations between related modifications of the state.
    :param persistent: If true, this state is stored to database, persistently.
        The type of the state must be serializable in this case.
    """
    
    def __init__(self, initial_value: T, *, persistent: bool = False) -> None:
        self._persistent = persistent
        self._init_val = initial_value
        
        
class UseLock(_DepInjectDescriptorBase[asyncio.Lock]):
    """
    Instruct the framework to provide a asyncio.Lock instance.
    """
    
    
class UseConfig(_DepInjectDescriptorBase):
    """
    Instruct the framework to provide a specific config option.
    Config Options are arranged into groups or sections, and may be loaded from command line,
    config files and environment variables. See as_mgmt.config for more details.
    
    NOTE: Due to the dynamic nature of the config registry, users of this class
        need to provide type information and instantiate generic class manually.
        In short, imitate the example below, put expected type in the "[]" after the class name. 
    >>> class SomeController
    >>>     some_cfg = UseConfig[bool]("section", "name")
    
    Config options provided by this class is read only.
    """
    
    
class UseFeatureFlag(_DepInjectDescriptorBase[bool]):
    """
    Find out whether a given feature flag is present.
    The result may vary among hardware models, ASIC types, software versions and product license.
    """
    

class UseYANGValidityTest(_DepInjectDescriptorBase[bool]):
    """
    Find out whether a given YANG path points to a valid node.
    The result may vary when YANG deviation modules are loaded to add/remove nodes on a specific platform.
    """


class UseNumSpec(_DepInjectDescriptorBase[int]):
    """
    Require a numeric specification of the current platform, such as maximum count of ACL rules.
    """


class UsedPlatformMetadata(_DepInjectDescriptorBase):
    """
    TODO: Define a standard semantic of platform metadata.
    Instruct the framework to provide platform metadata,
    including hardware model, software version and ASIC info.
    
    NOTE: This is THE LAST RESORT of resolving device compatibility issues.
    Use other methods whenever possible for better maintainability
    """
    

class UseUserIdentity(_DepInjectDescriptorBase):
    """
    TODO: Define a standard semantic of platform metadata.
    Instruct the framework to provide information about client identity.
    """
    
    
class UsePrivilegeLevel:
    """
    TODO: Define the interactions with libafauth.
    """


class ControllerLoader:
    """Load a controller and handle dependency injection"""
    
    def __init__(self, session_ctx: SessionContext):
        self._session_ctx = session_ctx
        
    def load_controller(self, controller_cls: Type[T]) -> T:
        instance = controller_cls()
        for field in UseSession.index[controller_cls]:
            setattr(instance, field, self._session_ctx)
        for field in UseController.index[controller_cls]:
            setattr(instance, field, self)
        return instance


K = TypeVar('K', bound=type)

def bind_path(path: str, type_: str = "request_handler") -> Callable[[K], K]:
    def cls_decorator(cls: K ) -> K:
        if type_ == "request_handler":
            PathRegistry.add_controller(path, cls)
        return cls
    return cls_decorator
