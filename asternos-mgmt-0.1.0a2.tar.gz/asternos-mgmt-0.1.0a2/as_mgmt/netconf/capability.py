"""
This file defines capabilities attributes according to our implementation.
Required by various protocols, this is used to negotiate with clients on session startup
"""

NETCONF_CAPABILITY_PREFIX = 'urn:ietf:params:netconf:capability:'

NETCONF_BASE_CAPABILITY = 'urn:ietf:params:netconf:base:1.1'  # protocol version
NETCONF_BASE_CAPABILITY_LEGACY = 'urn:ietf:params:netconf:base:1.0'

NETCONF_CAPABILITIES = [  # See RFC6241 Section 8.
    'writable-running:1.0',
    'candidate:1.0',
    'rollback-on-error:1.0',
    'validate:1.1',
    'startup:1.0',
]
