"""
NETCONF SSH-Based transport.
Conforming to RFC6242
"""
import asyncio
import collections
import dataclasses
import logging
import re
import typing
import weakref
from asyncio import (
    IncompleteReadError, LimitOverrunError, StreamReader, StreamWriter, AbstractEventLoop, 
    Task, coroutines, protocols, WriteTransport
)
from typing import Optional, Callable, Awaitable
from typing_extensions import TypeAlias

import asyncssh
import pam
from asyncssh import SSHServerChannel

from as_mgmt.config import cfg

LOG = logging.getLogger("netconf.transport")

END_OF_MESSAGE = b']]>]]>'
# Old message framing splitter in NETCONF v1.0

END_OF_CHUNK = b'##'

NETCONF_MAX_BUFFER_SIZE_BYTES = 65536


@dataclasses.dataclass
class NetconfContext:
    """
    Context containing TCP and SSH related info for the reference of applications.
    NOTE: This may be extended to pass more data in the future.
    """
    user: Optional[str] = None  # The user identity of the connected client
    remote_host: Optional[str] = None  # Host/address identity of the connected client
    remote_port: Optional[int] = None  # remote tcp port for underlying ssh connection
    local_host: Optional[str] = None
    local_port: Optional[int] = None   # Local ip/port of the connection


class NetConfStreamReader(StreamReader):
    
    # Provided by StreamReader:
    _buffer: bytearray
    _maybe_resume_transport: Callable[[], None]

    async def read_legacy_frame(self) -> bytes:
        """
        Read a legacy NETCONF Frame.
        legacy frames are separated by END_OF_MESSAGES.
        This format is deprecated by RFC6242, but required at the initial capability exchange
        and when serving old netconf clients.
        :return: Raw netconf frame bytes. It is up to the upper protocol implementation
                 to determine its encoding(typically UTF-8).
        NOTE: Return empty bytes '' at EOF.
              Or, use at_eof method to determine if connection is already closed. Example:
              while not reader.at_eof():
                  frame = reader.read_frame()
                  process(frame)
        """
        sep = END_OF_MESSAGE
        sep_len = len(sep)
        try:
            line = await self.readuntil(sep)
        except IncompleteReadError:
            LOG.warning("Read and discarded incomplete NETCONF frame")
            return b''
        except LimitOverrunError as err:
            if self._buffer.startswith(sep, err.consumed):
                del self._buffer[:err.consumed + sep_len]
            else:
                self._buffer.clear()
            self._maybe_resume_transport()
            raise ValueError(err.args[0]) from err
        return line[:-sep_len]

    async def read_standard_frame(self) -> bytes:
        """
        Read a standard, new-style NETCONF Frame, separated to chunks.
        :return: Raw netconf frame bytes.
        """
        in_chunk = False
        data = bytearray()
        while line := await self.readline():
            if line == b'\n':
                data.extend(line)
                break
            LOG.warning("First line not '\\n'. Discarding...")
        if not data:  # received EOF
            return b''

        while line := await self.readline():
            if re.match(rb'#[0-9]+\n', line):
                data.pop()
                # Remove the last '\n', which is a part of chunk separator and not the payload.
                in_chunk = True
                continue
            if b'##\n' == line:
                data.pop()
                return data
            if in_chunk:
                data.extend(line)
        if data:
            LOG.warning("Received EOF in the middle of a frame. "
                        "Incomplete frame discarded.")
        return b''


class NetConfStreamWriter(StreamWriter):
    
    _transport: SSHServerChannel

    def write_legacy_frame(self, data: bytes):
        """
        Write an encoded Netconf frame, using legacy separator frame.
        NOTE: This does not block and data is sent asynchronously.
              Call writer.drain() and await it to block the caller.
              Example:
                  writer.write_legacy_stream(frame)
                  await writer.drain()
        """
        self.write(data)
        self.write(b'\n')
        self.write(END_OF_MESSAGE)
        self.write(b'\n')

    def write_standard_frame(self, data: bytes):
        """
        Write an encoded Netconf frame, using new-style frame.
        """
        self.write(f'\n#{len(data)}\n'.encode('utf-8'))
        self.write(data)
        self.write(b'\n##\n')
        
    def abort(self):
        self._transport.abort()


SessionHandler: TypeAlias = Callable[[NetconfContext, NetConfStreamReader, NetConfStreamWriter], Awaitable[None]]


async def start_netconf_server(
        connected_cb: SessionHandler,
        host: str = '0.0.0.0', port: int = 830,
        ssh_server_keys: Optional[list[str]] = None,
        *,
        limit: int = NETCONF_MAX_BUFFER_SIZE_BYTES,
        **kwargs
) -> asyncssh.connection.SSHAcceptor:
    """
    Create netconf server object and start listening for incoming connection.
      :param connected_cb: Main server implementation entrypoint.
    This parameter should be a callable with three positional parameters, which are:
    context, reader, writer. Context object contains information about the client.
    reader is used to read NETCONF message frames from client(see `NetConfStreamReader`),
    and writer may
    To close connection with this specific client, call writer.close(), which results in
    a TCP FIN message to the client.
    TCP half open connections are allowed, which means that the reader is still available
    after calling writer.close() (TCP FIN sent), and writer is still available after
    reader read EOF(TCP FIN received). This allows flushing notification data on connection close.

      :param host: Local address to listening for connections.
    The default 0.0.0.0 value means listening to all addresses.

      :param port: TCP Port used for incoming connections.
    The default value 830 is defined by RFC6242 and is the standard practice for NETCONF.

      :param ssh_server_keys: A list of paths to SSH private keys(NOT ended with .pub).
    These file usually resides in "/etc/ssh" on a typical Linux system.
    The list also decides available key exchange algorithms.
    On recent versions of most Linux distributions,
    ssh-rsa has been deprecated and thus not listed by default.

      :param limit: Max read buffer size in the application.
    When this buffer is full, data will stay in system TCP receive buffer,
    which means TCP receiver window will shrink, stopping client from sending more data.

      :return: Sever object. 'update' and 'close' methods are available.
    to update connection parameters and close server.
    """
    loop = asyncio.events.get_running_loop()
    opt = asyncssh.SSHServerConnectionOptions()
    opt.prepare()

    if ssh_server_keys is None:
        ssh_server_keys = [
            '/etc/ssh/ssh_host_ecdsa_key',
            '/etc/ssh/ssh_host_ed25519_key',
            # NOTE: ssh-rsa is deprecated in later versions of OpenSSL
            #       and is thus not provided by default.
        ]

    def factory():
        reader = NetConfStreamReader(limit=limit, loop=loop)
        protocol = NetconfSSHServer(
            reader, connected_cb, loop=loop
        )
        return protocol

    return await asyncssh.create_server(
        factory, host, port, options=opt,
        server_host_keys=ssh_server_keys,
        reuse_port=True,
        **kwargs
    )


# ----------------------------------------- #
# Public API ends here.
# Content below are not related to the
# implementation of netconf applications.
# ----------------------------------------- #


class FlowControlMixin(protocols.Protocol):
    """Reusable flow control logic for StreamWriter.drain().

    This class intimidated asyncio.streams.FlowControlMixin,
    and added special considerations for NETCONF protocol.
    """
    _drain_waiters: collections.deque

    def __init__(self, loop):
        self._loop = loop
        self._paused = False
        self._drain_waiters = collections.deque()
        self._connection_lost = False

    def pause_writing(self):
        assert not self._paused
        self._paused = True
        if self._loop.get_debug():
            LOG.debug("%r pauses writing", self)

    def resume_writing(self):
        assert self._paused
        self._paused = False
        if self._loop.get_debug():
            LOG.debug("%r resumes writing", self)

        for waiter in self._drain_waiters:
            if not waiter.done():
                waiter.set_result(None)

    def connection_lost(self, exc):
        self._connection_lost = True
        # Wake up the writer(s) if currently paused.
        if not self._paused:
            return

        for waiter in self._drain_waiters:
            if not waiter.done():
                if exc is None:
                    waiter.set_result(None)
                else:
                    waiter.set_exception(exc)

    async def _drain_helper(self):
        if self._connection_lost:
            raise ConnectionResetError('Connection lost')
        if not self._paused:
            return
        waiter = self._loop.create_future()
        self._drain_waiters.append(waiter)
        try:
            await waiter
        finally:
            self._drain_waiters.remove(waiter)

    def _get_close_waiter(self, stream):
        raise NotImplementedError


class NetconfStreamReaderProtocol(FlowControlMixin, asyncssh.SSHServerSession):
    """
    Helper class to adapt between Protocol and StreamReader.

    This class intimidates the implementation of asyncio.StreamReaderProtocol,
    and added special considerations for NETCONF protocol.
    """
    _stream_reader_wr: Optional[weakref.ReferenceType[NetConfStreamReader]]

    def __init__(self, ctx: NetconfContext,
                 stream_reader: NetConfStreamReader,
                 client_connected_cb: SessionHandler,
                 loop: AbstractEventLoop):
        super().__init__(loop)
        if stream_reader is not None:
            self._stream_reader_wr = weakref.ref(stream_reader)
        else:
            self._stream_reader_wr = None
        # This is a stream created by the `create_server()` function.
        # Keep a strong reference to the reader until a connection
        # is established.
        self._strong_reader: Optional[NetConfStreamReader] = stream_reader
        self._reject_connection = False
        self._stream_writer: Optional[NetConfStreamWriter] = None
        self._task: Optional[Task] = None
        self._transport: Optional[SSHServerChannel] = None  # a.k.a SSH Channel
        self._client_connected_cb = client_connected_cb
        self._over_ssl = False
        self._closed = self._loop.create_future()
        self._ctx = ctx

    @property
    def _stream_reader(self):
        if self._stream_reader_wr is None:
            return None
        return self._stream_reader_wr()

    def _replace_writer(self, writer):
        transport = writer.transport
        self._stream_writer = writer
        self._transport = transport
        self._over_ssl = transport.get_extra_info('sslcontext') is not None

    def connection_made(self, chan: SSHServerChannel):  # type: ignore[override]
        transport = chan  # "Channel" and "Transport" are synonyms in this context.
        # Ignoring incompatible override, because SSHServerChannel actually implements BaseProtocol,
        # but is not explicitly registered as its subclass/
        transport.set_encoding(None)
        if self._reject_connection:
            context = {
                'message': ('An open stream was garbage collected prior to '
                            'establishing network connection; '
                            'call "stream.close()" explicitly.')
            }
            self._loop.call_exception_handler(context)
            transport.abort()
            return
        self._transport = transport
        reader = self._stream_reader
        if reader is not None:
            reader.set_transport(transport)
        self._over_ssl = transport.get_extra_info('sslcontext') is not None
        if self._client_connected_cb is not None:
            self._stream_writer = NetConfStreamWriter(
                typing.cast(WriteTransport, transport),
                self, reader, self._loop
            )
            res = self._client_connected_cb(self._ctx, reader, self._stream_writer)
            if coroutines.iscoroutine(res):
                self._task = self._loop.create_task(res)
            self._strong_reader = None

    def connection_lost(self, exc: Optional[Exception]):
        reader = self._stream_reader
        if reader is not None:
            if exc is None:
                reader.feed_eof()
            else:
                reader.set_exception(exc)
        if not self._closed.done():
            if exc is None:
                self._closed.set_result(None)
            else:
                self._closed.set_exception(exc)
        super().connection_lost(exc)
        self._stream_reader_wr = None
        self._stream_writer = None
        self._transport = None

    def data_received(self, data: bytes, datatype=None):
        reader = self._stream_reader
        if reader is not None:
            reader.feed_data(data)

    def eof_received(self):
        reader = self._stream_reader
        if reader is not None:
            reader.feed_eof()
        if self._over_ssl:
            # Prevent a warning in SSLProtocol.eof_received:
            # "returning true from eof_received()
            # has no effect when using ssl"
            return False
        return True

    def _get_close_waiter(self, stream):
        return self._closed

    def __del__(self):
        # Prevent reports about unhandled exceptions.
        # Better than self._closed._log_traceback = False hack
        try:
            closed = self._closed
        except AttributeError:
            pass  # failed constructor
        else:
            if closed.done() and not closed.cancelled():
                closed.exception()

    def subsystem_requested(self, subsystem: str) -> bool:
        if subsystem != "netconf":
            LOG.error("Requested unsupported subsystem %s.", subsystem)
            return False
        return True


class NetconfSSHServer(asyncssh.SSHServer):

    def __init__(self, stream_reader: NetConfStreamReader,
                 connected_cb: SessionHandler,
                 loop: Optional[AbstractEventLoop] = None):
        self._stream_reader = stream_reader
        self._connected_cb = connected_cb
        self._loop = loop
        self._ctx: NetconfContext = NetconfContext()

    def password_auth_supported(self) -> bool:
        return True

    def connection_requested(self, dest_host: str, dest_port: int,
                             orig_host: str, orig_port: int) -> bool:
        self._ctx.remote_host = orig_host
        self._ctx.remote_port = orig_port
        self._ctx.local_port = dest_port
        self._ctx.local_host = dest_host
        return True

    async def validate_password(self, username: str,  # pylint: disable=invalid-overridden-method
                                password: str) -> bool:
        self._ctx.user = username
        if cfg.netconf.disable_auth:
            return True
        return await asyncio.get_event_loop().run_in_executor(
            None, pam.authenticate, username, password
        )

    def session_requested(self) -> NetconfStreamReaderProtocol:
        assert self._loop is not None
        return NetconfStreamReaderProtocol(
            self._ctx, self._stream_reader, self._connected_cb, self._loop
        )
