
from lxml import etree
from lxml.etree import Element
from lxml.etree import fromstring

from as_mgmt.netconf import capability
from as_mgmt.typing_helper import ElementType
from as_mgmt.utils import split_xml_ns


class InvalidClientHelloMsgError(ValueError):
    pass


def format_server_hello_msg(session_id: int) -> ElementType:
    hello = Element("{urn:ietf:params:xml:ns:netconf:base:1.0}hello")
    cap_list = Element('capabilities')
    hello.append(cap_list)
    base_cap = Element('capability')
    base_cap.text = capability.NETCONF_BASE_CAPABILITY
    cap_list.append(base_cap)
    for server_cap_name in capability.NETCONF_CAPABILITIES:
        server_cap = Element('capability')
        server_cap.text = capability.NETCONF_CAPABILITY_PREFIX + server_cap_name
        cap_list.append(server_cap)
    sess = Element("session-id")
    sess.text = str(session_id)
    hello.append(sess)
    return hello


def parse_client_hello_msg(msg: bytes) -> bool:
    """:return Whether new-style chunk-based message framing is supported"""
    hello = etree.fromstring(msg)
    caps = []
    for elem in hello:
        if split_xml_ns(elem.tag)[1] == 'capabilities':
            for sub_elem in elem:
                if 'capability' in sub_elem.tag:
                    caps.append(sub_elem.text)
    if capability.NETCONF_BASE_CAPABILITY in caps:
        return True
    if capability.NETCONF_BASE_CAPABILITY_LEGACY in caps:
        return False
    raise InvalidClientHelloMsgError()


OK_ELEM = fromstring("<ok/>")
