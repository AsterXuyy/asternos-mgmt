from __future__ import annotations

import asyncio
import logging
import os
import time
import traceback
from asyncio import Task, Future, Queue
from typing import Callable, Optional, Union

from asyncssh.connection import SSHAcceptor
from lxml.etree import fromstring, tostring, Element

from as_mgmt import exc
from as_mgmt import utils
from as_mgmt.app.registry import PathElem
from as_mgmt.app.exc import InvalidSubtreeFilter
from as_mgmt.app.proto_server import (
    AbstractProtoClient, AbstractProtoServer, Notification, Response,
    RequestID, Request, RequestContext, UserClientID, Action
)
from as_mgmt.config import cfg, register_opt, Opt
from as_mgmt.netconf import hello
from as_mgmt.netconf.exc import BadNetconfMessageError
from as_mgmt.netconf.stream import (
    NetconfContext, start_netconf_server, NetConfStreamReader, NetConfStreamWriter
)
from as_mgmt.typing_helper import DataNodeType, ElementType, CommentElementType

LOG = logging.getLogger(__name__)


register_opt([
    Opt('netconf', 'max_request', int, "Max number of concurrent NETCONF sessions", default=20),
    Opt('netconf', 'address', str, 
        'Local IP address for HTTP Server for NETCONF server to listen on', default="0.0.0.0"),
    Opt("netconf", "port", int, "TCP Port to accept NETCONF connections, defaults to 830", default=830),
    Opt("netconf", "disable_auth", bool, 
        "Disable NETCONF user authentication. For test purpose only.", default=False),
    Opt("netconf", "use_bundled_ssh_hostkey", bool,
        "Use a bundled ecdsa host key for NETCONF transport. "
        "Useful when the user lacks privilege to access local system ssh keys", default=False),
])


class NetconfProtoClient(AbstractProtoClient):
    _pending_requests: dict[RequestID, tuple[Request, Future[tuple[list[ElementType], str]]]]
    # Maps RequestID to (request, response_future)
    
    def __init__(self, server: AbstractProtoServer):
        self._server = server
        self._converter = server.get_netconf_protocol_converter()
        self._client_id = self._server.add_client(self)
        self._pending_requests = {}
    
    @staticmethod
    def _format_internal_error(err: Exception) -> ElementType:
        elem = Element('rpc-error')
        err_type = Element('error-type')
        err_type.text = 'application'
        err_severity = Element('error-severity')
        err_severity.text = 'error'
        tag = Element('error-tag')
        tag.text = exc.NetconfErrorTag.OPERATION_FAILED
        app_tag = Element('error-app-tag')
        app_tag.text = "internal-error"
        msg = Element('error-message')
        msg.text = str(err)
        
        elem.extend([err_type, err_severity, tag, app_tag, msg])
        return elem
    
    def _format_error(self, exceptions: list[Exception]) -> tuple[list[ElementType], str]:
        result: list[ElementType] = []
        err_tag = 'internal-error'
        for err in exceptions:
            if isinstance(err, exc.MgmtBaseException):
                err_elem = err.format_netconf_rpc_error()
                err_tag = err.netconf_error_tag
            else:
                err_elem = self._format_internal_error(err)
            result.append(err_elem) 
        return result, err_tag
    
    def response_callback(self, response: Response):
        req = self._pending_requests[response.request_id][0]
        result: tuple[list[ElementType], str] = ([hello.OK_ELEM], "")
        if response.exceptions:
            result = self._format_error(response.exceptions)
        if req.action == Action.GET:
            try:
                data = [self._converter.format_get_data(req.path, response.body)]
                result = ([Element("data")], "")
                result[0][0].extend(data)
            except (TypeError, ValueError) as err:
                LOG.error("Failed to convert JSON data to XML:")
                LOG.error(traceback.format_exc())
                result = self._format_error([err])
        self._pending_requests[response.request_id][1].set_result(result)
            
    def notification_callback(self, notification: Notification):
        raise RuntimeError("Notifications are temporarily not implemented by NETCONF")
    
    async def send_request(self, request_id: str, session_id: int, 
                           datastore: Optional[str], netconf_action: str,
                           subtree_filter: Optional[ElementType], 
                           data: Optional[ElementType]) -> tuple[list[ElementType], str]:
        assert netconf_action in ['get-config', 'get', 'edit-config']
        path: list[PathElem] = []
        body: DataNodeType = {}
        action: str
        req_id_normalized = RequestID(request_id)
        if netconf_action in ['get', 'get-config']:
            action = 'get'
            if subtree_filter is not None:
                try:
                    path = self._converter.parse_subtree_filter(subtree_filter)
                except InvalidSubtreeFilter as err: 
                    return self._format_error([err])
            if datastore is None:
                if netconf_action == 'get':
                    datastore = 'operational'
                else:
                    datastore = 'running'
        else:
            if data is None:  # empty request
                return [hello.OK_ELEM], ""
            if datastore is None:
                datastore = "running"
            try:
                path, action, body = self._converter.parse_edit_config(data)
            except Exception as err:  # pylint: disable=broad-exception-caught
                return self._format_error([err])
        
        proto_req = Request(
            self._client_id, UserClientID(str(session_id)), req_id_normalized, RequestContext(),
            datastore, path, Action(action), body
        )
        self._pending_requests[req_id_normalized] = (proto_req, asyncio.get_running_loop().create_future())
        self._server.add_request(proto_req)
        return await self._pending_requests[req_id_normalized][1]


class SessionIdAllocator:
    current = 0
    # Type of session_id defined by RFC6242 is uint32.
    
    MAX = 2**32 - 1

    @classmethod
    def reset(cls):
        cls.current = 0

    @classmethod
    def allocate(cls):
        cls.current += 1
        if cls.current >= cls.MAX:
            cls.current = 0
        return cls.current


class NetconfServer:
    """
    NETCONF protocol implementation.
    This class is responsible for accepting connections from clients and negotiate capabilities.
    """
    
    def __init__(self, proto_server: AbstractProtoServer, 
                 ssh_keys: Optional[list[str]] = None, 
                 sshd_config: Optional[list[str]] = None):
        self._listener: Optional[SSHAcceptor] = None
        self._sessions: set[NetconfSession] = set()
        self._proto = NetconfProtoClient(proto_server)
        self._ssh_keys = ssh_keys
        self._sshd_config = sshd_config
        
        if self._ssh_keys is None and cfg.netconf.use_bundled_ssh_hostkey:
            self._ssh_keys = [
                os.path.join(os.path.abspath(os.path.dirname(__file__)), '../test/ssh_keys/ssh_host_ecdsa_key')
            ]
        
    async def run(self):
        self._listener = await start_netconf_server(
            connected_cb=self._handle_entry, host=cfg.netconf.address,
            port=cfg.netconf.port,
            ssh_server_keys=self._ssh_keys,
            config=self._sshd_config
        )
        
    async def stop(self):
        if self._listener is None:
            raise ValueError("Closing NETCONF server before stating it.")
        self._listener.close()
        await self._listener.wait_closed()
        if self._sessions:
            await asyncio.wait([asyncio.create_task(session.stop()) for session in self._sessions], timeout=5)
            
    async def _handle_entry(self, context: NetconfContext, reader: NetConfStreamReader, writer: NetConfStreamWriter):
        try:
            await self._handle(context, reader, writer)
        except Exception:  # pylint: disable=broad-exception-caught
            LOG.error("Unexpected exception when handling incoming NETCONF session: ")
            LOG.error(traceback.format_exc())
            if not writer.is_closing():
                writer.write_eof()
                writer.close()
                await writer.wait_closed()
        
    async def _handle(self, context: NetconfContext, reader: NetConfStreamReader, writer: NetConfStreamWriter):
        session_id = SessionIdAllocator.allocate()
        writer.write_legacy_frame(tostring(
            hello.format_server_hello_msg(session_id)
        ))
        is_new_version = hello.parse_client_hello_msg(
            await reader.read_legacy_frame()
        )
        session = NetconfSession(
            session_id, version='1.1' if is_new_version else "1.0", proto_client=self._proto,
            context=context, reader=reader, writer=writer,
            close_callback=self._sessions.discard
        )
        self._sessions.add(session)
        session.start()
        

class NetconfSession:
    """
    NETCONF protocol session implementation.
    This class is responsible for handling RPCs with a specific client.
    """
    
    _op_map = {
        # Maps RFC8526 extensional operations to standard RFC6241 operations.
        "get-data": "get-config",
        "edit-data": "edit-config"
    }
    _action_map = {
        "get-config": Action.GET,
        "edit-config": Action.MERGE,
        "copy-config": Action.REPLACE,
        "delete-config": Action.DELETE,
    }
    
    def __init__(self, session_id: int, version: str, context: NetconfContext, 
                 proto_client: NetconfProtoClient,
                 reader: NetConfStreamReader, writer: NetConfStreamWriter,
                 close_callback: Callable[[NetconfSession], None]) -> None:
        self._version = version
        self._context = context
        self._reader = reader
        self._writer = writer
        self._close_callback = close_callback
        self._proto = proto_client
        self._session_id = session_id
        
        # Compared with REST API server, we need an extra queue per-session
        # to support "request pipelining" where users consecutively send multiple requests
        # before previous ones finish. Such requests must be processed in order.
        self._req_accept_task: Optional[Task] = None
        self._req_accept_queue: Queue[bytes] = Queue(maxsize=100)
        # TODO: Make maxsize configurable.
        self._req_task: Optional[Task] = None
        
        # This namespace should be ended with 1.0 regardless of the "version",
        # which only affects SSH Transport protocol
        self._xml_ns = "urn:ietf:params:xml:ns:netconf:base:1.0"
        
    async def write(self,  msg_id: str, rpc_body: list[ElementType],
                    start: Optional[float] = None, req_type: str = "", err_tag: str = "") -> None:
        rpc = Element("rpc-reply",
                      attrib={"message-id": str(msg_id)}, nsmap={None: self._xml_ns})  # type: ignore[dict-item]
        rpc.extend(rpc_body)
        data = tostring(rpc)
        if self._version == '1.1':
            self._writer.write_standard_frame(data)
        else:
            self._writer.write_legacy_frame(data)
        await self._writer.drain()
        if start is not None:
            if err_tag:
                LOG.warning("NETCONF request %s %s failed with %s in %.3f ms", 
                            msg_id, req_type, err_tag, (time.monotonic() - start) * 1000)
            else:
                LOG.info("NETCONF request %s %s send %s bytes in %.3f ms", 
                          msg_id, req_type, len(data), (time.monotonic() - start) * 1000)
        
    def write_error(self, msg_id: Union[str, int], errors: list[Exception], 
                    start: Optional[float] = None, req_type: str = ""):
        rpc = Element("rpc-reply", 
                      attrib={"message-id": str(msg_id)}, nsmap={None: self._xml_ns})  # type: ignore[dict-item]
        err_tag = 'protocol-failure'
        for error in errors:
            if isinstance(error, exc.MgmtBaseException):
                rpc.append(error.format_netconf_rpc_error())
                err_tag = error.netconf_error_tag
            else:
                LOG.error("Unexpected error during netconf protocol process: ")
                LOG.error("%s: %s", type(error).__name__, str(error))
                LOG.error(traceback.format_exc())
                rpc.append(self._format_simple_exception(error))
        data = tostring(rpc)
        if self._version == '1.1':
            self._writer.write_standard_frame(data)
        else:
            self._writer.write_legacy_frame(data)
        if start is not None:
            LOG.warning("NETCONF request %s %s failed with %s in %.3f ms", 
                        msg_id, req_type, err_tag, (time.monotonic() - start) * 1000)
                
    @staticmethod
    def _format_simple_exception(error: Exception):
        rpc_error = Element('rpc-error')
        error_tag = Element('error-tag')
        error_tag.text = 'operation-failed'
        app_tag = Element('error-app-tag')
        app_tag.text = "internal-error"
        msg = Element("error-message")
        msg.text = f"{type(error).__name__}: {str(error)}"
        error_type = Element('error-type')
        error_type.text = 'protocol'
        
        rpc_error.extend([error_tag, app_tag, msg, error_type])
        return rpc_error
             
    async def read(self) -> bytes:
        if self._version == "1.1":
            data = await self._reader.read_standard_frame()
        else:
            data = await self._reader.read_legacy_frame()
        return data
    
    async def _request_accept_entry(self):
        while True:
            if self._reader.at_eof():
                await self._req_accept_queue.put(b'__flag_stream_end')
                break
            frame = await self.read()
            if not frame:
                await self._req_accept_queue.put(b'__flag_stream_end')
                break
            await self._req_accept_queue.put(frame)
            
    @staticmethod
    def _parse_rpc_action(action: ElementType, 
                          is_get: bool) -> tuple[Optional[str],  Optional[ElementType], Optional[ElementType]]:
        # return: (datastore, body, subtree_filter)
        datastore: Optional[str] = None
        body: Optional[ElementType] = None
        subtree_filter: Optional[ElementType] = None
        for elem in action:
            if not is_get and elem.tag == 'target':  # <target> <running/> </target>
                for sub_elem in elem:
                    datastore = sub_elem.tag
            elif not is_get and elem.tag == 'config':
                for sub_elem in elem:  # <config> <top> ... </top> </config>
                    body = sub_elem
            elif is_get and elem.tag == 'source':
                for sub_elem in elem:  # <source> <running/> </source>
                    datastore = sub_elem.tag
            elif is_get and elem.tag == 'filter':
                if elem.get('type') != 'subtree':
                    raise BadNetconfMessageError('unsupported-filter-type', 'Only subtree-filters are supported.')
                for sub_elem in elem:  # <filter type="subtree"> <top> ... </top> </filter>
                    subtree_filter = sub_elem
        return datastore, body, subtree_filter
    
    @staticmethod
    def _load_xml_and_strip_namespace(text: bytes) -> ElementType:
        # We don't like to handle various namespaces in XML documents,
        # and they are not useful for us because we don't store data as XML,
        # so we strip them before further processing.
        # An XML namespace can either get applied "by default", e.g.
        #   <top xmlns="foo.bar"> <inner/> </top>
        #   Here "inner" tag will be "{foo.bar}inner"
        # Or, it can be applied via a prefix:
        #   <top xmlns:pf="foo.bar"> <pf:inner/> <other/> </top>
        #   Here "inner" tag will also be "{foo.bar}inner" after parsing prefix,
        #   or, if the parser don't have enough context, it remains "pf:inner".
        # We need to handle both cases here.
        if isinstance(text, bytearray):
            text = bytes(text)  # lxml fails with bytearray. make it happy.
        root = fromstring(text)
        for elem in root.iter():
            if isinstance(elem, CommentElementType):
                continue
            ns_sp = elem.tag.find('}')
            pf_sp = elem.tag.find(':')
            if ns_sp > 0:
                elem.tag = elem.tag[ns_sp+1:]
            elif pf_sp > 0:
                elem.tag = elem.tag[pf_sp+1:]
        return root

    async def _proc_request_wrapped(self):
        try:
            await self._proc_request()
        except Exception:  # pylint: disable=broad-exception-caught
            LOG.error("Unexpected error in session handling, aborting session.")
            LOG.error(traceback.format_exc())
        if not self._writer.is_closing():  # Closing due to protocol error
            self._writer.abort()
        self._close_callback(self)

    async def _proc_request(self):
        while True:
            frame = await self._req_accept_queue.get()
            if frame == b'__flag_stream_end':
                self._writer.close()
                # TODO: We should instead use a sentinel object for this purpose.
                break
            start = time.monotonic()
            try:
                rpc = self._load_xml_and_strip_namespace(frame)
            except ValueError:
                self.write_error(0, [
                    BadNetconfMessageError('netconf.proto.xml-parse-failed', 'Failed to parse message as XML')
                ], start=start)
                break
            if utils.split_xml_ns(rpc.tag)[1] != "rpc":
                self.write_error(0, [
                    BadNetconfMessageError('netconf.proto.not-rpc', 'Expected "rpc" tag at XML root')
                ], start=start)
                break
            msg_id = rpc.get('message-id')
            if msg_id is None:
                self.write_error(0, [
                    BadNetconfMessageError('netconf.proto.bad-msg-id', "Missing or invalid message id")
                ], start=start)
                break
            rpc_body = utils.get_xml_only_child(rpc)
            if rpc_body is None:
                self.write_error(msg_id, [
                    BadNetconfMessageError('netconf.proto.empty-rpc', "Missing RPC body")
                ], start=start)
                break

            op_name = utils.split_xml_ns(rpc_body.tag)[1]
            # This tag is possible to have an associated namespace when using RFC8526 message
            op_name = self._op_map.get(op_name, op_name)
            if op_name == 'close-session':
                await self.write(msg_id, [hello.OK_ELEM])
            # TODO: Implement kill-session
            elif op_name in self._action_map:
                try:
                    datastore, body, subtree_filter = self._parse_rpc_action(
                        rpc_body, op_name in ['get', 'get-config']
                    )
                except BadNetconfMessageError as err:
                    self.write_error(msg_id, [err], start=start, req_type=op_name)
                    continue
                result, err_tag = await self._proto.send_request(
                    f"{self._session_id}-{msg_id}", self._session_id, datastore,
                    op_name, subtree_filter, body
                )
                await self.write(msg_id, result, start=start, req_type=op_name, err_tag=err_tag)
            else:
                self.write_error(0, [
                    BadNetconfMessageError('netconf.proto.bad-op', f"Unsupported operation type {op_name}")
                ])
    
    def start(self) -> None:
        self._req_accept_task = asyncio.create_task(self._request_accept_entry())
        self._req_task = asyncio.create_task(self._proc_request_wrapped())
        
    async def stop(self) -> None:
        """
        Gracefully terminate the current session.
        This method should block until the session is closed.
        """
        if self._req_task is None or self._req_task.done():
            return
        if self._req_accept_task is not None:
            self._req_accept_task.cancel()
        await self._req_accept_queue.put(b'__flag_stream_end')
        await self._req_task
