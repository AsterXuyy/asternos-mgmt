from typing import Any

from as_mgmt import exc


class BadNetconfMessageError(exc.MgmtBaseException):
    netconf_error_tag = exc.NetconfErrorTag.MALFORMED_MESSAGE
    
    def __init__(self, app_tag: str, msg: str):
        super().__init__()
        self.data: dict[str, Any] = {}
        self.error_tag = app_tag
        self.msg = msg
    

class NetConfAbortSession(BaseException):
    ...    
