from __future__ import annotations

import logging
from collections.abc import Iterator
from typing import Any, NamedTuple, cast, TYPE_CHECKING, Optional

from docutils.nodes import Text, literal, Node
from docutils.parsers.rst import directives
from sphinx import addnodes
from sphinx.addnodes import desc_signature, pending_xref, desc_content
from sphinx.directives import ObjectDescription
from sphinx.domains import Domain, ObjType, Index, IndexEntry
from sphinx.roles import XRefRole
from sphinx.locale import _
from sphinx.util.nodes import make_id, make_refnode
from sphinx.util.docfields import Field, TypedField, GroupedField

if TYPE_CHECKING:
    from docutils.nodes import Element
    from sphinx.builders import Builder
    from sphinx.environment import BuildEnvironment
    from sphinx.util.typing import OptionSpec

LOG = logging.getLogger(__name__)

NORMAL_ENTRY = 0


class ViewEntry(NamedTuple):
    docname: str
    node_id: str


class CommandEntry(NamedTuple):
    docname: str
    node_id: str


class ViewDesc(NamedTuple):
    name: str


class CommandDesc(NamedTuple):
    name: str


class KlishCommand(ObjectDescription[CommandDesc]):
    
    option_spec: OptionSpec = {
        "view": directives.unchanged,
        "idempotent": directives.flag
    }
    
    doc_field_types = [
        Field("name", names=("name", ), label=_('NAME'), has_arg=False),
        Field("synopsis", names=("synopsis", ), label=_('SYNOPSIS'), has_arg=False),
        Field("description", names=("desc", "description"), label=_("DESCRIPTION"), has_arg=False),
        TypedField("parameter", names=("param", ), label=_('PARAMETERS'), typenames=("type", )),
        GroupedField("option", names=("option", "opt"), label=_("OPTIONS")),
        Field("examples", names=("examples", ), label=_("EXAMPLES"), has_arg=False),
        Field("see_also", names=("ref", "see-also"), label=_("SEE ALSO"), has_arg=False)
    ]
    
    def get_signatures(self) -> list[str]:
        return [self.arguments[0]]
        
    def handle_signature(self, sig: str, signode: desc_signature) -> CommandDesc:
        view_name: str = self.options.get('view', "")
        if view_name:
            full_name = f"{view_name}/{sig}"
        else:
            full_name = sig
            
        signode['fullname'] = full_name
        signode += addnodes.desc_name(sig, sig)
        return CommandDesc(sig)
    
    def add_target_and_index(self, desc: CommandDesc, sig: str, signode: desc_signature) -> None:
        index_text = signode["fullname"]
            
        node_id = make_id(self.env, self.state.document, '', index_text)
        signode['ids'].append(node_id)
        self.state.document.note_explicit_target(signode)
        domain = cast(KlishDomain, self.env.get_domain('klish'))
        domain.note_command(index_text, node_id)

        self.indexnode['entries'].append(('single', index_text, node_id, '', None))
        
    def transform_content(self, contentnode: desc_content) -> None:
        nodes: list[Node] = []
        if 'view' in self.options:
            nodes.append(literal("", "", Text(f"view={self.options['view']}")))
            nodes.append(Text(" "))
        if 'idempotent' in self.options:
            nodes.append(literal("", "", Text("idempotent")))
        contentnode.children = nodes + contentnode.children
        
    def _object_hierarchy_parts(self, sig_node: desc_signature) -> tuple[str, ...]:
        fullname: str = sig_node['fullname']
        if '/' not in fullname:
            return "", fullname
        return tuple(fullname.split("/"))
        
    def _toc_entry_name(self, sig_node: desc_signature) -> str:
        config = self.env.app.config
        view, cmd = sig_node['_toc_parts']
        
        if config.toc_object_entries_show_parents == 'domain':
            return f'{view}/{cmd}'
        if config.toc_object_entries_show_parents == 'hide':
            return cmd
        if config.toc_object_entries_show_parents == 'all':
            return f'{view}/{cmd}'
        return ''


class KlishXRefRole(XRefRole):
    def process_link(self, env: BuildEnvironment, refnode: Element,
                     has_explicit_title: bool, title: str, target: str) -> tuple[str, str]:
        return title, target

    
class KlishCommandIndex(Index):
    name = "cmdindex"
    localname = _("Command Line Index")
    shortname = _("commands")
    
    def generate(self, docnames = None):
        content: dict[str, list[IndexEntry]] = {}
        modules: list[tuple[str, CommandEntry]] = sorted(
            self.domain.data['commands'].items(), key=lambda x: x[0].lower()
        )
        for qualified_name, (doc_name, node_id) in modules:
            if docnames and doc_name not in docnames:
                continue
            content.setdefault(qualified_name[0], []).append(
                IndexEntry(qualified_name, NORMAL_ENTRY, doc_name, node_id, "", "", "")
            )
            
        return sorted(content.items()), False


class KlishDomain(Domain):
    name = "klish"
    label = "Klish"
    object_types: dict[str, ObjType] = {
        'command': ObjType(_("command"), "command"),  # Klish command line, which belongs to a view
    }
    directives = {
        'command': KlishCommand,
    }
    roles = {
        'view': KlishXRefRole(),
        'command': KlishXRefRole()
    }
    initial_data: dict[str, dict[str, tuple[Any, ...]]] = {
        'views': {},  # fullname -> ViewEntry
        'commands': {},  # fullname -> Command
    }
    indices = [
        KlishCommandIndex
    ]
    
    @property
    def views(self) -> dict[str, ViewEntry]:
        return self.data.setdefault('views', {})
    
    @property
    def commands(self) -> dict[str, CommandEntry]:
        return self.data.setdefault('commands', {})
    
    def clear_doc(self, docname: str) -> None:
        for fullname, obj in list(self.views.items()):
            if obj.docname == docname:
                del self.views[fullname]
        for modname, mod in list(self.commands.items()):
            if mod.docname == docname:
                del self.commands[modname]
                
    def merge_domaindata(self, docnames: list[str], otherdata: dict[str, Any]) -> None:
        for fullname, obj in otherdata['views'].items():
            if obj.docname in docnames:
                self.views[fullname] = obj
        for modname, mod in otherdata['commands'].items():
            if mod.docname in docnames:
                self.commands[modname] = mod
                
    def resolve_xref(self, env: BuildEnvironment, fromdocname: str, builder: Builder,
                     typ: str, target: str, node: pending_xref, contnode: Element,
                     ) -> Optional[Element]:
        if typ != "command":
            return None
        cmd: Optional[tuple[str, CommandEntry]] = None
        for cmd_name, cmd_item in self.commands.items():  # TODO: This could use some optimization.
            if cmd_name.startswith(target):
                # TODO: Check for ambiguous reference that matches multiple commands.
                cmd = cmd_name, cmd_item
                break
        if cmd is None:
            return None
        full_name, cmd_entry = cmd
        return make_refnode(
            builder, fromdocname, cmd_entry.docname, cmd_entry.node_id, 
            [contnode], 
            full_name
        )
    
    def resolve_any_xref(self, env: BuildEnvironment, fromdocname: str, builder: Builder,
                         target: str, node: pending_xref, contnode: Element,
                         ) -> list[tuple[str, Element]]:
        # TODO: NOT IMPLEMENTED YET
        return []
    
    def get_objects(self) -> Iterator[tuple[str, str, str, str, str, int]]:
        for view_name, view in self.views.items():
            yield (view_name, view_name, 'view', view.docname, view.node_id, 0)
        for cmd_name, cmd in self.commands.items():
            yield (cmd_name, cmd_name, 'command', cmd.docname, cmd.node_id, 0)
            
    def note_command(self, qualified_name: str, node_id: str):
        self.commands[qualified_name] = CommandEntry(self.env.docname, node_id)
        
    def get_full_qualified_name(self, node: Element) -> Optional[str]:
        target = node.get('reftarget')
        print(target)
        if target is None:
            return None
        else:
            return target