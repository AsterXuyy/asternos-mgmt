from __future__ import annotations

from typing import Any, TYPE_CHECKING

from .klish import KlishDomain

if TYPE_CHECKING:
    from sphinx.application import Sphinx


def setup(app: Sphinx) -> dict[str, Any]:
    app.add_domain(KlishDomain)
    return {
        'version': '0.1',
        'env_version': 4,
        'parallel_read_safe': True,
        'parallel_write_safe': True,
    }
